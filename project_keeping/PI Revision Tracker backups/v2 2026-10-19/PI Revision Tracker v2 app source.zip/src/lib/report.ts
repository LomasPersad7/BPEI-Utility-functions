// Portfolio statistics and the Excel report, computed from the live project and time lists.
import { eachMonthOfInterval, format, parseISO } from "date-fns";
import type { Project, TimeEntry } from "@/data/tracker";
import { daysBetween, todayIso } from "@/lib/format";
import { isRunning } from "@/lib/time-math";

/** Inclusive reporting window, yyyy-MM-dd. */
export interface ReportPeriod {
  from: string;
  through: string;
}

export interface ProjectStats {
  project: Project;
  totalHours: number;
  periodHours: number;
  lastActivity: string | null;
  firstInPeriod: string | null;
  lastInPeriod: string | null;
  /** Intake → start, in days; null until both dates exist. */
  waitDays: number | null;
  /** Start → last logged work, in days. */
  supportDays: number | null;
}

export const inPeriod = (day: string | null, period: ReportPeriod) =>
  day !== null && day >= period.from && day <= period.through;

/** Logged (not running) entries that carry hours and a work date. */
export function loggedEntries(entries: TimeEntry[]): (TimeEntry & { hours: number; date: string })[] {
  return entries.filter(
    (e): e is TimeEntry & { hours: number; date: string } => !isRunning(e) && e.hours !== null && e.date !== null,
  );
}

export function projectStats(projects: Project[], entries: TimeEntry[], period: ReportPeriod): ProjectStats[] {
  const byProject = new Map<string, (TimeEntry & { hours: number; date: string })[]>();
  for (const entry of loggedEntries(entries)) {
    if (!entry.projectId) continue;
    const list = byProject.get(entry.projectId) ?? [];
    list.push(entry);
    byProject.set(entry.projectId, list);
  }
  return projects.map((project) => {
    let totalHours = 0;
    let periodHours = 0;
    let lastActivity: string | null = null;
    let firstInPeriod: string | null = null;
    let lastInPeriod: string | null = null;
    for (const entry of byProject.get(project.id) ?? []) {
      totalHours += entry.hours;
      if (!lastActivity || entry.date > lastActivity) lastActivity = entry.date;
      if (inPeriod(entry.date, period)) {
        periodHours += entry.hours;
        if (!firstInPeriod || entry.date < firstInPeriod) firstInPeriod = entry.date;
        if (!lastInPeriod || entry.date > lastInPeriod) lastInPeriod = entry.date;
      }
    }
    return {
      project,
      totalHours,
      periodHours,
      lastActivity,
      firstInPeriod,
      lastInPeriod,
      waitDays: project.intakeDate && project.startDate ? daysBetween(project.intakeDate, project.startDate) : null,
      supportDays: project.startDate && lastActivity ? daysBetween(project.startDate, lastActivity) : null,
    };
  });
}

export function median(values: number[]): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

/** Hours per calendar month across the period, oldest month first. */
export function hoursByMonth(entries: TimeEntry[], period: ReportPeriod): { month: string; label: string; hours: number }[] {
  const months = eachMonthOfInterval({ start: parseISO(period.from), end: parseISO(period.through) });
  const totals = new Map(months.map((m) => [format(m, "yyyy-MM"), 0]));
  for (const entry of loggedEntries(entries)) {
    if (!inPeriod(entry.date, period)) continue;
    const key = entry.date.slice(0, 7);
    if (totals.has(key)) totals.set(key, (totals.get(key) ?? 0) + entry.hours);
  }
  return months.map((m) => {
    const key = format(m, "yyyy-MM");
    return { month: key, label: format(m, "MMM yyyy"), hours: round2(totals.get(key) ?? 0) };
  });
}

export const round2 = (n: number) => Math.round(n * 100) / 100;

const asDate = (iso: string | null) =>
  iso ? new Date(Number(iso.slice(0, 4)), Number(iso.slice(5, 7)) - 1, Number(iso.slice(8, 10))) : null;

function countBy<T>(rows: T[], key: (row: T) => string): [string, number][] {
  const counts = new Map<string, number>();
  for (const row of rows) counts.set(key(row), (counts.get(key(row)) ?? 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1]);
}

/** Builds and downloads the reporting workbook. Throws when the download cannot be prepared. */
export async function downloadReport(projects: Project[], entries: TimeEntry[], period: ReportPeriod): Promise<string> {
  const xlsx = await import("xlsx");
  const stats = projectStats(projects, entries, period);
  const withActivity = stats.filter((s) => s.periodHours > 0);
  const newIntakes = stats.filter((s) => inPeriod(s.project.intakeDate, period));
  const startedInPeriod = stats.filter((s) => inPeriod(s.project.startDate, period));
  const periodEntries = loggedEntries(entries).filter((e) => inPeriod(e.date, period));
  const byId = new Map(projects.map((p) => [p.id, p]));
  const db = (p: Project) => p.database ?? "Not set";
  const sumHours = (rows: ProjectStats[]) => round2(rows.reduce((n, s) => n + s.periodHours, 0));
  const medianOrBlank = (values: number[]) => {
    const m = median(values);
    return m === null ? "" : Math.round(m);
  };

  const databases = [...new Set(stats.map((s) => db(s.project)))].sort();
  const pis = [...new Set(withActivity.map((s) => s.project.piName || "PI not set"))].sort();
  const summary: (string | number | Date | null)[][] = [
    ["PI Revision Tracker report"],
    ["Reporting period", asDate(period.from), asDate(period.through)],
    ["Generated", asDate(todayIso())],
    [],
    ["Activity in period", "Value"],
    ["Projects with logged time", withActivity.length],
    ["Hours logged", round2(periodEntries.reduce((n, e) => n + e.hours, 0))],
    ["New intakes", newIntakes.length],
    ["Projects started", startedInPeriod.length],
    ["Median wait from intake to start (days), projects started in period", medianOrBlank(startedInPeriod.flatMap((s) => (s.waitDays === null ? [] : [s.waitDays])))],
    ["Median calendar support time (days), projects with activity in period", medianOrBlank(withActivity.flatMap((s) => (s.supportDays === null ? [] : [s.supportDays])))],
    [],
    ["Projects by status (all time)", "Projects"],
    ...countBy(stats, (s) => s.project.status ?? "Not set"),
    [],
    ["Database", "All projects", "Active (not completed)", "New intakes in period", "Projects with activity in period", "Hours in period"],
    ...databases.map((name) => {
      const rows = stats.filter((s) => db(s.project) === name);
      return [
        name,
        rows.length,
        rows.filter((s) => s.project.status !== "Completed").length,
        rows.filter((s) => inPeriod(s.project.intakeDate, period)).length,
        rows.filter((s) => s.periodHours > 0).length,
        sumHours(rows),
      ];
    }),
    [],
    ["PI", "Projects with activity in period", "Hours in period", "Median calendar support time (days)"],
    ...pis.map((pi) => {
      const rows = withActivity.filter((s) => (s.project.piName || "PI not set") === pi);
      return [pi, rows.length, sumHours(rows), medianOrBlank(rows.flatMap((s) => (s.supportDays === null ? [] : [s.supportDays])))];
    }),
  ];

  const projectRows = stats.map((s) => ({
    "Project #": s.project.projectNumber,
    Project: s.project.title,
    PI: s.project.piName,
    Database: s.project.database ?? "",
    Status: s.project.status ?? "",
    Stage: s.project.stage ?? "",
    "Intake date": asDate(s.project.intakeDate),
    "Start date": asDate(s.project.startDate),
    "Last activity": asDate(s.lastActivity),
    "Total hours": round2(s.totalHours),
    "Hours in period": round2(s.periodHours),
    "Wait to start (days)": s.waitDays,
    "Support time (days)": s.supportDays,
    "Research output": s.project.researchOutput,
    "Requested by": s.project.requestedBy,
    "Intake source": s.project.intakeSource,
    Owner: s.project.owner,
    "Next action": s.project.nextAction,
  }));
  const activityRows = withActivity
    .sort((a, b) => b.periodHours - a.periodHours)
    .map((s) => ({
      "Project #": s.project.projectNumber,
      Project: s.project.title,
      PI: s.project.piName,
      Database: s.project.database ?? "",
      Status: s.project.status ?? "",
      "Hours in period": round2(s.periodHours),
      "First work in period": asDate(s.firstInPeriod),
      "Last work in period": asDate(s.lastInPeriod),
    }));
  const intakeRows = newIntakes
    .sort((a, b) => (a.project.intakeDate ?? "").localeCompare(b.project.intakeDate ?? ""))
    .map((s) => ({
      "Project #": s.project.projectNumber,
      Project: s.project.title,
      PI: s.project.piName,
      Database: s.project.database ?? "",
      "Intake date": asDate(s.project.intakeDate),
      "Requested by": s.project.requestedBy,
      Status: s.project.status ?? "",
    }));
  const monthRows = hoursByMonth(entries, period).map((m) => ({ Month: m.label, Hours: m.hours }));
  const entryRows = periodEntries
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((e) => {
      const p = e.projectId ? byId.get(e.projectId) : undefined;
      return {
        Date: asDate(e.date),
        "Project #": p?.projectNumber ?? null,
        Project: p?.title ?? "",
        PI: p?.piName ?? "",
        Database: p?.database ?? "",
        Category: e.category ?? "",
        Hours: round2(e.hours),
        "Work done": e.note,
      };
    });

  const options = { cellDates: true, dateNF: "yyyy-mm-dd" };
  const book = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(book, xlsx.utils.aoa_to_sheet(summary, options), "Summary");
  xlsx.utils.book_append_sheet(book, xlsx.utils.json_to_sheet(projectRows, options), "Projects");
  xlsx.utils.book_append_sheet(book, xlsx.utils.json_to_sheet(activityRows, options), "Activity in period");
  xlsx.utils.book_append_sheet(book, xlsx.utils.json_to_sheet(intakeRows, options), "New intakes");
  xlsx.utils.book_append_sheet(book, xlsx.utils.json_to_sheet(monthRows, options), "Hours by month");
  xlsx.utils.book_append_sheet(book, xlsx.utils.json_to_sheet(entryRows, options), "Time entries");
  const fileName = `PI Revision Tracker report ${period.from} to ${period.through}.xlsx`;
  xlsx.writeFile(book, fileName, { cellDates: true });
  return fileName;
}
