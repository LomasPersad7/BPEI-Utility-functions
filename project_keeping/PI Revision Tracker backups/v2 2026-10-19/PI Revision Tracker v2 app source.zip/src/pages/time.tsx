import { Fragment, useState } from "react";
import { useQueries, useQueryClient } from "@tanstack/react-query";
import { addDays, addMonths, differenceInCalendarDays, eachDayOfInterval, format, parseISO } from "date-fns";
import { ChevronLeft, ChevronRight, Clock, Download, Pencil, Plus, RefreshCw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ConnectorErrorState, EmptyState, LoadingState } from "@/components/states";
import { Field, RetryButton } from "@/components/tracker-ui";
import { TimeEntryForm } from "@/components/time-entry-form";
import { ProjectsService, RoundsService, TimeService } from "@/data/api";
import { usePeriodEntries } from "@/data/time-api";
import { projectLabel, toProject, toRound, type Project, type TimeEntry } from "@/data/tracker";
import { CONNECTOR, connectorFailure, remove } from "@/lib/sp";
import { allocateTime, dayKey, isRunning, periodFor, validDay, type Period, type ReportMode } from "@/lib/time-math";
import { fmtFull, fmtHours, todayIso } from "@/lib/format";
import { useConfirm } from "@/hooks/use-confirm";

interface ReportRow { entry: TimeEntry; project: Project | null; date: string; hours: number }
interface ProjectHours { id: string; title: string; pi: string; days: Record<string, number>; total: number }

export function TimePage() {
  const [mode, setMode] = useState<ReportMode>("week");
  const [anchor, setAnchor] = useState(todayIso);
  const [from, setFrom] = useState(todayIso);
  const [through, setThrough] = useState(todayIso);
  const [revision, setRevision] = useState(0);
  const [adding, setAdding] = useState(false);
  const valid = mode === "period"
    ? validDay(from) && validDay(through) && from <= through && differenceInCalendarDays(parseISO(through), parseISO(from)) < 366
    : validDay(anchor);
  const period = valid ? mode === "period" ? { start: from, end: dayKey(addDays(parseISO(through), 1)) } : periodFor(mode, anchor) : null;
  const navigate = (direction: number) => setAnchor(dayKey(mode === "month" ? addMonths(parseISO(anchor), direction) : addDays(parseISO(anchor), direction * 7)));
  return (
    <section id="workspace" tabIndex={-1} aria-labelledby="time-heading" className="mx-auto w-full max-w-[1440px] space-y-5 px-4 py-5 outline-none md:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3"><h1 id="time-heading" className="text-xl font-semibold tracking-tight">Time tracking</h1><Button className="h-auto whitespace-normal" onClick={() => setAdding(true)}><Plus aria-hidden="true" />Log time</Button></div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <Tabs value={mode} onValueChange={(value) => { if (value === "week" || value === "month" || value === "period") setMode(value); }}><TabsList aria-label="Time report" className="h-auto flex-wrap"><TabsTrigger className="h-auto whitespace-normal" value="week">Weekly timesheet</TabsTrigger><TabsTrigger className="h-auto whitespace-normal" value="month">Monthly by PI</TabsTrigger><TabsTrigger className="h-auto whitespace-normal" value="period">Date range</TabsTrigger></TabsList></Tabs>
        {mode === "period" ? <div className="flex flex-wrap gap-3"><Field id="period-from" label="From"><Input id="period-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} required /></Field><Field id="period-through" label="Through"><Input id="period-through" type="date" value={through} onChange={(e) => setThrough(e.target.value)} required /></Field></div> : <div className="flex flex-wrap items-end gap-2"><Button variant="outline" size="icon" aria-label={`Previous ${mode}`} disabled={!validDay(anchor)} onClick={() => navigate(-1)}><ChevronLeft aria-hidden="true" /></Button><Field id="time-anchor" label={mode === "month" ? "Month" : "Week containing"}><Input id="time-anchor" type={mode === "month" ? "month" : "date"} value={mode === "month" ? anchor.slice(0, 7) : anchor} onChange={(e) => setAnchor(mode === "month" ? `${e.target.value}-01` : e.target.value)} /></Field><Button variant="outline" size="icon" aria-label={`Next ${mode}`} disabled={!validDay(anchor)} onClick={() => navigate(1)}><ChevronRight aria-hidden="true" /></Button></div>}
      </div>
      {!period ? <p role="alert" className="text-sm">Choose valid dates, with a range of no more than 366 days.</p> : <TimeReport key={`${mode}:${period.start}:${period.end}:${revision}`} mode={mode} period={period} revision={revision} onRefresh={() => setRevision((n) => n + 1)} onAdd={() => setAdding(true)} />}
      <Dialog open={adding} onOpenChange={setAdding}><DialogContent className="max-h-[90dvh] overflow-y-auto"><DialogHeader><DialogTitle>Log time</DialogTitle></DialogHeader><TimeEntryForm onDone={() => { setAdding(false); setRevision((n) => n + 1); }} /></DialogContent></Dialog>
    </section>
  );
}

function TimeReport({ mode, period, revision, onRefresh, onAdd }: { mode: ReportMode; period: Period; revision: number; onRefresh: () => void; onAdd: () => void }) {
  const entries = usePeriodEntries(period, revision);
  const client = useQueryClient();
  const confirm = useConfirm();
  const [editing, setEditing] = useState<TimeEntry | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const roundIds = [...new Set(entries.rows.filter((entry) => !entry.projectId && entry.roundId).map((entry) => entry.roundId).filter((id): id is string => id !== null))];
  const roundQueries = useQueries({ queries: roundIds.map((id) => ({ queryKey: ["report-round", id], queryFn: async () => {
    const result = await RoundsService.get(id);
    if (!result.success) connectorFailure(result.error);
    const round = toRound(result.data);
    if (!round) throw new Error("Round identity is missing");
    return round;
  } })) });
  const rounds = new Map(roundQueries.flatMap((query) => query.data ? [[query.data.id, query.data] as const] : []));
  const projectIdFor = (entry: TimeEntry) => entry.projectId ?? (entry.roundId ? rounds.get(entry.roundId)?.projectId ?? null : null);
  const projectIds = [...new Set(entries.rows.map(projectIdFor).filter((id): id is string => id !== null))];
  const projectQueries = useQueries({ queries: projectIds.map((id) => ({ queryKey: ["report-project", id], queryFn: async () => {
    const result = await ProjectsService.get(id);
    if (!result.success) connectorFailure(result.error);
    const project = toProject(result.data);
    if (!project) throw new Error("Project identity is missing");
    return project;
  } })) });
  const projects = new Map(projectQueries.flatMap((query) => query.data ? [[query.data.id, query.data] as const] : []));
  const relatedError = roundQueries.find((query) => query.isError)?.error ?? projectQueries.find((query) => query.isError)?.error;
  const relatedPending = roundQueries.some((query) => query.isPending) || projectQueries.some((query) => query.isPending);
  const unlinked = !relatedPending && !relatedError && entries.rows.some((entry) => !projectIdFor(entry) || !projects.has(projectIdFor(entry) ?? ""));
  const running = entries.rows.filter(isRunning).length;
  const reportRows: ReportRow[] = [];
  let invalid = 0;
  for (const entry of entries.rows) {
    try {
      for (const slice of allocateTime(entry, period)) reportRows.push({ entry, project: projects.get(projectIdFor(entry) ?? "") ?? null, ...slice });
    } catch { invalid += 1; }
  }
  const grouped = new Map<string, ProjectHours>();
  for (const row of reportRows) {
    const id = row.project?.id ?? `unlinked-${row.entry.id}`;
    const group = grouped.get(id) ?? { id, title: row.project ? projectLabel(row.project) : `Unlinked entry #${row.entry.id}`, pi: row.project?.piName || "PI not assigned", days: {}, total: 0 };
    group.days[row.date] = (group.days[row.date] ?? 0) + row.hours;
    group.total += row.hours;
    grouped.set(id, group);
  }
  const groups = [...grouped.values()].sort((a, b) => a.pi.localeCompare(b.pi) || a.title.localeCompare(b.title));
  const total = groups.reduce((sum, group) => sum + group.total, 0);
  const piTotals = [...new Set(groups.map((group) => group.pi))].map((pi) => ({ pi, hours: groups.filter((group) => group.pi === pi).reduce((sum, group) => sum + group.total, 0) }));
  const canExport = entries.complete && !entries.query.isFetching && !relatedPending && !relatedError && !unlinked && invalid === 0 && reportRows.length > 0;
  const days = mode === "week" ? eachDayOfInterval({ start: parseISO(period.start), end: addDays(parseISO(period.end), -1) }) : [];
  const download = async () => {
    if (!canExport || exporting) return;
    setExporting(true);
    try {
      const xlsx = await import("xlsx");
      const workbook = xlsx.utils.book_new();
      const details = reportRows.map((row) => ({
        "Entry ID": row.entry.id, Date: row.date, Project: row.project ? projectLabel(row.project) : "", PI: row.project?.piName ?? "",
        Database: row.project?.database ?? "", "Round ID": row.entry.roundId ?? "", Category: row.entry.category ?? "Uncategorized",
        Hours: Number(row.hours.toFixed(6)), "Work done": row.entry.note,
      }));
      xlsx.utils.book_append_sheet(workbook, xlsx.utils.json_to_sheet(details), "Time entries");
      xlsx.utils.book_append_sheet(workbook, xlsx.utils.json_to_sheet(groups.map((group) => ({ Project: group.title, PI: group.pi, Hours: Number(group.total.toFixed(6)) }))), "By project");
      xlsx.utils.book_append_sheet(workbook, xlsx.utils.json_to_sheet(piTotals.map((row) => ({ PI: row.pi, Hours: Number(row.hours.toFixed(6)) }))), "By PI");
      xlsx.utils.book_append_sheet(workbook, xlsx.utils.aoa_to_sheet([["From", period.start], ["Through", dayKey(addDays(parseISO(period.end), -1))], ["Time zone", Intl.DateTimeFormat().resolvedOptions().timeZone], ["Scope", "All loaded pages; running timers excluded"], ["PI attribution", "Current project PI"]]), "Report scope");
      xlsx.writeFile(workbook, `time-${period.start}-through-${dayKey(addDays(parseISO(period.end), -1))}.xlsx`);
    } catch { toast.error("Couldn't prepare the Excel download. Try again."); }
    finally { setExporting(false); }
  };
  const deleteEntry = async (entry: TimeEntry) => {
    if (busy || isRunning(entry)) return;
    if (!(await confirm({ title: "Delete this time entry?", description: "The saved hours will be removed from reports.", confirmLabel: "Delete entry", destructive: true }))) return;
    setBusy(entry.id);
    const removed = await remove(() => TimeService.delete(entry.id), () => TimeService.getAll({ filter: `ID eq ${Number(entry.id)}`, top: 1 }), "Couldn't delete the time entry.");
    await Promise.all([
      client.invalidateQueries({ queryKey: ["time"] }),
      client.invalidateQueries({ queryKey: ["time-report"] }),
    ]);
    setBusy(null);
    if (removed) onRefresh();
  };
  return <div className="space-y-5">
    <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-base font-semibold">{fmtFull(period.start)} – {fmtFull(dayKey(addDays(parseISO(period.end), -1)))}</h2><div className="flex flex-wrap gap-2"><Button variant="outline" className="h-auto whitespace-normal" onClick={onRefresh}><RefreshCw aria-hidden="true" />Refresh period</Button><Button variant="outline" className="h-auto whitespace-normal" disabled={!canExport || exporting} onClick={() => void download()}><Download aria-hidden="true" />{exporting ? "Preparing…" : "Download Excel"}</Button></div></div>
    {entries.query.isPending ? <LoadingState rows={4} /> : entries.query.isError ? <ConnectorErrorState error={entries.query.error} connector={CONNECTOR} title="Couldn't load time entries" action={<RetryButton onRetry={() => void entries.query.refetch()} />} /> : <>
      <p role="status" className="text-sm">{entries.complete ? `Complete period · ${entries.rows.length} entries` : `Partial period · ${entries.rows.length} entries loaded. Load the remaining pages to finish totals and enable export.`}{running > 0 ? ` ${running} running ${running === 1 ? "timer is" : "timers are"} excluded.` : ""}</p>
      {relatedError ? <ConnectorErrorState error={relatedError} connector={CONNECTOR} title="Couldn't resolve time entries to projects" action={<RetryButton onRetry={() => { void Promise.all([...roundQueries, ...projectQueries].map((query) => query.refetch())); }} />} /> : relatedPending ? <LoadingState rows={2} /> : <>
        {unlinked && <p role="alert" className="text-sm">Some entries lack a valid project link. Their hours are shown as unlinked; export is blocked until the links are repaired.</p>}
        {invalid > 0 && <p role="alert" className="text-sm">{invalid} entries have invalid hours or dates and are excluded from totals. Correct them before exporting.</p>}
        {groups.length === 0 ? <EmptyState icon={Clock} title="No logged hours in the loaded entries" action={<Button variant="outline" onClick={onAdd}>Log time</Button>} /> : <div role="region" aria-label={mode === "week" ? "Weekly hours by project" : "Hours by project and PI"} tabIndex={0} className="min-w-0 rounded-xl border bg-card focus-visible:outline-2 focus-visible:outline-ring">
          <Table className="[&_th]:h-auto [&_th]:py-3"><TableCaption className="px-3 pb-3 text-left">{entries.complete ? "Period hours" : "Loaded-page hours"}. Timer days use {Intl.DateTimeFormat().resolvedOptions().timeZone}; PI names reflect current project assignments.</TableCaption>
            <TableHeader><TableRow><TableHead scope="col" className="min-w-44 whitespace-normal">Project / PI</TableHead>{days.map((day) => <TableHead key={dayKey(day)} scope="col" className="text-right whitespace-normal">{format(day, "EEE")}<span className="block text-xs">{format(day, "MMM d")}</span></TableHead>)}<TableHead scope="col" className="text-right whitespace-normal">{mode === "week" ? "Week total (h)" : "Hours"}</TableHead></TableRow></TableHeader>
            <TableBody>{mode === "week" ? groups.map((group) => <TableRow key={group.id}><TableHead scope="row" className="max-w-xs py-3 align-top whitespace-normal"><span className="block font-medium break-words">{group.title}</span><span className="block text-xs font-normal">{group.pi}</span></TableHead>{days.map((day) => <TableCell key={dayKey(day)} className="text-right align-top tabular-nums">{Number((group.days[dayKey(day)] ?? 0).toFixed(2))}</TableCell>)}<TableCell className="text-right align-top font-semibold tabular-nums">{Number(group.total.toFixed(2))}</TableCell></TableRow>) : piTotals.map(({ pi, hours }) => <Fragment key={pi}>{groups.filter((group) => group.pi === pi).map((group) => <TableRow key={group.id}><TableHead scope="row" className="py-3 align-top font-normal whitespace-normal break-words">{group.title}</TableHead><TableCell className="text-right align-top tabular-nums">{Number(group.total.toFixed(2))}</TableCell></TableRow>)}<TableRow className="bg-muted"><TableHead scope="row" className="py-3 font-semibold whitespace-normal">{pi} · total</TableHead><TableCell className="text-right font-semibold tabular-nums">{Number(hours.toFixed(2))}</TableCell></TableRow></Fragment>)}
              <TableRow><TableHead scope="row" className="py-3 font-semibold whitespace-normal">{entries.complete ? "Period total" : "Loaded total"}</TableHead>{days.map((day) => <TableCell key={dayKey(day)} className="text-right font-semibold tabular-nums">{Number(groups.reduce((sum, group) => sum + (group.days[dayKey(day)] ?? 0), 0).toFixed(2))}</TableCell>)}<TableCell className="text-right font-semibold tabular-nums">{Number(total.toFixed(2))}</TableCell></TableRow>
            </TableBody>
          </Table>
        </div>}
      </>}
    </>}
    <div className="flex flex-wrap items-center justify-end gap-2">{entries.hasPrev && <Button variant="outline" className="h-auto whitespace-normal" disabled={entries.query.isFetching} onClick={entries.previous}><ChevronLeft aria-hidden="true" />Previous page</Button>}{entries.hasNext && <Button variant="outline" className="h-auto whitespace-normal" disabled={entries.query.isFetching} onClick={entries.next}>{entries.query.isFetching ? "Loading…" : "Load more"}<ChevronRight aria-hidden="true" /></Button>}</div>
    {entries.pageRows.length > 0 && <section aria-labelledby="entries-heading" className="space-y-3"><h2 id="entries-heading" className="text-base font-semibold">Time entries · page {entries.index + 1}</h2><ul className="divide-y rounded-xl border bg-card">{entries.pageRows.map((entry) => <li key={entry.id} className="flex flex-wrap items-start gap-3 p-4"><div className="min-w-0 flex-1"><p className="text-sm font-medium break-words">{entry.note || `Time entry #${entry.id}`}</p><p className="mt-1 text-sm text-muted-foreground break-words">{projects.get(projectIdFor(entry) ?? "")?.title ?? "Project unresolved"} · {entry.category ?? "Uncategorized"}</p><p className="mt-1 text-sm tabular-nums">{entry.date ?? "No work date"} · {isRunning(entry) ? "Running" : entry.hours === null ? "Hours missing" : fmtHours(entry.hours)}{entry.roundId ? ` · Round #${entry.roundId}` : ""}</p></div><div className="flex shrink-0 gap-1"><Button variant="ghost" size="icon" aria-label={`Edit time entry ${entry.id}`} disabled={isRunning(entry) || busy !== null} onClick={() => setEditing(entry)}><Pencil aria-hidden="true" /></Button><Button variant="ghost" size="icon" aria-label={`Delete time entry ${entry.id}`} disabled={isRunning(entry) || busy !== null} onClick={() => void deleteEntry(entry)}><Trash2 aria-hidden="true" /></Button></div></li>)}</ul></section>}
    <Dialog open={!!editing} onOpenChange={(open) => { if (!open) setEditing(null); }}><DialogContent className="max-h-[90dvh] overflow-y-auto"><DialogHeader><DialogTitle>Edit time entry</DialogTitle></DialogHeader>{editing && <TimeEntryForm key={editing.id} entry={editing} onDone={() => { setEditing(null); onRefresh(); }} />}</DialogContent></Dialog>
  </div>;
}
