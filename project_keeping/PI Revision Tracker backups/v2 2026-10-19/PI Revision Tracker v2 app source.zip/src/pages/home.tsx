import { useRef, useState, type FormEvent } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { differenceInCalendarDays, eachMonthOfInterval, endOfMonth, format, parseISO, startOfMonth } from "date-fns";
import { toast } from "sonner";
import {
  Check,
  Clock,
  FileText,
  FolderPlus,
  Mail,
  MailPlus,
  Plus,
  Send,
  Trash2,
  Undo2,
  Users,
  type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { ConnectorErrorState, EmptyState, LoadingState } from "@/components/states";
import { ProjectNotes } from "@/components/project-notes";
import { ProjectTasks } from "@/components/project-tasks";
import { ResearchDetails } from "@/components/research-details";
import { ProjectAgents } from "@/components/project-agents";
import { StartWorkTimer } from "@/components/work-timer";
import { useAppStore } from "@/lib/store";
import { newManualSubmission, type ManualSubmission } from "@/lib/manual-submission";
import { submitManualTime, type ManualTimePayload } from "@/data/time-api";
import { ActivityService, RequestsService } from "@/data/agent-api";
import { defaultAgentMode } from "@/lib/agent-rules";
import { configuredChoice, isRunning } from "@/lib/time-math";
import {
  ChoiceSelect,
  DateField,
  DueBadge,
  Field,
  ListStatus,
  OptionalDateField,
  PageControls,
  RetryButton,
  StageBars,
  StatusBadge,
} from "@/components/tracker-ui";
import {
  ChangesService,
  NotesService,
  ProjectsService,
  RoundsService,
  TasksService,
  TimeService,
  fetchChanges,
  fetchNotes,
  fetchNextProjectNumber,
  fetchProjects,
  fetchRounds,
  fetchTasks,
  fetchTime,
  keys,
  useKindChoices,
  useStageChoices,
  useProjectChoices,
  useTimeChoices,
} from "@/data/api";
import {
  DONE_STATUS,
  NEW_PROJECT_STATUS,
  PAGE_SIZE,
  isProjectFinished,
  projectLabel,
  toSpDate,
  toProject,
  toTimeEntry,
  type ChangeItem,
  type Project,
  type Round,
  type TimeEntry,
} from "@/data/tracker";
import { useConfirm } from "@/hooks/use-confirm";
import { TONE_DOT, daysBetween, fmtDay, fmtFull, fmtHours, isOverdue, plural, projectStatusTone, stageTone, todayIso, type Tone } from "@/lib/format";
import { CONNECTOR, clearDate, connectorFailure, fetchPage, remove, save, usePaged, type Choices, type PagedList } from "@/lib/sp";
import { cn } from "@/lib/utils";

const KIND_ICON: Record<string, LucideIcon> = {
  "Initial report": FileText,
  "PI revision": Mail,
  "Reviewer revision": Users,
};
const HATCH = {
  backgroundImage: "repeating-linear-gradient(135deg, var(--primary) 0 3px, transparent 3px 7px)",
};

const roundStatus = (r: Round): { tone: Tone; label: string } =>
  r.deliveredDate ? { tone: "success", label: "Delivered" } : { tone: "pending", label: "Awaiting delivery" };

/* ---------- page ---------- */

interface NewProjectInput {
  projectNumber: number | null;
  intakeDate: string | null;
  requestedBy: string;
  title: string;
  piName: string;
  target: string;
  stage: string | null;
  status: string | null;
  targetDate: string | null;
  database: string;
  agentMode: string | null;
}

export function HomePage() {
  const queryClient = useQueryClient();
  const [params, setParams] = useSearchParams();
  const stages = useStageChoices();
  const databases = useProjectChoices("DatabaseSource");
  const statuses = useProjectChoices("Status");
  const [database, setDatabase] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(() => params.get("status"));
  const projects = usePaged([...keys.projects(PAGE_SIZE), { database, status }], (skipToken) => fetchProjects(PAGE_SIZE, skipToken, { database, status }));
  const [newOpen, setNewOpen] = useState(false);

  const requested = params.get("project");
  const validRequested = requested !== null && /^[1-9]\d*$/.test(requested);
  const listedProject = projects.rows.find((p) => p.id === requested);
  // A deep link must resolve that exact project, never another row from the current page.
  const requestedProject = useQuery({
    queryKey: ["projects", "by-id", requested],
    enabled: validRequested && !listedProject,
    queryFn: async () => {
      const result = await ProjectsService.get(requested as string);
      if (!result.success) connectorFailure(result.error);
      const found = toProject(result.data);
      if (!found || found.id !== requested) throw new Error("Requested project was not returned");
      return found;
    },
  });
  const project = requested
    ? listedProject ?? (validRequested ? requestedProject.data ?? null : null)
    : projects.rows[0] ?? null;
  const selectProject = (id: string | null) => setParams(id ? { project: id } : {}, { replace: true });
  const selectionLoading = requested ? validRequested && !listedProject && requestedProject.isPending : projects.query.isPending;
  const selectionError = requested ? !validRequested || (!listedProject && requestedProject.isError) : projects.query.isError;

  const addProject = async (input: NewProjectInput) => {
    const saved = await save(
      () =>
        ProjectsService.create({
          Title: input.title,
          PI: input.piName,
          ...(input.projectNumber !== null ? { ProjectNumber: input.projectNumber } : {}),
          ...(input.intakeDate ? { IntakeDate: toSpDate(input.intakeDate) } : {}),
          ...(input.requestedBy ? { RequestedBy: input.requestedBy } : {}),
          DatabaseSource: { Value: input.database },
          ...(input.agentMode ? { AgentMode: { Value: input.agentMode } } : {}),
          ...(input.target ? { Target: input.target } : {}),
          ...(input.stage ? { Stage: { Value: input.stage } } : {}),
          ...(input.status ? { Status: { Value: input.status } } : {}),
          ...(input.targetDate ? { TargetDate: toSpDate(input.targetDate) } : {}),
        }),
      "Couldn't add the project.",
    );
    if (!saved.ok) return false;
    await queryClient.invalidateQueries({ queryKey: ["projects"] });
    if (typeof saved.data?.ID === "number") selectProject(String(saved.data.ID));
    toast.success(`Added ${projectLabel(input)}`);
    return true;
  };

  return (
    <div className="mx-auto grid w-full max-w-[1440px] gap-6 px-4 py-5 md:px-6 lg:grid-cols-[18rem_minmax(0,1fr)]">
      <h1 className="text-xl font-semibold tracking-tight lg:col-span-2">Projects</h1>
      <div className="min-w-0 space-y-4">
        <Field id="database-filter" label="EHR database">
          <ChoiceSelect id="database-filter" choices={databases} value={database} onChange={(value) => { setDatabase(value); selectProject(null); }} what="databases" />
        </Field>
        {database && <Button variant="outline" className="h-auto whitespace-normal" onClick={() => { setDatabase(null); selectProject(null); }}>Show all databases</Button>}
        <Field id="status-filter" label="Status">
          <ChoiceSelect id="status-filter" choices={statuses} value={status} onChange={(value) => { setStatus(value); selectProject(null); }} what="statuses" />
        </Field>
        {status && <Button variant="outline" className="h-auto whitespace-normal" onClick={() => { setStatus(null); selectProject(null); }}>Show all statuses</Button>}
        <ProjectRail
          projects={projects}
          stages={stages}
          selectedId={project?.id ?? null}
          onSelect={selectProject}
          onNew={() => setNewOpen(true)}
        />
      </div>

      <section
        id="workspace"
        tabIndex={-1}
        aria-labelledby="project-title"
        className="min-w-0 space-y-5 rounded-md outline-none focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ring"
      >
        {project ? (
          <ProjectWorkspace
            key={project.id}
            project={project}
            stages={stages}
            onDeleted={() => selectProject(null)}
          />
        ) : (
          <>
            <h2 id="project-title" className="sr-only">
              Project
            </h2>
            {selectionLoading ? (
              <LoadingState rows={4} />
            ) : selectionError ? (
              <ConnectorErrorState
                error={requested ? requestedProject.error : projects.query.error}
                connector={CONNECTOR}
                title={requested ? "Couldn't load the requested project" : "Couldn't load projects"}
                action={requested && !validRequested
                  ? <Button variant="outline" onClick={() => selectProject(null)}>Back to projects</Button>
                  : <RetryButton onRetry={() => { void (requested ? requestedProject.refetch() : projects.query.refetch()); }} />}
              />
            ) : (
              <EmptyState
                icon={FolderPlus}
                title={projects.hasPrev ? "No projects on this page" : "No projects yet"}
                action={
                  <Button onClick={() => setNewOpen(true)}>
                    <Plus aria-hidden="true" />
                    New project
                  </Button>
                }
              />
            )}
          </>
        )}
      </section>

      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>New project</DialogTitle>
          </DialogHeader>
          <NewProjectForm
            stages={stages}
            onSubmit={async (input) => {
              if (await addProject(input)) setNewOpen(false);
            }}
            onCancel={() => setNewOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ---------- project rail ---------- */

function ProjectRail({
  projects,
  stages,
  selectedId,
  onSelect,
  onNew,
}: {
  projects: PagedList<Project>;
  stages: Choices;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
}) {
  const order = stages.data ?? [];
  return (
    <nav aria-label="Project list" className="min-w-0 lg:sticky lg:top-5 lg:self-start">
      <div className="mb-2 flex items-center justify-between gap-2 px-1">
        <h2 className="text-sm font-semibold">
          Projects
          {projects.query.isSuccess && !projects.paged && (
            <span className="ml-1.5 font-normal tabular-nums text-muted-foreground">{projects.rows.length}</span>
          )}
        </h2>
        <Button size="sm" variant="outline" onClick={onNew}>
          <Plus aria-hidden="true" />
          New project
        </Button>
      </div>
      {projects.query.isPending ? (
        <div role="status" aria-label="Loading projects" className="space-y-2">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-20 w-full rounded-lg" />
          ))}
        </div>
      ) : projects.query.isError ? (
        <div className="space-y-2 rounded-lg border p-3 text-sm">
          <p>Couldn&apos;t load projects.</p>
          <RetryButton onRetry={() => void projects.query.refetch()} />
        </div>
      ) : (
        <>
          <ul className="space-y-1">
            {projects.rows.map((p) => {
              const idx = p.stage ? order.indexOf(p.stage) : -1;
              const selected = p.id === selectedId;
              return (
                <li key={p.id}>
                  <button
                    type="button"
                    aria-current={selected ? "true" : undefined}
                    onClick={() => onSelect(p.id)}
                    className={cn(
                      "w-full rounded-lg border px-3 py-2.5 text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
                      selected ? "border-primary bg-card shadow-sm" : "border-transparent hover:bg-muted/60",
                    )}
                  >
                    <span className="block text-sm font-medium leading-snug">
                      {p.projectNumber !== null && <span className="mr-1.5 tabular-nums text-muted-foreground">#{p.projectNumber}</span>}
                      {p.title}
                    </span>
                    <span className="mt-0.5 block truncate text-xs text-muted-foreground">
                      {p.piName}
                      {p.target && ` · ${p.target}`}
                    </span>
                    <span className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                      {p.status && <StatusBadge tone={projectStatusTone(p.status)}><span className="sr-only">Status: </span>{p.status}</StatusBadge>}
                      {(p.stage || !p.status) && (
                        <span className="flex items-center gap-2">
                          <StageBars stage={p.stage} order={order} />
                          <span className="font-medium">{p.stage ?? "No stage"}</span>
                          {idx >= 0 && (
                            <span className="sr-only">
                              (stage {idx + 1} of {order.length})
                            </span>
                          )}
                        </span>
                      )}
                    </span>
                    {p.targetDate && (
                      <span className="mt-1.5 flex flex-wrap items-center gap-1.5 text-xs">
                        <span className="tabular-nums">Target {fmtDay(p.targetDate)}</span>
                        <DueBadge due={p.targetDate} done={isProjectFinished(p)} />
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
          <PageControls list={projects} what="projects" />
        </>
      )}
    </nav>
  );
}

/* ---------- selected project ---------- */

interface NewRoundInput {
  kind: string | null;
  requestDate: string;
  dueDate: string | null;
  emailSubject: string;
  requestSummary: string;
  changeLines: string[];
}

type TabKey = "rounds" | "tasks" | "notes" | "research" | "agents";

function ProjectWorkspace({
  project,
  stages,
  onDeleted,
}: {
  project: Project;
  stages: Choices;
  onDeleted: () => void;
}) {
  const queryClient = useQueryClient();
  const confirm = useConfirm();
  const rounds = usePaged(keys.rounds(project.id), (skipToken) => fetchRounds(project.id, skipToken));
  const tasks = usePaged(keys.tasks(project.id), (skipToken) => fetchTasks(project.id, skipToken));
  const notes = usePaged(keys.notes(project.id), (skipToken) => fetchNotes(project.id, skipToken));
  const [tab, setTab] = useState<TabKey>("rounds");
  const [roundId, setRoundId] = useState<string | null>(null);
  const [logOpen, setLogOpen] = useState(false);
  const [pending, setPending] = useState<string | null>(null);

  const list = rounds.rows;
  const activeRound =
    list.find((r) => r.id === roundId) ?? list.filter((r) => !r.deliveredDate).at(-1) ?? list.at(-1) ?? null;
  const nextLabel = `v${
    list.reduce((max, r) => Math.max(max, Number.parseInt(r.label.replace(/\D/g, ""), 10) || 0), 0) + 1
  }`;
  const openTasks = tasks.rows.filter((t) => t.status !== DONE_STATUS);
  const overdueTasks = openTasks.filter((t) => isOverdue(t.dueDate, false));

  const refreshProjects = () => queryClient.invalidateQueries({ queryKey: ["projects"] });

  const setStage = async (stage: string) => {
    if (stage === project.stage || pending) return;
    setPending(`stage:${stage}`);
    const saved = await save(
      () => ProjectsService.update(project.id, { Stage: { Value: stage } }),
      "Couldn't update the stage.",
    );
    if (saved.ok) {
      await refreshProjects();
      toast.success(`Stage set to ${stage}`);
    }
    setPending(null);
  };

  const setStatus = async (status: string) => {
    if (status === project.status || pending) return;
    setPending(`status:${status}`);
    const saved = await save(
      () => ProjectsService.update(project.id, { Status: { Value: status } }),
      "Couldn't update the status.",
    );
    if (saved.ok) {
      await refreshProjects();
      toast.success(`Status set to ${status}`);
    }
    setPending(null);
  };

  const setTargetDate = async (date: string | null) => {
    if (date === project.targetDate || pending) return;
    setPending("target");
    const saved = await save(
      () => ProjectsService.update(project.id, date ? { TargetDate: toSpDate(date) } : clearDate("TargetDate")),
      "Couldn't update the submission target.",
    );
    if (saved.ok) await refreshProjects();
    setPending(null);
  };

  const deleteProject = async () => {
    if (!rounds.query.isSuccess || !tasks.query.isSuccess || !notes.query.isSuccess) {
      toast.error("This project's rounds, tasks and notes haven't loaded yet.");
      return;
    }
    if (list.length > 0 || rounds.paged) {
      toast.error("Delete this project's rounds first.");
      return;
    }
    if (tasks.paged || notes.paged) {
      toast.error("This project has more than one page of tasks or notes; remove some first.");
      return;
    }
    const related = await Promise.all([
      save(() => TimeService.getAll({ filter: `ProjectId eq ${Number(project.id)}`, top: 1 }), "Couldn't check project time entries."),
      save(() => RequestsService.getAll({ filter: `ProjectId eq ${Number(project.id)}`, top: 1 }), "Couldn't check project requests."),
      save(() => ActivityService.getAll({ filter: `ProjectId eq ${Number(project.id)}`, top: 1 }), "Couldn't check project history."),
    ]);
    if (related.some((result) => !result.ok)) return;
    if (related.some((result) => result.ok && result.data.length > 0)) {
      toast.error("This project has time entries or review history. Keep it to preserve those records.");
      return;
    }
    const ok = await confirm({
      title: `Delete ${project.title}?`,
      description: `The project${
        tasks.rows.length || notes.rows.length
          ? `, its ${plural(tasks.rows.length, "task")} and ${plural(notes.rows.length, "note")}`
          : ""
      } will be removed from SharePoint.`,
      confirmLabel: "Delete project",
      destructive: true,
    });
    if (!ok) return;
    setPending("delete");
    for (const t of tasks.rows) {
      if (!(await remove(() => TasksService.delete(t.id), () => TasksService.getAll({ filter: `ID eq ${Number(t.id)}`, top: 1 }), "Couldn't delete a task."))) {
        setPending(null);
        await queryClient.invalidateQueries({ queryKey: keys.tasks(project.id) });
        return;
      }
    }
    for (const n of notes.rows) {
      if (!(await remove(() => NotesService.delete(n.id), () => NotesService.getAll({ filter: `ID eq ${Number(n.id)}`, top: 1 }), "Couldn't delete a note."))) {
        setPending(null);
        await queryClient.invalidateQueries({ queryKey: keys.notes(project.id) });
        return;
      }
    }
    const gone = await remove(
      () => ProjectsService.delete(project.id),
      () => ProjectsService.getAll({ filter: `ID eq ${Number(project.id)}`, top: 1 }),
      "Couldn't delete the project.",
    );
    setPending(null);
    if (!gone) return;
    await refreshProjects();
    onDeleted();
    toast.success("Project deleted");
  };

  const logEmail = async (input: NewRoundInput) => {
    const saved = await save(
      () =>
        RoundsService.create({
          Title: nextLabel,
          ProjectId: Number(project.id),
          ...(input.kind ? { Kind: { Value: input.kind } } : {}),
          Received: toSpDate(input.requestDate),
          ...(input.dueDate ? { DueOn: toSpDate(input.dueDate) } : {}),
          EmailSubject: input.emailSubject,
          ...(input.requestSummary ? { Summary: input.requestSummary } : {}),
        }),
      "Couldn't log the PI email.",
    );
    if (!saved.ok || typeof saved.data?.ID !== "number") return false;
    const newRoundId = saved.data.ID;
    let failed = 0;
    for (const text of input.changeLines) {
      const change = await save(
        () => ChangesService.create({ Title: text, RoundId: newRoundId, Done: false }),
        `Couldn't save the change "${text}".`,
      );
      if (!change.ok) failed += 1;
    }
    await queryClient.invalidateQueries({ queryKey: keys.rounds(project.id) });
    setRoundId(String(newRoundId));
    setTab("rounds");
    if (failed === 0) toast.success(`PI email logged as round ${nextLabel}`);
    return true;
  };

  return (
    <>
      <ProjectHeader
        project={project}
        stages={stages}
        pending={pending}
        onStage={(stage) => void setStage(stage)}
        onStatus={(status) => void setStatus(status)}
        onTargetDate={(date) => void setTargetDate(date)}
        onLogEmail={() => setLogOpen(true)}
        onDelete={() => void deleteProject()}
      />

      <Tabs value={tab} onValueChange={(v) => setTab(v as TabKey)} className="space-y-4">
        <TabsList aria-label="Project sections" className="h-auto max-w-full flex-wrap justify-start gap-1 [&>button]:h-auto [&>button]:whitespace-normal">
          <TabsTrigger value="research">Research setup</TabsTrigger>
          <TabsTrigger value="rounds">
            Revision rounds
            {rounds.query.isSuccess && !rounds.paged && (
              <span className="tabular-nums text-muted-foreground">{list.length}</span>
            )}
          </TabsTrigger>
          <TabsTrigger value="tasks">
            Tasks
            {tasks.query.isSuccess && !tasks.paged && (
              <span className="tabular-nums text-muted-foreground">
                {openTasks.length}
                <span className="sr-only"> open</span>
              </span>
            )}
            {overdueTasks.length > 0 && (
              <span className="inline-flex items-center gap-1 text-xs text-red-700 dark:text-red-300">
                <span aria-hidden="true" className={cn("tone-dot size-1.5 rounded-full", TONE_DOT.danger)} />
                {overdueTasks.length} overdue
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="notes">
            Notes
            {notes.query.isSuccess && !notes.paged && (
              <span className="tabular-nums text-muted-foreground">{notes.rows.length}</span>
            )}
          </TabsTrigger>
          <TabsTrigger value="agents">Agent review</TabsTrigger>
        </TabsList>

        <TabsContent value="research"><ResearchDetails project={project} /></TabsContent>
        <TabsContent value="agents"><ProjectAgents project={project} tasks={tasks} /></TabsContent>
        <TabsContent value="rounds" className="space-y-5">
          <RoundTimeline
            rounds={rounds}
            activeId={activeRound?.id ?? null}
            onSelect={setRoundId}
            onLogEmail={() => setLogOpen(true)}
          />
          {activeRound && (
            <RoundDetail
              key={activeRound.id}
              round={activeRound}
              piName={project.piName}
              onDeleted={() => setRoundId(null)}
            />
          )}
        </TabsContent>
        <TabsContent value="tasks">
          <ProjectTasks projectId={project.id} tasks={tasks} />
        </TabsContent>
        <TabsContent value="notes">
          <ProjectNotes projectId={project.id} notes={notes} />
        </TabsContent>
      </Tabs>

      <Dialog open={logOpen} onOpenChange={setLogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Log PI email</DialogTitle>
            <DialogDescription>{project.title}</DialogDescription>
          </DialogHeader>
          <LogEmailForm
            nextLabel={nextLabel}
            preferredKind={list.length > 0 ? "PI revision" : "Initial report"}
            onSubmit={async (input) => {
              if (await logEmail(input)) setLogOpen(false);
            }}
            onCancel={() => setLogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}

function ProjectHeader({
  project,
  stages,
  pending,
  onStage,
  onStatus,
  onTargetDate,
  onLogEmail,
  onDelete,
}: {
  project: Project;
  stages: Choices;
  pending: string | null;
  onStage: (stage: string) => void;
  onStatus: (status: string) => void;
  onTargetDate: (date: string | null) => void;
  onLogEmail: () => void;
  onDelete: () => void;
}) {
  const order = stages.data ?? [];
  const statuses = useProjectChoices("Status");
  const stage = pending?.startsWith("stage:") ? pending.slice(6) : project.stage;
  const status = pending?.startsWith("status:") ? pending.slice(7) : project.status;
  const current = stage ? order.indexOf(stage) : -1;
  const tone = stageTone(stage);
  const busy = pending !== null;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 id="project-title" className="text-xl font-semibold tracking-tight text-balance">
            {project.projectNumber !== null && <span className="mr-2 tabular-nums text-muted-foreground">#{project.projectNumber}</span>}
            {project.title}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {project.piName}
            {project.target && ` · ${project.target}`}
          </p>
          <dl className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm">
            <div><dt className="inline text-muted-foreground">Database: </dt><dd className="inline">{project.database ?? "Not set"}</dd></div>
            {project.owner && <div><dt className="inline text-muted-foreground">Owner: </dt><dd className="inline">{project.owner}</dd></div>}
            {project.priority && <div><dt className="inline text-muted-foreground">Priority: </dt><dd className="inline">{project.priority}</dd></div>}
            {project.requestedBy && <div><dt className="inline text-muted-foreground">Requested by: </dt><dd className="inline">{project.requestedBy}</dd></div>}
          </dl>
          <ProjectTimeline project={project} />
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <Button onClick={onLogEmail}>
            <MailPlus aria-hidden="true" />
            Log PI email
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Delete project"
            title="Delete project"
            disabled={busy}
            onClick={onDelete}
          >
            <Trash2 aria-hidden="true" />
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-x-6 gap-y-3 text-sm">
        <div className="flex flex-wrap items-center gap-2">
          <Label htmlFor="project-status" className="font-medium">
            Status
          </Label>
          <ChoiceSelect
            id="project-status"
            choices={statuses}
            value={status}
            onChange={onStatus}
            what="statuses"
            size="sm"
            disabled={busy}
            className="w-36"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
        <Label htmlFor="target-date" className="font-medium">
          Submission target
        </Label>
        <OptionalDateField
          id="target-date"
          label="Submission target"
          value={project.targetDate}
          onChange={onTargetDate}
          disabled={busy}
          size="sm"
          emptyLabel="Not set"
        />
        <DueBadge due={project.targetDate} done={isProjectFinished(project)} />
        </div>
      </div>

      {stages.isPending ? (
        <Skeleton className="h-10 w-full" />
      ) : stages.isError ? (
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <span>Couldn&apos;t load the stages.</span>
          <RetryButton onRetry={() => void stages.refetch()} />
        </div>
      ) : order.length === 0 ? (
        <p className="text-sm text-muted-foreground">No stages are configured.</p>
      ) : (
        <ol aria-label="Submission progress" aria-busy={busy || undefined} className="flex flex-wrap gap-1">
          {order.map((s, i) => {
            const state = current < 0 ? "todo" : i < current ? "done" : i === current ? "current" : "todo";
            return (
              <li key={s} className="min-w-[6.5rem] flex-1">
                <button
                  type="button"
                  title={s}
                  disabled={busy}
                  aria-current={state === "current" ? "step" : undefined}
                  onClick={() => onStage(s)}
                  className="flex w-full flex-col gap-1.5 rounded-md p-1.5 text-left transition-colors hover:bg-muted/60 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-ring disabled:cursor-wait"
                >
                  <span aria-hidden="true" className="flex h-2 items-center">
                    <span
                      className={cn(
                        "w-full rounded-full",
                        state === "current" ? "h-2" : "h-1.5",
                        state === "todo" ? "stage-bar-empty bg-foreground/15" : cn("stage-bar-filled", TONE_DOT[tone]),
                      )}
                    />
                  </span>
                  <span
                    className={cn(
                      "flex min-w-0 items-center gap-1 text-xs",
                      state === "current" && "font-semibold",
                      state === "todo" && "text-muted-foreground",
                    )}
                  >
                    {state === "done" && <Check aria-hidden="true" className="size-3 shrink-0" />}
                    <span className="truncate">{s}</span>
                    {state === "done" && <span className="sr-only">, done</span>}
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}

/* ---------- revision timeline (the rounds list) ---------- */

function RoundTimeline({
  rounds,
  activeId,
  onSelect,
  onLogEmail,
}: {
  rounds: PagedList<Round>;
  activeId: string | null;
  onSelect: (id: string) => void;
  onLogEmail: () => void;
}) {
  const list = rounds.rows;
  const heading = (
    <h3 id="rounds-heading" className="text-sm font-semibold">
      Revision rounds
      {rounds.query.isSuccess && !rounds.paged && (
        <span className="ml-1.5 font-normal tabular-nums text-muted-foreground">{list.length}</span>
      )}
    </h3>
  );

  if (!rounds.query.isSuccess) {
    return (
      <section aria-labelledby="rounds-heading" className="rounded-xl border bg-card px-4 py-3">
        {heading}
        <ListStatus list={rounds} what="rounds" />
      </section>
    );
  }
  if (list.length === 0 && !rounds.paged) {
    return (
      <section aria-labelledby="rounds-heading" className="rounded-xl border bg-card px-4 py-3">
        {heading}
        <EmptyState
          icon={Mail}
          title="No rounds yet"
          className="py-10"
          action={
            <Button size="sm" onClick={onLogEmail}>
              <MailPlus aria-hidden="true" />
              Log PI email
            </Button>
          }
        />
      </section>
    );
  }

  const today = new Date();
  const todayDay = todayIso();
  const times: number[] = [];
  for (const r of list) {
    for (const d of [r.requestDate, r.deliveredDate, r.dueDate]) if (d) times.push(parseISO(d).getTime());
  }
  if (times.length === 0 || list.some((r) => r.requestDate && !r.deliveredDate)) times.push(today.getTime());
  const start = startOfMonth(new Date(Math.min(...times)));
  const end = endOfMonth(new Date(Math.max(...times)));
  const span = differenceInCalendarDays(end, start) + 1;
  const pct = (d: Date) => Math.min(100, Math.max(0, (differenceInCalendarDays(d, start) / span) * 100));
  const months = eachMonthOfInterval({ start, end });
  const todayPct = today >= start && today <= end ? pct(today) : null;
  const cols = "grid grid-cols-[8.5rem_minmax(0,1fr)_11rem] gap-4";

  return (
    <section aria-labelledby="rounds-heading" className="rounded-xl border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2 border-b px-4 py-3">
        {heading}
        <div aria-hidden="true" className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="tl-marker grid size-4 place-items-center rounded-full border-2 border-primary bg-card text-primary">
              <Mail className="size-2.5" />
            </span>
            PI email
          </span>
          <span className="flex items-center gap-1.5">
            <span className="tl-marker-done grid size-4 place-items-center rounded-full bg-primary text-primary-foreground">
              <Send className="size-2.5" />
            </span>
            Delivered
          </span>
          <span className="flex items-center gap-1.5">
            <span className="tl-due size-2.5 rotate-45 border-2 border-foreground bg-card" />
            Due back
          </span>
          <span className="flex items-center gap-1.5">
            <span className="tl-bar tl-bar-open h-2 w-5 rounded-full border border-primary" style={HATCH} />
            In progress
          </span>
        </div>
      </div>
      <div className="overflow-x-auto">
        <div className="min-w-[740px] p-2">
          <div aria-hidden="true" className={cn(cols, "px-2")}>
            <span />
            <div className="relative h-6">
              {months.map((m, i) => (
                <span
                  key={m.toISOString()}
                  className="absolute top-1 pl-1 text-[11px] whitespace-nowrap text-muted-foreground"
                  style={{ left: `${pct(m)}%` }}
                >
                  {format(m, i === 0 || m.getMonth() === 0 ? "MMM yyyy" : "MMM")}
                </span>
              ))}
              {todayPct !== null && (
                <span
                  className="absolute top-0.5 -translate-x-1/2 rounded bg-foreground px-1 text-[11px] leading-4 font-medium text-background"
                  style={{ left: `${todayPct}%` }}
                >
                  Today
                </span>
              )}
            </div>
            <span />
          </div>
          <ol>
            {list.map((r) => {
              const selected = r.id === activeId;
              const left = r.requestDate ? pct(parseISO(r.requestDate)) : null;
              const endPct = r.deliveredDate ? pct(parseISO(r.deliveredDate)) : r.requestDate ? pct(today) : null;
              const right = left !== null && endPct !== null ? Math.max(left, endPct) : endPct;
              const duePct = r.dueDate ? pct(parseISO(r.dueDate)) : null;
              const dueLate = !r.deliveredDate && isOverdue(r.dueDate, false, todayDay);
              const Icon = (r.kind && KIND_ICON[r.kind]) || Mail;
              const status = roundStatus(r);
              return (
                <li key={r.id}>
                  <button
                    type="button"
                    aria-current={selected ? "true" : undefined}
                    onClick={() => onSelect(r.id)}
                    className={cn(
                      cols,
                      "w-full items-center rounded-lg px-2 py-2 text-left transition-colors focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-ring",
                      selected ? "bg-muted" : "hover:bg-muted/50",
                    )}
                  >
                    <span className="flex min-w-0 items-center gap-2.5">
                      <span
                        aria-hidden="true"
                        className={cn("h-8 w-1 shrink-0 rounded-full", selected ? "bg-primary" : "bg-transparent")}
                      />
                      <span className="min-w-0">
                        <span className="block text-sm font-semibold tabular-nums">{r.label || "Round"}</span>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Icon aria-hidden="true" className="size-3 shrink-0" />
                          <span className="truncate">{r.kind ?? "No type"}</span>
                        </span>
                      </span>
                    </span>
                    <span aria-hidden="true" className="relative block h-9">
                      {months.slice(1).map((m) => (
                        <span
                          key={m.toISOString()}
                          className="absolute inset-y-0 w-px bg-border"
                          style={{ left: `${pct(m)}%` }}
                        />
                      ))}
                      {todayPct !== null && (
                        <span
                          className="tl-today absolute inset-y-0 border-l border-dashed border-foreground/50"
                          style={{ left: `${todayPct}%` }}
                        />
                      )}
                      {left !== null && right !== null && (
                        <span
                          className={cn(
                            "tl-bar absolute top-1/2 h-2 -translate-y-1/2 rounded-full",
                            r.deliveredDate ? "bg-primary" : "tl-bar-open border border-primary",
                          )}
                          style={{
                            left: `${left}%`,
                            width: `${Math.max(right - left, 0.75)}%`,
                            ...(r.deliveredDate ? {} : HATCH),
                          }}
                        />
                      )}
                      {duePct !== null && (
                        <span
                          className={cn(
                            "tl-due absolute top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rotate-45 border-2",
                            dueLate ? "tl-due-late border-red-700 bg-red-600 dark:border-red-300 dark:bg-red-400" : "border-foreground bg-card",
                          )}
                          style={{ left: `${duePct}%` }}
                        />
                      )}
                      {left !== null && (
                        <span
                          className="tl-marker absolute top-1/2 grid size-5 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-2 border-primary bg-card text-primary"
                          style={{ left: `${left}%` }}
                        >
                          <Mail className="size-2.5" />
                        </span>
                      )}
                      {r.deliveredDate && right !== null && (
                        <span
                          className="tl-marker-done absolute top-1/2 grid size-5 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-primary text-primary-foreground"
                          style={{ left: `${right}%` }}
                        >
                          <Send className="size-2.5" />
                        </span>
                      )}
                    </span>
                    <span className="min-w-0 text-right">
                      <span className="block text-xs font-medium tabular-nums">
                        {r.requestDate ? fmtDay(r.requestDate) : "No date"} <span aria-hidden="true">→</span>
                        <span className="sr-only">to</span> {r.deliveredDate ? fmtDay(r.deliveredDate) : "open"}
                        {r.dueDate && <span className="text-muted-foreground"> · due {fmtDay(r.dueDate)}</span>}
                      </span>
                      <span className="mt-1 flex flex-wrap justify-end gap-1">
                        <StatusBadge tone={status.tone}>{status.label}</StatusBadge>
                        <DueBadge due={r.dueDate} completedOn={r.deliveredDate} />
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
          {list.length === 0 && <p className="px-2 py-3 text-sm text-muted-foreground">No rounds on this page.</p>}
          <PageControls list={rounds} what="rounds" />
        </div>
      </div>
    </section>
  );
}

/* ---------- selected round: PI email, changes, time, delivery ---------- */

const SUBHEAD = "text-xs font-semibold tracking-wide text-muted-foreground uppercase";

function RoundDetail({ round, piName, onDeleted }: { round: Round; piName: string; onDeleted: () => void }) {
  const queryClient = useQueryClient();
  const confirm = useConfirm();
  const roundNumber = Number(round.id);
  const changes = usePaged(keys.changes(round.id), (skipToken) => fetchChanges(round.id, skipToken));
  const entries = usePaged(keys.time(round.id), (skipToken) => fetchTime(round.id, skipToken));
  const [doneOverride, setDoneOverride] = useState<Record<string, boolean>>({});
  const [changeText, setChangeText] = useState("");
  const [entryDate, setEntryDate] = useState(todayIso);
  const [entryHours, setEntryHours] = useState("");
  const [entryNote, setEntryNote] = useState("");
  const [entryCategory, setEntryCategory] = useState<string | null>(null);
  const manualSubmission = useRef<ManualSubmission<ManualTimePayload> | null>(null);
  const [pendingManualSave, setPendingManualSave] = useState(false);
  const categories = useTimeChoices("WorkCategory");
  const entryStates = useTimeChoices("EntryState");
  const [deliverDate, setDeliverDate] = useState(round.deliveredDate ?? todayIso());
  const [deliverNote, setDeliverNote] = useState(round.deliveryNote);
  const [busy, setBusy] = useState<string | null>(null);

  const refreshChanges = () => queryClient.invalidateQueries({ queryKey: keys.changes(round.id) });
  const refreshEntries = () => Promise.all([
    queryClient.invalidateQueries({ queryKey: keys.time(round.id) }),
    queryClient.invalidateQueries({ queryKey: ["time-report"] }),
  ]);
  const refreshRounds = () => queryClient.invalidateQueries({ queryKey: keys.rounds(round.projectId) });

  const doneCount = changes.rows.filter((c) => doneOverride[c.id] ?? c.done).length;
  const loggedHours = entries.rows.reduce((sum, e) => sum + (isRunning(e) ? 0 : e.hours ?? 0), 0);

  const toggleChange = async (c: ChangeItem, done: boolean) => {
    setDoneOverride((o) => ({ ...o, [c.id]: done }));
    const saved = await save(() => ChangesService.update(c.id, { Done: done }), "Couldn't update the change.");
    if (saved.ok) await refreshChanges();
    setDoneOverride((o) => {
      const rest = { ...o };
      delete rest[c.id];
      return rest;
    });
  };

  const addChange = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const text = changeText.trim();
    if (!text || busy) return;
    setBusy("change");
    const saved = await save(
      () => ChangesService.create({ Title: text, RoundId: roundNumber, Done: false }),
      "Couldn't add the change.",
    );
    if (saved.ok) {
      setChangeText("");
      await refreshChanges();
    }
    setBusy(null);
  };

  const removeChange = async (c: ChangeItem) => {
    if (await remove(() => ChangesService.delete(c.id), () => ChangesService.getAll({ filter: `ID eq ${Number(c.id)}`, top: 1 }), "Couldn't remove the change.")) {
      await refreshChanges();
    }
  };

  const addEntry = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const hours = Number.parseFloat(entryHours);
    const note = entryNote.trim();
    if (busy) return;
    if (!Number.isFinite(hours) || hours <= 0 || hours > 24) {
      toast.error("Enter hours between 0.25 and 24.");
      return;
    }
    if (!note || !entryCategory) {
      toast.error("Describe the work and choose a work category.");
      return;
    }
    setBusy("entry");
    const logged = configuredChoice(entryStates.data, ["Logged", "Stopped", "Completed"]);
    if (!manualSubmission.current?.attempted && !logged) {
      setBusy(null); toast.error("The logged-time state is not available. Reload the options before saving."); return;
    }
    if (!manualSubmission.current?.attempted) manualSubmission.current = newManualSubmission({
      Title: note, RoundId: roundNumber, ProjectId: Number(round.projectId), WorkDate: toSpDate(entryDate), Hours: hours,
      WorkCategory: { Value: entryCategory },
      ...(logged ? { EntryState: { Value: logged } } : {}),
    });
    const saved = await submitManualTime(manualSubmission.current);
    setPendingManualSave(!saved && manualSubmission.current.attempted);
    if (saved) {
      manualSubmission.current = null;
      setEntryHours("");
      setEntryNote("");
      await refreshEntries();
      toast.success(`Logged ${fmtHours(hours)} on ${round.label}`);
    }
    setBusy(null);
  };

  const removeEntry = async (entry: TimeEntry) => {
    if (isRunning(entry)) { toast.error("Stop and log the timer before deleting it."); return; }
    if (!(await confirm({ title: "Delete this time entry?", description: "Its hours will be removed from reports.", confirmLabel: "Delete entry", destructive: true }))) return;
    if (await remove(() => TimeService.delete(entry.id), () => TimeService.getAll({ filter: `ID eq ${Number(entry.id)}`, top: 1 }), "Couldn't remove the time entry.")) {
      await refreshEntries();
      await queryClient.invalidateQueries({ queryKey: ["time-report"] });
    }
  };

  const setDue = async (date: string | null) => {
    if (date === round.dueDate || busy) return;
    setBusy("due");
    const saved = await save(
      () => RoundsService.update(round.id, date ? { DueOn: toSpDate(date) } : clearDate("DueOn")),
      "Couldn't update the due date.",
    );
    if (saved.ok) await refreshRounds();
    setBusy(null);
  };

  const deliver = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (busy) return;
    setBusy("delivery");
    const note = deliverNote.trim();
    const saved = await save(
      () =>
        RoundsService.update(round.id, {
          Delivered: toSpDate(deliverDate),
          ...(note ? { DeliveryNote: note } : {}),
        }),
      "Couldn't save the delivery.",
    );
    if (saved.ok) {
      await refreshRounds();
      toast.success(`Round ${round.label} marked delivered`);
    }
    setBusy(null);
  };

  const reopen = async () => {
    if (busy) return;
    setBusy("delivery");
    const saved = await save(() => RoundsService.update(round.id, clearDate("Delivered")), "Couldn't reopen the round.");
    if (saved.ok) await refreshRounds();
    setBusy(null);
  };

  const deleteRound = async () => {
    if (busy || useAppStore.getState().timerBusy) {
      toast.error("Wait for the current timer or save operation to finish.");
      return;
    }
    if (!(await confirm({
      title: `Delete round ${round.label}?`,
      description: "Its changes and logged time entries are deleted from SharePoint too. A running timer prevents deletion.",
      confirmLabel: "Delete round",
      destructive: true,
    }))) return;
    // Acquire the same synchronous app-level lock used by timer start/stop.
    if (useAppStore.getState().timerBusy) {
      toast.error("A timer operation started while you were confirming. Try again after it finishes.");
      return;
    }
    useAppStore.getState().setTimerBusy(true);
    setBusy("round");
    try {
      const latestTime = await TimeService.getAll({ filter: `RoundId eq ${roundNumber}`, top: PAGE_SIZE });
      if (!latestTime.success) connectorFailure(latestTime.error);
      if (latestTime.skipToken) { toast.error("This round has more than one page of time entries; remove some first."); return; }
      const currentEntries = latestTime.data.map(toTimeEntry);
      if (currentEntries.some((item) => item === null)) throw new Error("Time entry identity could not be verified");
      if (currentEntries.some((item) => item && isRunning(item))) {
        toast.error("Stop this round's running timers before deleting it.");
        return;
      }
      const latestChanges = await ChangesService.getAll({ filter: `RoundId eq ${roundNumber}`, top: PAGE_SIZE });
      if (!latestChanges.success) connectorFailure(latestChanges.error);
      if (latestChanges.skipToken) { toast.error("This round has more than one page of changes; remove some first."); return; }
      for (const change of latestChanges.data) {
        if (typeof change.ID !== "number") throw new Error("Change identity could not be verified");
        if (!(await remove(
          () => ChangesService.delete(String(change.ID)),
          () => ChangesService.getAll({ filter: `ID eq ${change.ID}`, top: 1 }),
          "Couldn't remove a change.",
        ))) return;
      }
      for (const entry of currentEntries) {
        if (!entry) return;
        if (!(await remove(
          () => TimeService.delete(entry.id),
          () => TimeService.getAll({ filter: `ID eq ${Number(entry.id)}`, top: 1 }),
          "Couldn't remove a time entry.",
        ))) return;
      }
      const gone = await remove(
        () => RoundsService.delete(round.id),
        () => RoundsService.getAll({ filter: `ID eq ${Number(round.id)}`, top: 1 }),
        "Couldn't delete the round.",
      );
      if (gone) { onDeleted(); toast.success(`Round ${round.label} deleted`); }
    } catch (error) {
      console.error("Round deletion could not be completed", error);
      toast.error("Couldn't complete the deletion. Refresh the round before retrying.");
    } finally {
      // Even a partial cascade may have removed hours. Never leave report caches complete and stale.
      try {
        await Promise.all([
          refreshChanges(), refreshEntries(), refreshRounds(),
          queryClient.invalidateQueries({ queryKey: ["time-report"] }),
        ]);
      } finally {
        useAppStore.getState().setTimerBusy(false);
        setBusy(null);
      }
    }
  };

  return (
    <section aria-labelledby="round-heading" aria-busy={busy === "round" || undefined} className="rounded-xl border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b px-4 py-3">
        <h3 id="round-heading" className="text-base font-semibold">
          Round {round.label}
          {round.kind && <span className="font-normal text-muted-foreground"> · {round.kind}</span>}
        </h3>
        <Button variant="ghost" size="sm" disabled={busy !== null} onClick={() => void deleteRound()}>
          <Trash2 aria-hidden="true" />
          Delete round
        </Button>
      </div>

      <div className="grid divide-y lg:grid-cols-2 lg:divide-x lg:divide-y-0">
        <div className="min-w-0 space-y-6 p-4">
          <div className="space-y-1.5">
            <h4 className={SUBHEAD}>PI email</h4>
            <p className="text-sm font-medium">{round.emailSubject || "No subject"}</p>
            <p className="text-xs text-muted-foreground">
              From {piName || "PI"} · {round.requestDate ? `received ${fmtFull(round.requestDate)}` : "no received date"}
            </p>
            {round.requestSummary && (
              <p className="pt-1 text-sm leading-relaxed whitespace-pre-line">{round.requestSummary}</p>
            )}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <Label htmlFor="round-due" className="text-sm">
                Due back
              </Label>
              <OptionalDateField
                id="round-due"
                label="Due back"
                value={round.dueDate}
                onChange={(d) => void setDue(d)}
                disabled={busy === "due"}
                size="sm"
                emptyLabel="Not set"
              />
              <DueBadge due={round.dueDate} completedOn={round.deliveredDate} />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-baseline justify-between gap-2">
              <h4 className={SUBHEAD}>Changes</h4>
              {changes.query.isSuccess && !changes.paged && (
                <span className="text-xs tabular-nums text-muted-foreground">
                  {doneCount} of {changes.rows.length} done
                </span>
              )}
            </div>
            <ListStatus list={changes} what="changes" />
            {changes.query.isSuccess && changes.rows.length > 0 && (
              <ul className="divide-y rounded-lg border">
                {changes.rows.map((c) => {
                  const done = doneOverride[c.id] ?? c.done;
                  return (
                    <li key={c.id} className="flex items-center gap-3 py-1 pr-1 pl-3">
                      <Checkbox
                        id={`change-${c.id}`}
                        checked={done}
                        disabled={c.id in doneOverride}
                        onCheckedChange={(v) => void toggleChange(c, v === true)}
                      />
                      <Label
                        htmlFor={`change-${c.id}`}
                        className={cn(
                          "flex-1 py-1.5 text-sm leading-snug font-normal",
                          done && "line-through decoration-foreground/70",
                        )}
                      >
                        {c.text}
                      </Label>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        aria-label={`Remove change: ${c.text}`}
                        onClick={() => void removeChange(c)}
                      >
                        <Trash2 aria-hidden="true" />
                      </Button>
                    </li>
                  );
                })}
              </ul>
            )}
            <PageControls list={changes} what="changes" />
            <form onSubmit={(e) => void addChange(e)} className="flex gap-2">
              <Label htmlFor="new-change" className="sr-only">
                New change
              </Label>
              <Input
                id="new-change"
                value={changeText}
                onChange={(e) => setChangeText(e.target.value)}
                placeholder="Add a change"
              />
              <Button type="submit" variant="outline" disabled={busy === "change"}>
                <Plus aria-hidden="true" />
                Add
              </Button>
            </form>
          </div>
        </div>

        <div className="min-w-0 space-y-6 p-4">
          <div className="space-y-2">
            <div className="flex items-baseline justify-between gap-2">
              <h4 className={SUBHEAD}>Time log</h4>
              {entries.query.isSuccess && entries.rows.length > 0 && (
                <span className="text-xs tabular-nums text-muted-foreground">
                  {fmtHours(loggedHours)}
                  {entries.paged ? " on this page" : " total"}
                </span>
              )}
            </div>
            <StartWorkTimer projectId={round.projectId} roundId={round.id} note={entryNote.trim() || `Round ${round.label}`} />
            <ListStatus list={entries} what="time entries" />
            {entries.query.isSuccess && entries.rows.length > 0 && (
              <ul className="divide-y rounded-lg border">
                {entries.rows.map((entry) => (
                  <li
                    key={entry.id}
                    className="grid grid-cols-[3.75rem_3.75rem_minmax(0,1fr)_auto] items-center gap-2 py-1 pr-1 pl-3 text-sm"
                  >
                    <span className="tabular-nums text-muted-foreground">{entry.date ? fmtDay(entry.date) : "—"}</span>
                    <span className="font-medium tabular-nums">{isRunning(entry) ? "Running" : entry.hours === null ? "—" : fmtHours(entry.hours)}</span>
                    <span className="break-words">{entry.note}{entry.category && <span className="block text-xs text-muted-foreground">{entry.category}</span>}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon-sm"
                      aria-label={`Remove time entry: ${entry.note}`}
                      onClick={() => void removeEntry(entry)}
                    >
                      <Trash2 aria-hidden="true" />
                    </Button>
                  </li>
                ))}
              </ul>
            )}
            <PageControls list={entries} what="time entries" />
            <form
              onSubmit={(e) => void addEntry(e)}
              className="grid gap-2 sm:grid-cols-2"
            >
              <fieldset disabled={busy === "entry" || pendingManualSave} className="grid gap-2 border-0 p-0 sm:col-span-2 sm:grid-cols-2">
              <div className="sm:col-span-2"><Field id="entry-category" label="Work category"><ChoiceSelect id="entry-category" choices={categories} value={entryCategory} onChange={setEntryCategory} what="work categories" /></Field></div>
              <DateField id="entry-date" label="Work date" value={entryDate} onChange={setEntryDate} />
              <Label htmlFor="entry-hours" className="sr-only">
                Hours
              </Label>
              <Input
                id="entry-hours"
                type="number"
                inputMode="decimal"
                min="0.25"
                max="24"
                step="0.25"
                required
                placeholder="Hours"
                value={entryHours}
                onChange={(e) => setEntryHours(e.target.value)}
                className="tabular-nums"
              />
              <Label htmlFor="entry-note" className="sr-only">
                Work done
              </Label>
              <Input
                id="entry-note"
                required
                placeholder="Work done"
                value={entryNote}
                onChange={(e) => setEntryNote(e.target.value)}
              />
              </fieldset>
              {entryStates.isError && <ConnectorErrorState error={entryStates.error} connector={CONNECTOR} title="Couldn't load time states" className="py-2 sm:col-span-2" action={<RetryButton onRetry={() => void entryStates.refetch()} />} />}
              {entryStates.isPending && <p role="status" className="text-sm sm:col-span-2">Loading time states…</p>}
              {entryStates.isSuccess && !configuredChoice(entryStates.data, ["Logged", "Stopped", "Completed"]) && <p role="alert" className="text-sm sm:col-span-2">A logged-time state must be configured before saving manual hours.</p>}
              {pendingManualSave && <p role="alert" className="text-sm sm:col-span-2">The original entry is awaiting confirmation. Its values are retained here. Check the saved entry before leaving this round or logging the same hours again.</p>}
              <Button
                type="submit"
                variant="outline"
                disabled={busy === "entry" || !entryCategory || (!pendingManualSave && !configuredChoice(entryStates.data, ["Logged", "Stopped", "Completed"]))}
                className="h-auto justify-self-start whitespace-normal sm:col-span-2"
              >
                <Clock aria-hidden="true" />
                {pendingManualSave ? "Check saved entry" : "Log time"}
              </Button>
            </form>
          </div>

          <div className="space-y-2">
            <h4 className={SUBHEAD}>Delivery</h4>
            {round.deliveredDate ? (
              <div className="flex flex-wrap items-start justify-between gap-3 rounded-lg border px-3 py-2.5">
                <div className="min-w-0 space-y-0.5">
                  <p className="flex items-center gap-1.5 text-sm font-medium">
                    <Send aria-hidden="true" className="size-3.5" />
                    Sent {fmtFull(round.deliveredDate)}
                  </p>
                  {round.deliveryNote && <p className="text-sm">{round.deliveryNote}</p>}
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  disabled={busy === "delivery"}
                  onClick={() => void reopen()}
                >
                  <Undo2 aria-hidden="true" />
                  Reopen
                </Button>
              </div>
            ) : (
              <form onSubmit={(e) => void deliver(e)} className="grid gap-2 sm:grid-cols-[minmax(0,10rem)_minmax(0,1fr)]">
                <DateField id="deliver-date" label="Delivered on" value={deliverDate} onChange={setDeliverDate} />
                <Label htmlFor="deliver-note" className="sr-only">
                  What was sent
                </Label>
                <Input
                  id="deliver-note"
                  placeholder="What was sent"
                  value={deliverNote}
                  onChange={(e) => setDeliverNote(e.target.value)}
                />
                <Button type="submit" disabled={busy === "delivery"} className="justify-self-start sm:col-span-2">
                  <Send aria-hidden="true" />
                  Mark delivered
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- intake → start → last activity ---------- */

/** Latest logged work date for a project, from its newest time entry. */
function useLastActivity(projectId: string) {
  return useQuery({
    queryKey: ["last-activity", projectId],
    queryFn: async () => {
      const page = await fetchPage(
        TimeService.getAll({ filter: `ProjectId eq ${Number(projectId)}`, orderBy: ["WorkDate desc"], top: 1 }),
        toTimeEntry,
      );
      return page.rows[0]?.date ?? null;
    },
  });
}

function ProjectTimeline({ project }: { project: Project }) {
  const last = useLastActivity(project.id);
  const today = todayIso();
  const waited = project.intakeDate ? daysBetween(project.intakeDate, project.startDate ?? today) : null;
  const lastDate = last.data ?? null;
  const support = project.startDate && lastDate ? daysBetween(project.startDate, lastDate) : null;
  return (
    <dl className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-sm">
      <div><dt className="inline text-muted-foreground">Intake: </dt><dd className="inline tabular-nums">{project.intakeDate ? fmtFull(project.intakeDate) : "Not set"}</dd></div>
      <div><dt className="inline text-muted-foreground">Started: </dt><dd className="inline tabular-nums">{project.startDate ? fmtFull(project.startDate) : "Not started"}</dd></div>
      {waited !== null && (
        <div>
          <dt className="inline text-muted-foreground">{project.startDate ? "Wait to start: " : "Waiting: "}</dt>
          <dd className="inline tabular-nums">{plural(waited, "day")}</dd>
        </div>
      )}
      <div>
        <dt className="inline text-muted-foreground">Last worked: </dt>
        <dd className="inline tabular-nums">{last.isPending ? "…" : last.isError ? "Couldn't load" : lastDate ? fmtFull(lastDate) : "No time logged"}</dd>
      </div>
      {support !== null && <div><dt className="inline text-muted-foreground">Support time: </dt><dd className="inline tabular-nums">{plural(support, "day")}</dd></div>}
    </dl>
  );
}

/* ---------- dialogs ---------- */

function NewProjectForm({
  stages,
  onSubmit,
  onCancel,
}: {
  stages: Choices;
  onSubmit: (input: NewProjectInput) => Promise<void>;
  onCancel: () => void;
}) {
  const [stage, setStage] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [intakeDate, setIntakeDate] = useState<string | null>(todayIso);
  const nextNumber = useQuery({ queryKey: ["projects", "next-number"], queryFn: fetchNextProjectNumber, staleTime: 0 });
  const [numberText, setNumberText] = useState<string | null>(null);
  const shownNumber = numberText ?? (nextNumber.data !== undefined ? String(nextNumber.data) : "");
  const [targetDate, setTargetDate] = useState<string | null>(null);
  const [database, setDatabase] = useState<string | null>(null);
  const databases = useProjectChoices("DatabaseSource");
  const statuses = useProjectChoices("Status");
  const selectedStatus = status ?? (statuses.data?.includes(NEW_PROJECT_STATUS) ? NEW_PROJECT_STATUS : statuses.data?.[0] ?? null);
  const agentModes = useProjectChoices("AgentMode");
  const [busy, setBusy] = useState(false);
  const selectedStage = stage ?? stages.data?.[0] ?? null;
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const title = String(data.get("title") ?? "").trim();
    const piName = String(data.get("piName") ?? "").trim();
    const parsedNumber = shownNumber.trim() ? Number(shownNumber) : null;
    if (parsedNumber !== null && (!Number.isInteger(parsedNumber) || parsedNumber < 1)) {
      toast.error("Project number must be a whole number of 1 or more.");
      return;
    }
    if (!title || !piName || !database || busy) return;
    setBusy(true);
    await onSubmit({
      projectNumber: parsedNumber,
      intakeDate,
      requestedBy: String(data.get("requestedBy") ?? "").trim(),
      title,
      piName,
      database,
      agentMode: defaultAgentMode(agentModes.data),
      target: String(data.get("target") ?? "").trim(),
      stage: selectedStage,
      status: selectedStatus,
      targetDate,
    });
    setBusy(false);
  };
  return (
    <form onSubmit={(e) => void submit(e)} className="grid gap-4">
      <div className="grid gap-4 sm:grid-cols-[8rem_minmax(0,1fr)]">
        <Field id="np-number" label="Project #">
          <Input id="np-number" inputMode="numeric" value={shownNumber} onChange={(e) => setNumberText(e.target.value)} placeholder={nextNumber.isPending ? "Loading…" : undefined} />
        </Field>
        <Field id="np-title" label="Project title">
          <Input id="np-title" name="title" required maxLength={255} />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="np-pi" label="PI">
          <Input id="np-pi" name="piName" required maxLength={255} />
        </Field>
        <Field id="np-requested" label="Requested by">
          <Input id="np-requested" name="requestedBy" maxLength={255} />
        </Field>
      </div>
      <Field id="np-intake" label="Intake date">
        <OptionalDateField id="np-intake" label="Intake date" value={intakeDate} onChange={setIntakeDate} emptyLabel="Not set" />
      </Field>
      <Field id="np-database" label="EHR database"><ChoiceSelect id="np-database" choices={databases} value={database} onChange={setDatabase} what="databases" /></Field>
      <Field id="np-target" label="Target">
        <Input id="np-target" name="target" placeholder="Manuscript, abstract or grant" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="np-status" label="Status">
          <ChoiceSelect id="np-status" choices={statuses} value={selectedStatus} onChange={setStatus} what="statuses" />
        </Field>
        <Field id="np-stage" label="Stage">
          <ChoiceSelect id="np-stage" choices={stages} value={selectedStage} onChange={setStage} what="stages" />
        </Field>
        <Field id="np-target-date" label="Submission target">
          <OptionalDateField
            id="np-target-date"
            label="Submission target"
            value={targetDate}
            onChange={setTargetDate}
            emptyLabel="Not set"
          />
        </Field>
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={busy || !database}>
          <FolderPlus aria-hidden="true" />
          {busy ? "Adding…" : "Add project"}
        </Button>
      </DialogFooter>
    </form>
  );
}

function LogEmailForm({
  nextLabel,
  preferredKind,
  onSubmit,
  onCancel,
}: {
  nextLabel: string;
  preferredKind: string;
  onSubmit: (input: NewRoundInput) => Promise<void>;
  onCancel: () => void;
}) {
  const kinds = useKindChoices();
  const [date, setDate] = useState(todayIso);
  const [dueDate, setDueDate] = useState<string | null>(null);
  const [kind, setKind] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const options = kinds.data ?? [];
  const selectedKind = kind ?? (options.includes(preferredKind) ? preferredKind : (options[0] ?? null));
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const emailSubject = String(data.get("subject") ?? "").trim();
    if (!emailSubject || busy) return;
    const changeLines = String(data.get("changes") ?? "")
      .split("\n")
      .map((line) => line.replace(/^\s*(?:[-•*]|\d+[.)])\s*/, "").trim())
      .filter(Boolean);
    setBusy(true);
    await onSubmit({
      kind: selectedKind,
      requestDate: date,
      dueDate,
      emailSubject,
      requestSummary: String(data.get("summary") ?? "").trim(),
      changeLines,
    });
    setBusy(false);
  };
  return (
    <form onSubmit={(e) => void submit(e)} className="grid gap-4">
      <div className="grid gap-4 sm:grid-cols-3">
        <Field id="le-date" label="Received">
          <DateField id="le-date" label="Received" value={date} onChange={setDate} className="w-full" />
        </Field>
        <Field id="le-due" label="Due back">
          <OptionalDateField id="le-due" label="Due back" value={dueDate} onChange={setDueDate} emptyLabel="Not set" />
        </Field>
        <Field id="le-kind" label="Round type">
          <ChoiceSelect id="le-kind" choices={kinds} value={selectedKind} onChange={setKind} what="round types" />
        </Field>
      </div>
      <Field id="le-subject" label="Email subject">
        <Input id="le-subject" name="subject" required />
      </Field>
      <Field id="le-summary" label="Summary">
        <Textarea id="le-summary" name="summary" rows={2} />
      </Field>
      <Field id="le-changes" label="Requested changes, one per line">
        <Textarea id="le-changes" name="changes" rows={4} />
      </Field>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={busy}>
          <MailPlus aria-hidden="true" />
          {busy ? "Saving…" : `Log as ${nextLabel}`}
        </Button>
      </DialogFooter>
    </form>
  );
}
