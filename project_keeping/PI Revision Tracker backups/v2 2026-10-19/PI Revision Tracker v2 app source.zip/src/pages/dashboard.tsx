// Home: the live portfolio — status mix, the intake queue, work in progress, hours by month,
// and the reporting workbook. Everything is computed from the project and time lists.
import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { addDays, addMonths, format, parseISO, startOfMonth } from "date-fns";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { ChevronDown, Download, FolderPlus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ConnectorErrorState, EmptyState } from "@/components/states";
import { DateField, Field, RetryButton, StatusBadge } from "@/components/tracker-ui";
import { useProjectChoices } from "@/data/api";
import { fetchDashboardProjects, fetchDashboardTime, fetchReportProjects, fetchReportTime } from "@/data/report-api";
import { DONE_PROJECT_STATUS, type Project } from "@/data/tracker";
import { TONE_DOT, daysBetween, fmtFull, fmtHours, plural, projectStatusTone, todayIso } from "@/lib/format";
import { downloadReport, hoursByMonth, median, projectStats, round2, type ProjectStats, type ReportPeriod } from "@/lib/report";
import { CONNECTOR } from "@/lib/sp";
import { cn } from "@/lib/utils";

const FALLBACK_STATUSES = ["Pending", "Ongoing", "On hold", "Completed"];

const lastTwelveMonths = (today: string): ReportPeriod => ({
  from: format(startOfMonth(addMonths(parseISO(today), -11)), "yyyy-MM-dd"),
  through: today,
});

const projectLink = (p: Project) => ({ pathname: "/projects", search: `?project=${encodeURIComponent(p.id)}` });

function ProjectName({ project }: { project: Project }) {
  return (
    <Link
      to={projectLink(project)}
      className="font-medium underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
    >
      {project.projectNumber !== null && <span className="mr-1.5 tabular-nums text-muted-foreground">#{project.projectNumber}</span>}
      {project.title}
    </Link>
  );
}

export function DashboardPage() {
  const today = todayIso();
  const statusChoices = useProjectChoices("Status");
  const projects = useQuery({ queryKey: ["dashboard", "projects"], queryFn: fetchDashboardProjects, staleTime: 0 });
  const time = useQuery({ queryKey: ["dashboard", "time"], queryFn: fetchDashboardTime, staleTime: 0 });
  const window12 = lastTwelveMonths(today);

  const loading = projects.isPending || time.isPending;
  const error = projects.error ?? time.error;
  const stats = projects.data && time.data ? projectStats(projects.data.rows, time.data.rows, window12) : [];
  const months = time.data ? hoursByMonth(time.data.rows, window12) : [];

  return (
    <div className="mx-auto w-full max-w-[1440px] space-y-6 px-4 py-5 md:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="text-xl font-semibold tracking-tight">Dashboard</h1>
        <ReportControls today={today} />
      </div>

      {loading ? (
        <DashboardSkeleton />
      ) : error ? (
        <ConnectorErrorState
          error={error}
          connector={CONNECTOR}
          title="Couldn't load the dashboard"
          action={<RetryButton onRetry={() => { void projects.refetch(); void time.refetch(); }} />}
        />
      ) : stats.length === 0 ? (
        <EmptyState
          icon={FolderPlus}
          title="No projects yet"
          action={<Button asChild><Link to="/projects">Go to Projects</Link></Button>}
        />
      ) : (
        <>
          {(projects.data?.next || time.data?.next) && (
            <p role="status" className="rounded-md border bg-muted px-3 py-2 text-sm">
              The dashboard shows the {projects.data?.next ? `first ${projects.data.rows.length} projects` : "projects"}
              {time.data?.next ? ` and the ${time.data.rows.length} most recent time entries` : ""}. Use Download report for the complete figures.
            </p>
          )}
          <Portfolio stats={stats} statusOrder={statusChoices.data?.length ? statusChoices.data : FALLBACK_STATUSES} months={months} today={today} />
          <div className="grid gap-6 xl:grid-cols-2">
            <WaitingQueue stats={stats} today={today} />
            <InProgress stats={stats} today={today} />
          </div>
          <HoursByMonth months={months} />
        </>
      )}
    </div>
  );
}

/* ---------- portfolio band ---------- */

function Portfolio({
  stats,
  statusOrder,
  months,
  today,
}: {
  stats: ProjectStats[];
  statusOrder: string[];
  months: { month: string; hours: number }[];
  today: string;
}) {
  const counts = statusOrder.map((status) => ({ status, count: stats.filter((s) => s.project.status === status).length }));
  const unset = stats.filter((s) => !s.project.status || !statusOrder.includes(s.project.status)).length;
  const total = stats.length;
  const databases = [...new Set(stats.map((s) => s.project.database ?? "Not set"))]
    .map((name) => ({ name, count: stats.filter((s) => (s.project.database ?? "Not set") === name && s.project.status !== DONE_PROJECT_STATUS).length }))
    .filter((d) => d.count > 0)
    .sort((a, b) => b.count - a.count);
  const thisMonth = months.at(-1)?.hours ?? 0;
  const year = round2(months.reduce((n, m) => n + m.hours, 0));
  const yearAgo = format(addDays(parseISO(today), -365), "yyyy-MM-dd");
  const recentWaits = stats.flatMap((s) => (s.waitDays !== null && s.project.startDate && s.project.startDate >= yearAgo ? [s.waitDays] : []));
  const medianWait = median(recentWaits);

  return (
    <section aria-labelledby="portfolio-heading" className="space-y-4 rounded-xl border bg-card p-4 sm:p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 id="portfolio-heading" className="text-base font-semibold">
          Portfolio <span className="ml-1 font-normal tabular-nums text-muted-foreground">{plural(total, "project")}</span>
        </h2>
        <dl className="flex flex-wrap gap-x-6 gap-y-1 text-sm">
          <div className="flex items-baseline gap-2"><dt className="text-muted-foreground">Hours this month</dt><dd className="font-semibold tabular-nums">{fmtHours(thisMonth)}</dd></div>
          <div className="flex items-baseline gap-2"><dt className="text-muted-foreground">Hours, last 12 months</dt><dd className="font-semibold tabular-nums">{fmtHours(year)}</dd></div>
          <div className="flex items-baseline gap-2">
            <dt className="text-muted-foreground">Median wait to start (started in last year)</dt>
            <dd className="font-semibold tabular-nums">{medianWait === null ? "—" : plural(Math.round(medianWait), "day")}</dd>
          </div>
        </dl>
      </div>

      <div aria-hidden="true" className="flex h-4 w-full overflow-hidden rounded-full bg-foreground/10">
        {counts.filter((c) => c.count > 0).map((c) => (
          <span key={c.status} className={cn("h-full", TONE_DOT[projectStatusTone(c.status)])} style={{ width: `${(c.count / total) * 100}%` }} />
        ))}
      </div>
      <ul aria-label="Projects by status" className="flex flex-wrap gap-2">
        {counts.map((c) => (
          <li key={c.status}>
            <Link
              to={{ pathname: "/projects", search: `?status=${encodeURIComponent(c.status)}` }}
              className="inline-flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm hover:bg-muted/60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
            >
              <span aria-hidden="true" className={cn("size-2.5 rounded-full", TONE_DOT[projectStatusTone(c.status)])} />
              <span className="font-semibold tabular-nums">{c.count}</span>
              {c.status}
            </Link>
          </li>
        ))}
        {unset > 0 && <li className="inline-flex items-center px-3 py-1.5 text-sm text-muted-foreground">{unset} without a status</li>}
      </ul>
      {databases.length > 0 && (
        <p className="text-sm">
          <span className="text-muted-foreground">Open projects by database: </span>
          {databases.map((d, i) => (
            <span key={d.name}>
              {i > 0 && " · "}
              <span className="tabular-nums font-medium">{d.count}</span> {d.name}
            </span>
          ))}
        </p>
      )}
    </section>
  );
}

/* ---------- intake queue ---------- */

function WaitingQueue({ stats, today }: { stats: ProjectStats[]; today: string }) {
  const queue = stats
    .filter((s) => s.project.status === "Pending")
    .map((s) => ({ ...s, waiting: s.project.intakeDate ? daysBetween(s.project.intakeDate, today) : null }))
    .sort((a, b) => (b.waiting ?? -1) - (a.waiting ?? -1));
  const longest = Math.max(1, ...queue.map((q) => q.waiting ?? 0));
  return (
    <section aria-labelledby="queue-heading" className="rounded-xl border bg-card">
      <h2 id="queue-heading" className="border-b px-4 py-3 text-base font-semibold">
        Waiting to start <span className="ml-1 font-normal tabular-nums text-muted-foreground">{queue.length}</span>
      </h2>
      {queue.length === 0 ? (
        <p className="px-4 py-6 text-sm text-muted-foreground">No pending intakes.</p>
      ) : (
        <ol className="divide-y">
          {queue.map((q) => (
            <li key={q.project.id} className="space-y-1.5 px-4 py-3">
              <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                <span className="min-w-0 break-words text-sm"><ProjectName project={q.project} /></span>
                <span className="shrink-0 text-sm tabular-nums">{q.waiting === null ? "Intake date not set" : `Waiting ${plural(q.waiting, "day")}`}</span>
              </div>
              {q.waiting !== null && (
                <span aria-hidden="true" className="block h-1.5 w-full rounded-full bg-foreground/10">
                  <span className={cn("block h-full rounded-full", TONE_DOT.pending)} style={{ width: `${Math.max(2, (q.waiting / longest) * 100)}%` }} />
                </span>
              )}
              <p className="text-xs text-muted-foreground">
                {[q.project.piName, q.project.database, q.project.requestedBy && `requested by ${q.project.requestedBy}`, q.project.intakeDate && `intake ${fmtFull(q.project.intakeDate)}`, q.project.owner && `owner ${q.project.owner}`]
                  .filter(Boolean)
                  .join(" · ")}
              </p>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}

/* ---------- work in progress ---------- */

function InProgress({ stats, today }: { stats: ProjectStats[]; today: string }) {
  const rows = stats
    .filter((s) => s.project.status === "Ongoing" || s.project.status === "On hold")
    .sort((a, b) => (b.lastActivity ?? "").localeCompare(a.lastActivity ?? ""));
  return (
    <section aria-labelledby="progress-heading" className="rounded-xl border bg-card">
      <h2 id="progress-heading" className="border-b px-4 py-3 text-base font-semibold">
        In progress <span className="ml-1 font-normal tabular-nums text-muted-foreground">{rows.length}</span>
      </h2>
      {rows.length === 0 ? (
        <p className="px-4 py-6 text-sm text-muted-foreground">No ongoing projects.</p>
      ) : (
        <ul className="divide-y">
          {rows.map((s) => {
            const idle = s.lastActivity ? daysBetween(s.lastActivity, today) : null;
            return (
              <li key={s.project.id} className="space-y-1.5 px-4 py-3">
                <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                  <span className="min-w-0 break-words text-sm"><ProjectName project={s.project} /></span>
                  <span className="flex shrink-0 items-center gap-2">
                    {s.project.status === "On hold" && <StatusBadge tone={projectStatusTone("On hold")}>On hold</StatusBadge>}
                    <span className="text-sm font-semibold tabular-nums">{fmtHours(s.totalHours)}</span>
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {[s.project.piName, s.project.database, s.project.stage ?? "No stage", s.project.startDate && `started ${fmtFull(s.project.startDate)}`]
                    .filter(Boolean)
                    .join(" · ")}
                </p>
                <p className="text-xs">
                  {s.lastActivity ? (
                    <>Last worked {fmtFull(s.lastActivity)}{idle !== null && idle > 0 && <span className="text-muted-foreground"> · {plural(idle, "day")} ago</span>}</>
                  ) : (
                    <span className="text-muted-foreground">No time logged yet</span>
                  )}
                </p>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

/* ---------- hours by month ---------- */

const chartConfig = { hours: { label: "Hours", color: "var(--primary)" } } satisfies ChartConfig;

function HoursByMonth({ months }: { months: { month: string; label: string; hours: number }[] }) {
  const total = round2(months.reduce((n, m) => n + m.hours, 0));
  const busiest = months.reduce<{ label: string; hours: number } | null>((best, m) => (!best || m.hours > best.hours ? m : best), null);
  const short = months.map((m) => ({ ...m, short: format(parseISO(`${m.month}-01`), "MMM") }));
  return (
    <section aria-labelledby="hours-heading" className="space-y-3 rounded-xl border bg-card p-4 sm:p-5">
      <h2 id="hours-heading" className="text-base font-semibold">Hours logged by month</h2>
      <p className="text-sm">
        {fmtHours(total)} over the last 12 months
        {busiest && busiest.hours > 0 && <> · busiest month {busiest.label} ({fmtHours(busiest.hours)})</>}
      </p>
      <ChartContainer config={chartConfig} className="h-56 w-full" role="img" aria-label={`Hours logged per month, last 12 months, ${fmtHours(total)} in total`}>
        <BarChart data={short} margin={{ left: 0, right: 8, top: 8 }}>
          <CartesianGrid vertical={false} />
          <XAxis dataKey="short" tickLine={false} axisLine={false} />
          <YAxis tickLine={false} axisLine={false} width={36} />
          <ChartTooltip content={<ChartTooltipContent labelKey="label" />} />
          <Bar dataKey="hours" fill="var(--color-hours)" radius={4} />
        </BarChart>
      </ChartContainer>
      <Collapsible>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="group">
            Hours by month as a table
            <ChevronDown aria-hidden="true" className="transition-transform group-data-[state=open]:rotate-180" />
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <Table>
            <TableCaption className="sr-only">Hours logged per month over the last 12 months</TableCaption>
            <TableHeader><TableRow><TableHead scope="col">Month</TableHead><TableHead scope="col" className="text-right">Hours</TableHead></TableRow></TableHeader>
            <TableBody>
              {months.map((m) => (
                <TableRow key={m.month}><TableCell>{m.label}</TableCell><TableCell className="text-right tabular-nums">{m.hours}</TableCell></TableRow>
              ))}
            </TableBody>
          </Table>
        </CollapsibleContent>
      </Collapsible>
    </section>
  );
}

/* ---------- report ---------- */

function ReportControls({ today }: { today: string }) {
  const initial = lastTwelveMonths(today);
  const [from, setFrom] = useState(initial.from);
  const [through, setThrough] = useState(initial.through);
  const [busy, setBusy] = useState(false);
  const invalid = from > through;
  const run = async () => {
    if (busy || invalid) return;
    setBusy(true);
    try {
      const [projects, entries] = await Promise.all([fetchReportProjects(), fetchReportTime()]);
      const fileName = await downloadReport(projects, entries, { from, through });
      toast.success(`Report downloaded: ${fileName}`);
    } catch (error) {
      console.error("Report failed", error);
      toast.error(error instanceof Error && error.message.startsWith("There are too many rows") ? error.message : "Couldn't prepare the report. Try again.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <section aria-label="Report" className="flex flex-wrap items-end gap-2">
      <Field id="report-from" label="Report from"><DateField id="report-from" label="Report from" value={from} onChange={setFrom} /></Field>
      <Field id="report-through" label="Through"><DateField id="report-through" label="Report through" value={through} onChange={setThrough} /></Field>
      <Button onClick={() => void run()} disabled={busy || invalid}>
        <Download aria-hidden="true" />
        {busy ? "Preparing…" : "Download report"}
      </Button>
      {invalid && <p role="alert" className="w-full text-sm">The start date must be on or before the end date.</p>}
    </section>
  );
}

function DashboardSkeleton() {
  return (
    <div role="status" aria-label="Loading the dashboard" className="space-y-6">
      <Skeleton className="h-40 w-full rounded-xl" />
      <div className="grid gap-6 xl:grid-cols-2">
        <Skeleton className="h-72 w-full rounded-xl" />
        <Skeleton className="h-72 w-full rounded-xl" />
      </div>
      <Skeleton className="h-64 w-full rounded-xl" />
    </div>
  );
}
