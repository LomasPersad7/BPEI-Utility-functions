// Reads for the dashboard and the on-demand report.
import { ProjectsService, TimeService } from "@/data/api";
import { toProject, toTimeEntry, type Project, type TimeEntry } from "@/data/tracker";
import { fetchPage, type Page } from "@/lib/sp";

/** Dashboard reads: one large page each; `next` tells the page that more rows exist. */
export const DASHBOARD_PROJECTS = 1000;
export const DASHBOARD_TIME = 2000;

export const fetchDashboardProjects = (): Promise<Page<Project>> =>
  fetchPage(ProjectsService.getAll({ orderBy: ["ProjectNumber desc", "ID desc"], top: DASHBOARD_PROJECTS }), toProject);

/** Newest work first, so a partial page still covers recent months. */
export const fetchDashboardTime = (): Promise<Page<TimeEntry>> =>
  fetchPage(TimeService.getAll({ orderBy: ["WorkDate desc", "ID desc"], top: DASHBOARD_TIME }), toTimeEntry);

const MAX_REPORT_PAGES = 50;

/** User-requested report: follows the connector's continuation to the end, or fails visibly. */
async function fetchEveryPage<T>(load: (skipToken?: string) => Promise<Page<T>>): Promise<T[]> {
  const rows: T[] = [];
  let token: string | undefined;
  for (let page = 0; page < MAX_REPORT_PAGES; page++) {
    const result = await load(token);
    rows.push(...result.rows);
    if (!result.next) return rows;
    token = result.next;
  }
  throw new Error("There are too many rows for one report. Narrow the reporting period and try again.");
}

export const fetchReportProjects = () =>
  fetchEveryPage((skipToken) =>
    fetchPage(ProjectsService.getAll({ orderBy: ["ProjectNumber desc", "ID desc"], top: 500, skipToken }), toProject),
  );

export const fetchReportTime = () =>
  fetchEveryPage((skipToken) => fetchPage(TimeService.getAll({ orderBy: ["ID asc"], top: 1000, skipToken }), toTimeEntry));
