// Entity reads shared by every page. Keys are shared so the Projects and
// Overview pages reuse each other's cached first pages and invalidations.
import {
  PAGE_SIZE,
  toChange,
  toNote,
  toProject,
  toRound,
  toTask,
  toTimeEntry,
} from "@/data/tracker";
import { fetchPage, useChoices } from "@/lib/sp";
import {
  Change_items_9426df72Service as ChangesService,
  Notes_9426df72Service as NotesService,
  Projects_9426df72Service as ProjectsService,
  Revision_rounds_9426df72Service as RoundsService,
  Tasks_9426df72Service as TasksService,
  Time_log_9426df72Service as TimeService,
} from "../../generated";

export { ChangesService, NotesService, ProjectsService, RoundsService, TasksService, TimeService };

export const keys = {
  projects: (pageSize: number) => ["projects", { pageSize }] as const,
  rounds: (projectId: string) => ["rounds", projectId] as const,
  tasks: (projectId: string) => ["tasks", projectId] as const,
  notes: (projectId: string) => ["notes", projectId] as const,
  changes: (roundId: string) => ["changes", roundId] as const,
  time: (roundId: string) => ["time", roundId] as const,
};

/** The first-page key usePaged builds for a list key. */
export const firstPage = (key: readonly unknown[]) => [...key, { skipToken: undefined }];

const byProject = (projectId: string) => `ProjectId eq ${Number(projectId)}`;
const byRound = (roundId: string) => `RoundId eq ${Number(roundId)}`;

const choiceEq = (field: string, value: string) => `${field} eq '${value.replaceAll("'", "''")}'`;

export interface ProjectFilters {
  database?: string | null;
  status?: string | null;
  /** Leave out projects whose Status is this value (e.g. Completed). */
  excludeStatus?: string | null;
}

/** Newest project number first; projects without a number sort last. */
export const fetchProjects = (pageSize: number, skipToken?: string, filters: ProjectFilters = {}) => {
  const clauses = [
    ...(filters.database ? [choiceEq("DatabaseSource", filters.database)] : []),
    ...(filters.status ? [choiceEq("Status", filters.status)] : []),
    ...(filters.excludeStatus ? [`Status ne '${filters.excludeStatus.replaceAll("'", "''")}'`] : []),
  ];
  return fetchPage(ProjectsService.getAll({
    filter: clauses.length ? clauses.join(" and ") : undefined,
    orderBy: ["ProjectNumber desc", "ID desc"], top: pageSize, skipToken,
  }), toProject);
};

/** One more than the highest project number in the list (1 when none). */
export async function fetchNextProjectNumber(): Promise<number> {
  const page = await fetchPage(ProjectsService.getAll({ orderBy: ["ProjectNumber desc"], top: 1 }), toProject);
  return (page.rows[0]?.projectNumber ?? 0) + 1;
}

export const fetchRounds = (projectId: string, skipToken?: string) =>
  fetchPage(
    RoundsService.getAll({ filter: byProject(projectId), orderBy: ["Received asc"], top: PAGE_SIZE, skipToken }),
    toRound,
  );

export const fetchTasks = (projectId: string, skipToken?: string) =>
  fetchPage(
    TasksService.getAll({ filter: byProject(projectId), orderBy: ["ID asc"], top: PAGE_SIZE, skipToken }),
    toTask,
  );

export const fetchNotes = (projectId: string, skipToken?: string) =>
  fetchPage(
    NotesService.getAll({ filter: byProject(projectId), orderBy: ["NoteDate desc", "ID desc"], top: PAGE_SIZE, skipToken }),
    toNote,
  );

export const fetchChanges = (roundId: string, skipToken?: string) =>
  fetchPage(
    ChangesService.getAll({ filter: byRound(roundId), orderBy: ["ID asc"], top: PAGE_SIZE, skipToken }),
    toChange,
  );

export const fetchTime = (roundId: string, skipToken?: string) =>
  fetchPage(
    TimeService.getAll({ filter: byRound(roundId), orderBy: ["WorkDate asc"], top: PAGE_SIZE, skipToken }),
    toTimeEntry,
  );

export const useStageChoices = () =>
  useChoices(["choices", "Stage"], () => ProjectsService.getReferencedEntity("", "Stage"));
export const useKindChoices = () =>
  useChoices(["choices", "Kind"], () => RoundsService.getReferencedEntity("", "Kind"));
export const usePriorityChoices = () =>
  useChoices(["choices", "TaskPriority"], () => TasksService.getReferencedEntity("", "TaskPriority"));
export const useStatusChoices = () =>
  useChoices(["choices", "TaskStatus"], () => TasksService.getReferencedEntity("", "TaskStatus"));
export const useNoteTypeChoices = () =>
  useChoices(["choices", "NoteType"], () => NotesService.getReferencedEntity("", "NoteType"));
export const useProjectChoices = (field: "DatabaseSource" | "ProjectPriority" | "AccessStatus" | "ExtractStatus" | "AgentMode" | "Status") =>
  useChoices(["choices", "projects", field], () => ProjectsService.getReferencedEntity("", field));
export const useTaskChoices = (field: "Workstream" | "Milestone") =>
  useChoices(["choices", "tasks", field], () => TasksService.getReferencedEntity("", field));
export const useTimeChoices = (field: "WorkCategory" | "EntryState") =>
  useChoices(["choices", "time", field], () => TimeService.getReferencedEntity("", field));
