// PI Revision Tracker domain types and SharePoint adapters.
// Linked SharePoint lists: projects → revision rounds / tasks / notes (ProjectId),
// rounds → change items / time log (RoundId). Ids are the SharePoint item IDs.
import type { Change_items_9426df72Read } from "../../generated/models/Change_items_9426df72Model";
import type { Notes_9426df72Read } from "../../generated/models/Notes_9426df72Model";
import type { Projects_9426df72Read } from "../../generated/models/Projects_9426df72Model";
import type { Revision_rounds_9426df72Read } from "../../generated/models/Revision_rounds_9426df72Model";
import type { Tasks_9426df72Read } from "../../generated/models/Tasks_9426df72Model";
import type { Time_log_9426df72Read } from "../../generated/models/Time_log_9426df72Model";

export interface Project {
  id: string;
  /** Chronological biostatistics project number, or null when unset. */
  projectNumber: number | null;
  title: string;
  piName: string;
  target: string;
  stage: string | null;
  /** Configured project Status choice (Pending, Ongoing, On hold, Completed), or null when unset. */
  status: string | null;
  /** Date the formal intake form was submitted (yyyy-MM-dd). */
  intakeDate: string | null;
  /** Date work on the project started (yyyy-MM-dd). */
  startDate: string | null;
  requestedBy: string;
  intakeSource: string;
  researchOutput: string;
  targetDate: string | null;
  database: string | null;
  owner: string;
  priority: string | null;
  studyReference: string;
  cohortVersion: string;
  accessStatus: string | null;
  extractStatus: string | null;
  nextAction: string;
  agentMode: string | null;
}

/** One iteration: a PI email asking for work, and the delivery that answered it. */
export interface Round {
  id: string;
  projectId: string;
  label: string;
  /** Configured Kind choice, or null when unset. */
  kind: string | null;
  /** Date the PI email arrived (yyyy-MM-dd). */
  requestDate: string | null;
  emailSubject: string;
  requestSummary: string;
  /** Date the PI needs the update back (yyyy-MM-dd). */
  dueDate: string | null;
  /** Date the update was sent back (yyyy-MM-dd); null while open. */
  deliveredDate: string | null;
  deliveryNote: string;
}

export interface ChangeItem {
  id: string;
  roundId: string;
  text: string;
  done: boolean;
}

export interface TimeEntry {
  id: string;
  roundId: string | null;
  projectId: string | null;
  date: string | null;
  hours: number | null;
  note: string;
  category: string | null;
  state: string | null;
  startedOn: string | null;
  stoppedOn: string | null;
  entryKey: string | null;
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  /** Configured TaskPriority choice. */
  priority: string | null;
  /** Configured TaskStatus choice. */
  status: string | null;
  dueDate: string | null;
  assignedTo: string;
  workstream: string | null;
  milestone: string | null;
  blockedReason: string;
}

export interface Note {
  id: string;
  projectId: string;
  text: string;
  /** Configured NoteType choice. */
  type: string | null;
  date: string | null;
}

/** Rows requested per page; further rows load page by page. */
export const PAGE_SIZE = 100;

/** The configured Stage choice that marks a finished project. */
export const FINAL_STAGE = "Accepted";

/** The configured project Status choice that marks a finished project. */
export const DONE_PROJECT_STATUS = "Completed";

/** The configured project Status choice a new project starts with. */
export const NEW_PROJECT_STATUS = "Pending";

/** "#47 Title" for text contexts (selects, exports, dialogs). */
export function projectLabel(project: Pick<Project, "projectNumber" | "title">): string {
  return project.projectNumber !== null ? `#${project.projectNumber} ${project.title}` : project.title;
}

/** A project is finished when its status is Completed or its paper reached the final stage. */
export function isProjectFinished(project: Pick<Project, "status" | "stage">): boolean {
  return project.status === DONE_PROJECT_STATUS || project.stage === FINAL_STAGE;
}

/** The configured TaskStatus choice that marks a finished task. */
export const DONE_STATUS = "Done";

/** yyyy-MM-dd from a SharePoint date/time value; null when absent or unrecognized. */
export function dateOnly(value: string | null | undefined): string | null {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}/.test(value) ? value.slice(0, 10) : null;
}

/** Noon UTC keeps the calendar day stable across site time zones. */
export function toSpDate(isoDay: string): string {
  return `${isoDay}T12:00:00Z`;
}

/** Plain text from a multi-line field that SharePoint may return as rich-text HTML. */
export function plainText(value: string | null | undefined): string {
  if (!value) return "";
  if (!value.trimStart().startsWith("<")) return value;
  const doc = new DOMParser().parseFromString(value, "text/html");
  return (doc.body.textContent ?? "").trim();
}

export function toProject(r: Projects_9426df72Read): Project | null {
  if (typeof r.ID !== "number") return null;
  return {
    id: String(r.ID),
    projectNumber: typeof r.ProjectNumber === "number" && Number.isFinite(r.ProjectNumber) ? r.ProjectNumber : null,
    title: r.Title ?? "",
    piName: r.PI ?? "",
    target: r.Target ?? "",
    stage: r.Stage?.Value ?? null,
    status: r.Status?.Value ?? null,
    intakeDate: dateOnly(r.IntakeDate),
    startDate: dateOnly(r.StartDate),
    requestedBy: r.RequestedBy ?? "",
    intakeSource: r.IntakeSource ?? "",
    researchOutput: r.ResearchOutput ?? "",
    targetDate: dateOnly(r.TargetDate),
    database: r.DatabaseSource?.Value ?? null,
    owner: r.ProjectOwner ?? "",
    priority: r.ProjectPriority?.Value ?? null,
    studyReference: r.StudyReference ?? "",
    cohortVersion: r.CohortVersion ?? "",
    accessStatus: r.AccessStatus?.Value ?? null,
    extractStatus: r.ExtractStatus?.Value ?? null,
    nextAction: plainText(r.NextAction),
    agentMode: r.AgentMode?.Value ?? null,
  };
}

export function toRound(r: Revision_rounds_9426df72Read): Round | null {
  if (typeof r.ID !== "number" || typeof r.ProjectId !== "number") return null;
  return {
    id: String(r.ID),
    projectId: String(r.ProjectId),
    label: r.Title ?? "",
    kind: r.Kind?.Value ?? null,
    requestDate: dateOnly(r.Received),
    emailSubject: r.EmailSubject ?? "",
    requestSummary: plainText(r.Summary),
    dueDate: dateOnly(r.DueOn),
    deliveredDate: dateOnly(r.Delivered),
    deliveryNote: r.DeliveryNote ?? "",
  };
}

export function toChange(r: Change_items_9426df72Read): ChangeItem | null {
  if (typeof r.ID !== "number" || typeof r.RoundId !== "number") return null;
  return { id: String(r.ID), roundId: String(r.RoundId), text: r.Title ?? "", done: r.Done === true };
}

export function toTimeEntry(r: Time_log_9426df72Read): TimeEntry | null {
  if (typeof r.ID !== "number") return null;
  return {
    id: String(r.ID),
    roundId: typeof r.RoundId === "number" ? String(r.RoundId) : null,
    projectId: typeof r.ProjectId === "number" ? String(r.ProjectId) : null,
    date: dateOnly(r.WorkDate),
    hours: typeof r.Hours === "number" && Number.isFinite(r.Hours) ? r.Hours : null,
    note: r.Title ?? "",
    category: r.WorkCategory?.Value ?? null,
    state: r.EntryState?.Value ?? null,
    startedOn: r.StartedOn ?? null,
    stoppedOn: r.StoppedOn ?? null,
    entryKey: r.EntryKey ?? null,
  };
}

export function toTask(r: Tasks_9426df72Read): Task | null {
  if (typeof r.ID !== "number" || typeof r.ProjectId !== "number") return null;
  return {
    id: String(r.ID),
    projectId: String(r.ProjectId),
    title: r.Title ?? "",
    priority: r.TaskPriority?.Value ?? null,
    status: r.TaskStatus?.Value ?? null,
    dueDate: dateOnly(r.DueOn),
    assignedTo: r.AssignedTo ?? "",
    workstream: r.Workstream?.Value ?? null,
    milestone: r.Milestone?.Value ?? null,
    blockedReason: plainText(r.BlockedReason),
  };
}

export function toNote(r: Notes_9426df72Read): Note | null {
  if (typeof r.ID !== "number" || typeof r.ProjectId !== "number") return null;
  return {
    id: String(r.ID),
    projectId: String(r.ProjectId),
    text: plainText(r.NoteText) || (r.Title ?? ""),
    type: r.NoteType?.Value ?? null,
    date: dateOnly(r.NoteDate),
  };
}

/** A short single-line title for list views (SharePoint Title holds 255 characters). */
export function shortTitle(text: string, max = 120): string {
  const line = text.trim().split("\n")[0]?.trim() ?? "";
  return line.length > max ? `${line.slice(0, max - 1)}…` : line;
}

/**
 * Configured Choice values from a generated getReferencedEntity call. The
 * payload is either a direct array or an OData `{ value: [...] }` envelope;
 * any other shape is an error, never an empty list.
 */
export function parseChoices(payload: unknown): string[] {
  let raw: unknown[] | null = null;
  if (Array.isArray(payload)) {
    raw = payload;
  } else if (typeof payload === "object" && payload !== null && "value" in payload) {
    const value: unknown = payload.value;
    if (Array.isArray(value)) raw = value;
  }
  if (raw === null) throw new Error("Unsupported SharePoint Choice response shape");
  return raw.map((item) => {
    if (typeof item === "object" && item !== null && "Value" in item && typeof item.Value === "string") {
      return item.Value;
    }
    throw new Error("Unsupported SharePoint Choice item shape");
  });
}
