import { useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Save } from "lucide-react";
import { toast } from "sonner";
import type { Projects_9426df72Write } from "../../generated/models/Projects_9426df72Model";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ChoiceSelect, Field, OptionalDateField } from "@/components/tracker-ui";
import { ProjectsService, useProjectChoices } from "@/data/api";
import { toSpDate, type Project } from "@/data/tracker";
import { clearDate, save } from "@/lib/sp";

export function ResearchDetails({ project }: { project: Project }) {
  const client = useQueryClient();
  const databases = useProjectChoices("DatabaseSource");
  const priorities = useProjectChoices("ProjectPriority");
  const access = useProjectChoices("AccessStatus");
  const extracts = useProjectChoices("ExtractStatus");
  const [draft, setDraft] = useState(project);
  const [busy, setBusy] = useState(false);
  const [numberText, setNumberText] = useState(project.projectNumber !== null ? String(project.projectNumber) : "");
  const update = <K extends keyof Project>(key: K, value: Project[K]) => setDraft((current) => ({ ...current, [key]: value }));
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (busy || !draft.title.trim() || !draft.piName.trim()) return;
    const parsedNumber = numberText.trim() ? Number(numberText) : null;
    if (parsedNumber !== null && (!Number.isInteger(parsedNumber) || parsedNumber < 1)) {
      toast.error("Project number must be a whole number of 1 or more.");
      return;
    }
    const patch: Partial<Projects_9426df72Write> = {};
    if (parsedNumber !== null && parsedNumber !== project.projectNumber) patch.ProjectNumber = parsedNumber;
    if (draft.intakeDate !== project.intakeDate) Object.assign(patch, draft.intakeDate ? { IntakeDate: toSpDate(draft.intakeDate) } : clearDate("IntakeDate"));
    if (draft.startDate !== project.startDate) Object.assign(patch, draft.startDate ? { StartDate: toSpDate(draft.startDate) } : clearDate("StartDate"));
    if (draft.requestedBy.trim() !== project.requestedBy) patch.RequestedBy = draft.requestedBy.trim();
    if (draft.intakeSource.trim() !== project.intakeSource) patch.IntakeSource = draft.intakeSource.trim();
    if (draft.researchOutput.trim() !== project.researchOutput) patch.ResearchOutput = draft.researchOutput.trim();
    if (draft.title.trim() !== project.title) patch.Title = draft.title.trim();
    if (draft.piName.trim() !== project.piName) patch.PI = draft.piName.trim();
    if (draft.target.trim() !== project.target) patch.Target = draft.target.trim();
    if (draft.owner.trim() !== project.owner) patch.ProjectOwner = draft.owner.trim();
    if (draft.studyReference.trim() !== project.studyReference) patch.StudyReference = draft.studyReference.trim();
    if (draft.cohortVersion.trim() !== project.cohortVersion) patch.CohortVersion = draft.cohortVersion.trim();
    if (draft.nextAction.trim() !== project.nextAction) patch.NextAction = draft.nextAction.trim();
    if (draft.database && draft.database !== project.database) patch.DatabaseSource = { Value: draft.database };
    if (draft.priority && draft.priority !== project.priority) patch.ProjectPriority = { Value: draft.priority };
    if (draft.accessStatus && draft.accessStatus !== project.accessStatus) patch.AccessStatus = { Value: draft.accessStatus };
    if (draft.extractStatus && draft.extractStatus !== project.extractStatus) patch.ExtractStatus = { Value: draft.extractStatus };
    if (!Object.keys(patch).length) { toast.info("No changes to save"); return; }
    setBusy(true);
    const result = await save(() => ProjectsService.update(project.id, patch), "Couldn't save the research details.");
    if (result.ok) { await client.invalidateQueries({ queryKey: ["projects"] }); await client.invalidateQueries({ queryKey: ["report-project"] }); toast.success("Research details saved"); }
    setBusy(false);
  };
  return (
    <section aria-labelledby="research-heading" className="rounded-xl border bg-card p-4 sm:p-5">
      <h3 id="research-heading" className="mb-4 text-base font-semibold">Research setup</h3>
      <form onSubmit={(e) => void submit(e)} className="space-y-5">
        <p className="text-sm text-muted-foreground">Project metadata only. Do not enter patient records or identifiers.</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="research-number" label="Project #"><Input id="research-number" inputMode="numeric" value={numberText} onChange={(e) => setNumberText(e.target.value)} /></Field>
          <Field id="research-requested" label="Requested by"><Input id="research-requested" value={draft.requestedBy} onChange={(e) => update("requestedBy", e.target.value)} maxLength={255} /></Field>
          <Field id="research-intake" label="Intake date"><OptionalDateField id="research-intake" label="Intake date" value={draft.intakeDate} onChange={(v) => update("intakeDate", v)} emptyLabel="Not set" /></Field>
          <Field id="research-start" label="Start date"><OptionalDateField id="research-start" label="Start date" value={draft.startDate} onChange={(v) => update("startDate", v)} emptyLabel="Not started" /></Field>
          <Field id="research-source" label="Intake source"><Input id="research-source" value={draft.intakeSource} onChange={(e) => update("intakeSource", e.target.value)} maxLength={255} /></Field>
          <Field id="research-output" label="Research output"><Input id="research-output" value={draft.researchOutput} onChange={(e) => update("researchOutput", e.target.value)} placeholder="Published, Submitted, Abstract…" maxLength={255} /></Field>
        </div>
        <div className="grid gap-4 border-t pt-5 sm:grid-cols-2">
          <Field id="research-title" label="Project title"><Input id="research-title" value={draft.title} onChange={(e) => update("title", e.target.value)} required maxLength={255} /></Field>
          <Field id="research-pi" label="PI"><Input id="research-pi" value={draft.piName} onChange={(e) => update("piName", e.target.value)} required maxLength={255} /></Field>
          <Field id="research-database" label="EHR database"><ChoiceSelect id="research-database" choices={databases} value={draft.database} onChange={(v) => update("database", v)} what="databases" /></Field>
          <Field id="research-owner" label="Project owner"><Input id="research-owner" value={draft.owner} onChange={(e) => update("owner", e.target.value)} maxLength={255} /></Field>
          <Field id="research-priority" label="Project priority"><ChoiceSelect id="research-priority" choices={priorities} value={draft.priority} onChange={(v) => update("priority", v)} what="priorities" /></Field>
          <Field id="research-target" label="Target deliverable"><Input id="research-target" value={draft.target} onChange={(e) => update("target", e.target.value)} maxLength={255} /></Field>
        </div>
        <div className="grid gap-4 border-t pt-5 sm:grid-cols-2">
          <Field id="research-study" label="Study / approval reference"><Input id="research-study" value={draft.studyReference} onChange={(e) => update("studyReference", e.target.value)} maxLength={255} /></Field>
          <Field id="research-access" label="Access / approval status"><ChoiceSelect id="research-access" choices={access} value={draft.accessStatus} onChange={(v) => update("accessStatus", v)} what="access statuses" /></Field>
          <Field id="research-version" label="Cohort / extract version"><Input id="research-version" value={draft.cohortVersion} onChange={(e) => update("cohortVersion", e.target.value)} maxLength={255} /></Field>
          <Field id="research-extract" label="Extract status"><ChoiceSelect id="research-extract" choices={extracts} value={draft.extractStatus} onChange={(v) => update("extractStatus", v)} what="extract statuses" /></Field>
        </div>
        <Field id="research-next" label="Next action"><Textarea id="research-next" value={draft.nextAction} onChange={(e) => update("nextAction", e.target.value)} rows={2} maxLength={255} /></Field>
        <Button type="submit" disabled={busy} className="h-auto whitespace-normal"><Save aria-hidden="true" />{busy ? "Saving…" : "Save research details"}</Button>
      </form>
    </section>
  );
}
