import { useRef, useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ClipboardCheck, History, Plus, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ConnectorErrorState, EmptyState } from "@/components/states";
import { ChoiceSelect, Field, ListStatus, PageControls } from "@/components/tracker-ui";
import { ProjectsService, useProjectChoices, useStageChoices, useStatusChoices } from "@/data/api";
import { fetchActivity, fetchRequests, proposalBaseline, RequestsService, reviewRequest, useActivityChoices, useRequestChoices, type AgentRequest } from "@/data/agent-api";
import type { Project, Task } from "@/data/tracker";
import { allowedAction, defaultAgentMode, isTaskAction } from "@/lib/agent-rules";
import { configuredChoice } from "@/lib/time-math";
import { save, usePaged, type PagedList } from "@/lib/sp";

const stamp = (value?: string) => value && Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleString() : "Time not recorded";

export function ProjectAgents({ project, tasks }: { project: Project; tasks: PagedList<Task> }) {
  const client = useQueryClient();
  const modes = useProjectChoices("AgentMode");
  const requestStates = useRequestChoices("RequestState");
  const outcomes = useActivityChoices("Outcome");
  const origins = useActivityChoices("Origin");
  const statuses = useStatusChoices();
  const stages = useStageChoices();
  const requests = usePaged(["agent-requests", project.id], (token) => fetchRequests(project.id, token));
  const activity = usePaged(["activity", project.id], (token) => fetchActivity(project.id, token));
  const [mode, setMode] = useState<string | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [review, setReview] = useState<AgentRequest | null>(null);
  const [note, setNote] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const selectedMode = mode ?? project.agentMode ?? defaultAgentMode(modes.data);
  const pending = configuredChoice(requestStates.data, ["Pending", "Proposed", "Pending approval", "Awaiting approval", "Submitted"]);
  const refresh = async () => {
    await Promise.all(["agent-requests", "activity", "projects", "tasks", "report-project"].map((key) => client.invalidateQueries({ queryKey: [key] })));
  };
  const saveMode = async () => {
    if (!selectedMode || busy) return;
    setBusy(true);
    const result = await save(() => ProjectsService.update(project.id, { AgentMode: { Value: selectedMode } }), "Couldn't save the agent preference.");
    if (result.ok) { await client.invalidateQueries({ queryKey: ["projects"] }); toast.success("Agent preference saved; human review still required"); }
    setBusy(false);
  };
  const apply = async (reject: boolean) => {
    if (!review || lock.current || !requestStates.data || !statuses.data || !stages.data || !outcomes.data || !origins.data) return;
    lock.current = true; setBusy(true); setMessage("");
    try {
      const result = await reviewRequest({ visible: review, projectId: project.id, reject, reviewNote: note, states: requestStates.data, statuses: statuses.data, stages: stages.data, outcomes: outcomes.data, origins: origins.data });
      await refresh();
      if (result.ok) { toast.success(result.message); setReview(null); }
      else setMessage(result.message);
    } finally { setBusy(false); lock.current = false; }
  };
  const canReview = requestStates.isSuccess && statuses.isSuccess && stages.isSuccess && outcomes.isSuccess && origins.isSuccess;
  const reviewOptionError = [requestStates, statuses, stages, outcomes, origins].find((query) => query.isError)?.error;
  return (
    <section aria-labelledby="agents-heading" className="space-y-5">
      <div className="rounded-xl border bg-card p-4">
        <h3 id="agents-heading" className="mb-3 text-base font-semibold">Agent review</h3>
        <p className="mb-4 max-w-3xl text-sm text-muted-foreground">Mode preferences do not activate automation. Every request here requires human review; an external agent must be configured separately. Patient data, deletions, email sending and publishing are excluded.</p>
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-0 flex-1"><Field id="agent-mode" label="Agent mode preference"><ChoiceSelect id="agent-mode" choices={modes} value={selectedMode} onChange={setMode} what="agent modes" /></Field></div>
          <Button variant="outline" className="h-auto whitespace-normal" disabled={busy || !selectedMode || selectedMode === project.agentMode} onClick={() => void saveMode()}>Save preference</Button>
          <Button className="h-auto whitespace-normal" onClick={() => setNewOpen(true)}><Plus aria-hidden="true" />New request</Button>
        </div>
      </div>
      <Tabs defaultValue="requests">
        <TabsList className="h-auto flex-wrap" aria-label="Agent review records"><TabsTrigger className="h-auto whitespace-normal" value="requests">Requests</TabsTrigger><TabsTrigger className="h-auto whitespace-normal" value="activity">Change history</TabsTrigger></TabsList>
        <TabsContent value="requests" className="space-y-3">
          <ListStatus list={requests} what="agent requests" />
          {requests.query.isSuccess && requests.rows.length === 0 && <EmptyState icon={ClipboardCheck} title="No requests on this page" action={<Button variant="outline" onClick={() => setNewOpen(true)}>New request</Button>} />}
          <ul className="space-y-3">{requests.rows.map((request) => (
            <li key={request.ID} className="flex flex-wrap items-start gap-4 rounded-xl border bg-card p-4">
              <div className="min-w-0 flex-1 space-y-2">
                <p className="font-medium break-words">{request.Title}</p>
                <dl className="flex flex-wrap gap-x-5 gap-y-1 text-sm"><div><dt className="inline text-muted-foreground">Action: </dt><dd className="inline">{request.ActionName?.Value ?? "Not specified"}</dd></div><div><dt className="inline text-muted-foreground">State: </dt><dd className="inline">{request.RequestState?.Value ?? "Not specified"}</dd></div><div><dt className="inline text-muted-foreground">Created by: </dt><dd className="inline">{request.Author?.DisplayName ?? "Author unavailable"}</dd></div></dl>
                <div className="grid gap-2 text-sm sm:grid-cols-2"><p className="break-words"><span className="text-muted-foreground">Expected: </span>{request.ExpectedValue || "(empty)"}</p><p className="break-words"><span className="text-muted-foreground">Proposed: </span>{request.ProposedValue || "(empty)"}</p></div>
                {request.Reason && <p className="text-sm break-words whitespace-pre-wrap">{request.Reason}</p>}
                {request.AppliedAt && <p className="text-sm text-muted-foreground">Applied {stamp(request.AppliedAt)}</p>}
              </div>
              <Button variant="outline" className="h-auto whitespace-normal" onClick={() => { setNote(""); setMessage(""); setReview(request); }}><ClipboardCheck aria-hidden="true" />Review request</Button>
            </li>
          ))}</ul>
          <PageControls list={requests} what="requests" />
        </TabsContent>
        <TabsContent value="activity" className="space-y-3">
          <ListStatus list={activity} what="change history" />
          {activity.query.isSuccess && activity.rows.length === 0 && <EmptyState icon={History} title="No review activity on this page" action={<Button variant="outline" onClick={() => void activity.query.refetch()}>Refresh history</Button>} />}
          <ol className="divide-y rounded-xl border bg-card">{activity.rows.map((item) => (
            <li key={item.ID} className="space-y-2 p-4 text-sm">
              <p className="font-medium">{item.Title}</p>
              <dl className="flex flex-wrap gap-x-5 gap-y-1"><div><dt className="inline text-muted-foreground">Target: </dt><dd className="inline">{item.EntityType} #{item.EntityId}</dd></div><div><dt className="inline text-muted-foreground">Request: </dt><dd className="inline">#{item.RequestId}</dd></div><div><dt className="inline text-muted-foreground">Outcome: </dt><dd className="inline">{item.Outcome?.Value ?? "See review record"}</dd></div></dl>
              <div className="grid gap-2 sm:grid-cols-2"><p className="break-words">Before: {item.BeforeValue || "(empty)"}</p><p className="break-words">After: {item.AfterValue || "(empty)"}</p></div>
              <p className="text-muted-foreground">{stamp(item.OccurredAt)} · Recorded by {item.Author?.DisplayName ?? "author unavailable"}</p>
            </li>
          ))}</ol>
          <PageControls list={activity} what="activity" />
        </TabsContent>
      </Tabs>
      <Dialog open={newOpen} onOpenChange={setNewOpen}><DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-xl"><DialogHeader><DialogTitle>New change request</DialogTitle><DialogDescription>{project.title}</DialogDescription></DialogHeader><NewRequest project={project} tasks={tasks} onDone={async () => { await refresh(); setNewOpen(false); }} /></DialogContent></Dialog>
      <Dialog open={!!review} onOpenChange={(open) => { if (!open && !busy) setReview(null); }}><DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-xl"><DialogHeader><DialogTitle>Review change request</DialogTitle><DialogDescription>Record authorship identifies who created the request; it is not an agent authorization grant.</DialogDescription></DialogHeader>
        {review && <div className="space-y-4">
          <p className="font-medium break-words">{review.ActionName?.Value ?? "Unknown action"} · Target #{review.TargetId}</p>
          <dl className="grid gap-3 text-sm"><div><dt className="text-muted-foreground">Expected current value</dt><dd className="break-words whitespace-pre-wrap">{review.ExpectedValue || "(empty)"}</dd></div><div><dt className="text-muted-foreground">Proposed value</dt><dd className="break-words whitespace-pre-wrap">{review.ProposedValue || "(empty)"}</dd></div><div><dt className="text-muted-foreground">Request mode</dt><dd>{review.RequestMode?.Value ?? "Not specified"}</dd></div><div><dt className="text-muted-foreground">Created by</dt><dd>{review.Author?.DisplayName ?? "Author unavailable"}</dd></div>{review.RequesterLabel && <div><dt className="text-muted-foreground">Requester label (unverified)</dt><dd className="break-words">{review.RequesterLabel}</dd></div>}</dl>
          {review.Reason && <p className="text-sm break-words whitespace-pre-wrap">{review.Reason}</p>}
          <Field id="review-note" label="Review note"><Textarea id="review-note" value={note} onChange={(e) => setNote(e.target.value)} maxLength={2000} rows={2} /></Field>
          <p className="text-sm text-muted-foreground">Updates across records are not transactional. Review this request in only one session; a partial attempt is held for reconciliation rather than automatically replayed.</p>
          {message && <p role="alert" className="text-sm font-medium">{message}</p>}
          {reviewOptionError ? <ConnectorErrorState error={reviewOptionError} connector="SharePoint" title="Couldn't load review options" className="py-3" action={<Button variant="outline" className="h-auto whitespace-normal" onClick={() => void Promise.all([requestStates.refetch(), statuses.refetch(), stages.refetch(), outcomes.refetch(), origins.refetch()])}>Reload review options</Button>} /> : !canReview && <p role="status" className="text-sm">Loading review options…</p>}
          {review.AppliedAt || review.RequestState?.Value !== pending ? <p className="text-sm">This request is not pending. No further application is allowed.</p> : <DialogFooter><Button variant="outline" disabled={busy || !canReview} onClick={() => void apply(true)}>Reject request</Button><Button className="h-auto whitespace-normal" disabled={busy || !canReview || !allowedAction(review.ActionName?.Value)} onClick={() => void apply(false)}><ShieldCheck aria-hidden="true" />{busy ? "Reviewing…" : "Approve & apply"}</Button></DialogFooter>}
        </div>}
      </DialogContent></Dialog>
    </section>
  );
}

function NewRequest({ project, tasks, onDone }: { project: Project; tasks: PagedList<Task>; onDone: () => Promise<void> }) {
  const actions = useRequestChoices("ActionName");
  const modes = useRequestChoices("RequestMode");
  const states = useRequestChoices("RequestState");
  const statuses = useStatusChoices();
  const stages = useStageChoices();
  const [actionName, setActionName] = useState<string | null>(null);
  const [target, setTarget] = useState("");
  const [value, setValue] = useState("");
  const [reason, setReason] = useState("");
  const [mode, setMode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const action = allowedAction(actionName);
  const taskAction = action ? isTaskAction(action) : false;
  const permitted = (name: string) => allowedAction(name) !== null;
  const selectedMode = mode ?? (modes.data?.includes(project.agentMode ?? "") ? project.agentMode : defaultAgentMode(modes.data));
  const pending = configuredChoice(states.data, ["Pending", "Proposed", "Pending approval", "Awaiting approval", "Submitted"]);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!actionName || !selectedMode || !pending || !action || !value.trim() || !reason.trim() || busy || (taskAction && !target)) return;
    setBusy(true);
    try {
      const targetId = taskAction ? target : project.id;
      const expected = await proposalBaseline(project.id, actionName, targetId);
      const result = await save(() => RequestsService.create({
        Title: `${actionName}: ${project.title}`.slice(0, 255), ProjectId: Number(project.id), TargetId: Number(targetId),
        ActionName: { Value: actionName }, ExpectedValue: expected, ProposedValue: value.trim(), Reason: reason.trim(),
        RequestMode: { Value: selectedMode }, RequestState: { Value: pending }, RequestKey: crypto.randomUUID(),
      }), "Couldn't save the request.");
      if (result.ok) { toast.success("Request saved for human review"); await onDone(); }
    } catch (error) { console.error("Request preparation failed", error); toast.error("Couldn't verify the request target. Refresh the project and try again."); }
    finally { setBusy(false); }
  };
  return <form onSubmit={(e) => void submit(e)} className="space-y-4">
    <Field id="request-action" label="Allowed action"><ChoiceSelect id="request-action" choices={actions} filterOptions={permitted} value={actionName} onChange={(v) => { setActionName(v); setValue(""); }} what="supported actions" /></Field>
    {taskAction && <div className="space-y-2"><Field id="request-task" label="Target task"><Select value={target} onValueChange={setTarget}><SelectTrigger id="request-task" className="h-auto w-full whitespace-normal"><SelectValue placeholder="Choose task" /></SelectTrigger><SelectContent>{tasks.rows.map((task) => <SelectItem key={task.id} value={task.id}>{task.title}</SelectItem>)}</SelectContent></Select></Field><ListStatus list={tasks} what="tasks" /><PageControls list={tasks} what="target tasks" /></div>}
    <Field id="request-value" label="Proposed value">{action === "task-status" || action === "project-stage" ? <ChoiceSelect id="request-value" choices={action === "task-status" ? statuses : stages} value={value || null} onChange={setValue} what={action === "task-status" ? "statuses" : "stages"} /> : <Input id="request-value" type={action === "task-due" ? "date" : "text"} value={value} onChange={(e) => setValue(e.target.value)} required maxLength={255} />}</Field>
    <Field id="request-mode" label="Request mode"><ChoiceSelect id="request-mode" choices={modes} value={selectedMode} onChange={setMode} what="request modes" /></Field>
    <Field id="request-reason" label="Reason"><Textarea id="request-reason" value={reason} onChange={(e) => setReason(e.target.value)} required maxLength={2000} rows={3} /></Field>
    {states.isError && <ConnectorErrorState error={states.error} connector="SharePoint" title="Couldn't load request states" className="py-3" action={<Button variant="outline" onClick={() => void states.refetch()}>Retry request states</Button>} />}
    {states.isSuccess && !pending && <p role="alert" className="text-sm">A pending review state must be configured.</p>}
    <DialogFooter><Button type="submit" disabled={busy || !pending || !action || !selectedMode || !value.trim() || !reason.trim() || (taskAction && !target)}>{busy ? "Saving…" : "Save for review"}</Button></DialogFooter>
  </form>;
}
