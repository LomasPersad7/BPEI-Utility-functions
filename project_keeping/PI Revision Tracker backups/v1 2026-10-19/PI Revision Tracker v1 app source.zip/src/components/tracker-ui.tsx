// Shared UI pieces for the tracker pages.
import { useState, type ReactNode } from "react";
import { format, parseISO } from "date-fns";
import { CalendarIcon, ChevronLeft, ChevronRight, RotateCw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ConnectorErrorState, LoadingState } from "@/components/states";
import { TONE_BADGE, TONE_DOT, dueState, fmtFull, stageTone, type Tone } from "@/lib/format";
import { CONNECTOR, type Choices, type PagedList } from "@/lib/sp";
import { cn } from "@/lib/utils";

export function StatusBadge({ tone, children }: { tone: Tone; children: ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-xs font-medium whitespace-normal",
        TONE_BADGE[tone],
      )}
    >
      <span aria-hidden="true" className={cn("tone-dot size-1.5 rounded-full", TONE_DOT[tone])} />
      {children}
    </span>
  );
}

/** Deadline badge: overdue / due today / due in N days, or on time / late once completed. */
export function DueBadge({
  due,
  completedOn = null,
  done = false,
}: {
  due: string | null;
  completedOn?: string | null;
  done?: boolean;
}) {
  const info = dueState(due, completedOn, done);
  if (!info) return null;
  return <StatusBadge tone={info.tone}>{info.label}</StatusBadge>;
}

export function Field({ id, label, children }: { id: string; label: string; children: ReactNode }) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
    </div>
  );
}

export function RetryButton({ onRetry }: { onRetry: () => void }) {
  return (
    <Button type="button" variant="outline" size="sm" onClick={onRetry}>
      <RotateCw aria-hidden="true" />
      Retry
    </Button>
  );
}

export function PageControls<T>({ list, what }: { list: PagedList<T>; what: string }) {
  if (!list.hasPrev && !list.hasNext) return null;
  return (
    <div className="flex flex-wrap items-center justify-end gap-2 pt-2">
      {list.hasPrev && (
        <Button type="button" variant="outline" size="sm" disabled={list.query.isFetching} onClick={list.showPrev}>
          <ChevronLeft aria-hidden="true" />
          Previous page<span className="sr-only"> of {what}</span>
        </Button>
      )}
      {list.hasNext && (
        <Button type="button" variant="outline" size="sm" disabled={list.query.isFetching} onClick={list.showNext}>
          {list.query.isFetching ? "Loading…" : "Next page"}
          <span className="sr-only"> of {what}</span>
          <ChevronRight aria-hidden="true" />
        </Button>
      )}
    </div>
  );
}

/** First-page loading / error states shared by every list. */
export function ListStatus<T>({ list, what }: { list: PagedList<T>; what: string }) {
  if (list.query.isPending) return <LoadingState rows={3} />;
  if (list.query.isError) {
    return (
      <ConnectorErrorState
        error={list.query.error}
        connector={CONNECTOR}
        title={`Couldn't load ${what}`}
        className="py-8"
        action={
          <div className="flex gap-2">
            {list.hasPrev && (
              <Button type="button" variant="outline" size="sm" onClick={list.showPrev}>
                <ChevronLeft aria-hidden="true" />
                Previous page
              </Button>
            )}
            <RetryButton onRetry={() => void list.query.refetch()} />
          </div>
        }
      />
    );
  }
  return null;
}

export function DateField({
  id,
  label,
  value,
  onChange,
  className,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (iso: string) => void;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const date = parseISO(value);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          id={id}
          type="button"
          variant="outline"
          aria-label={`${label}: ${fmtFull(value)}`}
          className={cn("justify-start font-normal tabular-nums", className)}
        >
          <CalendarIcon aria-hidden="true" />
          {fmtFull(value)}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={date}
          defaultMonth={date}
          onSelect={(d) => {
            if (!d) return;
            onChange(format(d, "yyyy-MM-dd"));
            setOpen(false);
          }}
        />
      </PopoverContent>
    </Popover>
  );
}

/** A date that may be unset, with a clear button. */
export function OptionalDateField({
  id,
  label,
  value,
  onChange,
  disabled,
  size = "default",
  emptyLabel = "No date",
  className,
}: {
  id: string;
  label: string;
  value: string | null;
  onChange: (iso: string | null) => void;
  disabled?: boolean;
  size?: "sm" | "default";
  emptyLabel?: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const date = value ? parseISO(value) : undefined;
  return (
    <div className={cn("flex items-center gap-1", className)}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            id={id}
            type="button"
            variant="outline"
            size={size}
            disabled={disabled}
            aria-label={`${label}: ${value ? fmtFull(value) : "not set"}`}
            className="min-w-0 flex-1 justify-start font-normal tabular-nums"
          >
            <CalendarIcon aria-hidden="true" />
            {value ? fmtFull(value) : <span className="text-muted-foreground">{emptyLabel}</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={date}
            defaultMonth={date}
            onSelect={(d) => {
              if (!d) return;
              onChange(format(d, "yyyy-MM-dd"));
              setOpen(false);
            }}
          />
        </PopoverContent>
      </Popover>
      {value && (
        <Button
          type="button"
          variant="ghost"
          size={size === "sm" ? "icon-sm" : "icon"}
          disabled={disabled}
          aria-label={`Clear ${label.toLowerCase()}`}
          title={`Clear ${label.toLowerCase()}`}
          onClick={() => onChange(null)}
        >
          <X aria-hidden="true" />
        </Button>
      )}
    </div>
  );
}

/** A Select over configured SharePoint Choice values, with distinct loading / empty / error states. */
export function ChoiceSelect({
  id,
  choices,
  value,
  onChange,
  what,
  label,
  size = "default",
  disabled,
  className,
  filterOptions,
}: {
  id: string;
  choices: Choices;
  filterOptions?: (option: string) => boolean;
  value: string | null;
  onChange: (value: string) => void;
  what: string;
  label?: string;
  size?: "sm" | "default";
  disabled?: boolean;
  className?: string;
}) {
  if (choices.isError) {
    return <ConnectorErrorState error={choices.error} connector={CONNECTOR} title={`Couldn't load ${what}`} className="py-2" action={<RetryButton onRetry={() => void choices.refetch()} />} />;
  }
  const options = filterOptions ? (choices.data ?? []).filter(filterOptions) : choices.data ?? [];
  return (
    <Select
      value={value ?? ""}
      onValueChange={onChange}
      disabled={disabled || !choices.isSuccess || options.length === 0}
    >
      <SelectTrigger id={id} size={size} aria-label={label} className={cn("h-auto min-w-0 w-full whitespace-normal [&_[data-slot=select-value]]:whitespace-normal [&_[data-slot=select-value]]:line-clamp-none", className)}>
        <SelectValue placeholder={choices.isPending ? "Loading…" : options.length === 0 ? `No ${what} configured` : "Choose"} />
      </SelectTrigger>
      <SelectContent>
        {options.map((option) => (
          <SelectItem key={option} value={option}>
            {option}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/** Compact stage progress: one bar per configured stage, filled through the current one. */
export function StageBars({ stage, order }: { stage: string | null; order: string[] }) {
  const idx = stage ? order.indexOf(stage) : -1;
  if (idx < 0) return null;
  return (
    <span aria-hidden="true" className="flex gap-0.5">
      {order.map((s, i) => (
        <span
          key={s}
          className={cn(
            "h-1.5 w-2.5 rounded-full",
            i <= idx ? cn("stage-bar-filled", TONE_DOT[stageTone(stage)]) : "stage-bar-empty bg-foreground/15",
          )}
        />
      ))}
    </span>
  );
}
