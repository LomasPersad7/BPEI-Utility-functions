import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Clock, Play, Square } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChoiceSelect, Field, RetryButton } from "@/components/tracker-ui";
import { ConnectorErrorState } from "@/components/states";
import { useTimeChoices } from "@/data/api";
import { readTimer, startTimer, stopTimer, useTimerRecord } from "@/data/time-api";
import { useConfirm } from "@/hooks/use-confirm";
import { CONNECTOR } from "@/lib/sp";
import { readTimerPointer, useAppStore } from "@/lib/store";
import { configuredChoice } from "@/lib/time-math";

export function StartWorkTimer({ projectId, roundId, note }: { projectId: string; roundId?: string; note: string }) {
  const client = useQueryClient();
  const categories = useTimeChoices("WorkCategory");
  const states = useTimeChoices("EntryState");
  const [category, setCategory] = useState<string | null>(null);
  const pointer = useAppStore((s) => s.timer);
  const busy = useAppStore((s) => s.timerBusy);
  const configured = !!configuredChoice(states.data, ["Running", "Active"]) && !!configuredChoice(states.data, ["Logged", "Stopped", "Completed"]);
  const start = async () => {
    if (!category || !states.data) return;
    const saved = await startTimer({ projectId, roundId, note, category, states: states.data });
    await client.invalidateQueries({ queryKey: ["active-timer"] });
    await client.invalidateQueries({ queryKey: ["time"] });
    if (saved) toast.success("Timer started");
  };
  return (
    <div className="space-y-2 rounded-lg border p-3">
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-0 flex-1"><Field id={`timer-category-${roundId ?? projectId}`} label="Timer work category"><ChoiceSelect id={`timer-category-${roundId ?? projectId}`} choices={categories} value={category} onChange={setCategory} what="work categories" /></Field></div>
        <Button type="button" className="h-auto whitespace-normal" disabled={busy || !!pointer || !category || !configured} onClick={() => void start()}><Play aria-hidden="true" />Start timer</Button>
      </div>
      {pointer && <p className="text-sm text-muted-foreground">Finish the timer at the top of the page before starting another.</p>}
      {states.isError && <ConnectorErrorState error={states.error} connector={CONNECTOR} title="Couldn't load timer states" className="py-2" action={<RetryButton onRetry={() => void states.refetch()} />} />}
      {states.isSuccess && !configured && <p role="alert" className="text-sm">Timer running and logged states need to be configured.</p>}
    </div>
  );
}

export function ActiveWorkTimer() {
  const confirm = useConfirm();
  const pointer = useAppStore((s) => s.timer);
  const busy = useAppStore((s) => s.timerBusy);
  const query = useTimerRecord();
  const states = useTimeChoices("EntryState");
  const client = useQueryClient();
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!pointer) return;
    const interval = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(interval);
  }, [pointer]);
  useEffect(() => {
    const sync = () => {
      try { useAppStore.getState().setTimer(readTimerPointer()); }
      catch { toast.error("Couldn't refresh the timer reference."); }
    };
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);
  if (!pointer) return null;
  const entry = query.data;
  const elapsed = entry?.startedOn ? Math.max(0, Math.floor(((pointer.stopAt ? Date.parse(pointer.stopAt) : now) - Date.parse(entry.startedOn)) / 1000)) : 0;
  const clock = `${String(Math.floor(elapsed / 3600)).padStart(2, "0")}:${String(Math.floor(elapsed / 60) % 60).padStart(2, "0")}:${String(elapsed % 60).padStart(2, "0")}`;
  const stop = async () => {
    if (!states.data) return;
    await stopTimer(pointer, states.data);
    await Promise.all([client.invalidateQueries({ queryKey: ["active-timer"] }), client.invalidateQueries({ queryKey: ["time"] }), client.invalidateQueries({ queryKey: ["time-report"] })]);
  };
  const clearMissingReference = async () => {
    if (busy || query.isFetching || !query.isSuccess || entry) return;
    if (!(await confirm({
      title: "Clear the missing timer reference?",
      description: "No saved timer was returned for this reference. This clears only the browser reference, not any SharePoint record. Check the time entries before starting again if an earlier save was uncertain.",
      confirmLabel: "Clear reference",
    }))) return;
    const store = useAppStore.getState();
    if (store.timerBusy || store.timer?.key !== pointer.key) return;
    store.setTimerBusy(true);
    try {
      const found = await readTimer(pointer);
      if (found) {
        await client.invalidateQueries({ queryKey: ["active-timer"] });
        toast.info("The saved timer is now available. Use its stop control.");
      } else if (readTimerPointer()?.key === pointer.key) {
        store.setTimer(null);
        toast.success("Missing browser reference cleared; no saved records deleted");
      }
    } catch {
      toast.error("The timer could not be verified. Its reference was kept.");
    } finally { store.setTimerBusy(false); }
  };
  return (
    <section aria-label="Saved work timer" className="border-b bg-muted px-4 py-3 md:px-6">
      <div className="mx-auto max-w-[1440px]">
        {query.isError ? <ConnectorErrorState error={query.error} connector={CONNECTOR} title="Couldn't load the saved timer" className="py-2" action={<RetryButton onRetry={() => void query.refetch()} />} /> : !entry ? (
          <div className="flex flex-wrap items-center gap-3 text-sm" role="status"><Clock aria-hidden="true" />{query.isFetching || busy ? "Checking saved timer…" : "The timer was not found. Check again before starting another."}<RetryButton onRetry={() => void query.refetch()} />{query.isSuccess && !query.isFetching && !busy && <Button type="button" variant="outline" onClick={() => void clearMissingReference()}>Clear missing reference</Button>}</div>
        ) : (
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <Clock aria-hidden="true" className="size-5 shrink-0" />
            <div className="min-w-0 flex-1"><p className="text-sm font-medium break-words">{entry.note}</p><p className="text-sm text-muted-foreground">{entry.category ?? "Uncategorized"} · {entry.stoppedOn ? "Already logged" : pointer.stopAt ? "Stop time retained" : "Timer running"}</p></div>
            <span aria-label={`Elapsed time ${clock}`} className="font-mono text-lg tabular-nums">{clock}</span>
            <Button type="button" className="h-auto whitespace-normal" disabled={busy || !states.isSuccess} onClick={() => void stop()}><Square aria-hidden="true" />{busy ? "Saving…" : entry.stoppedOn ? "Dismiss logged timer" : pointer.stopAt ? "Finish saving time" : "Stop & log time"}</Button>
            <Button asChild variant="outline" className="h-auto whitespace-normal"><Link to="/time">View time reports</Link></Button>
          </div>
        )}
        {states.isError && <ConnectorErrorState error={states.error} connector={CONNECTOR} title="Couldn't load timer states" className="py-2" action={<RetryButton onRetry={() => void states.refetch()} />} />}
      </div>
    </section>
  );
}
