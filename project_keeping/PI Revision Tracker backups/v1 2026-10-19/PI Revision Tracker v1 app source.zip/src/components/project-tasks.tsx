import { useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ListTodo, Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useConfirm } from "@/hooks/use-confirm";
import { EmptyState } from "@/components/states";
import {
  ChoiceSelect,
  DueBadge,
  Field,
  ListStatus,
  OptionalDateField,
  PageControls,
  StatusBadge,
} from "@/components/tracker-ui";
import { TasksService, keys, usePriorityChoices, useStatusChoices, useTaskChoices } from "@/data/api";
import { DONE_STATUS, toSpDate, type Task } from "@/data/tracker";
import { fmtDay, priorityTone } from "@/lib/format";
import { clearDate, remove, save, type PagedList } from "@/lib/sp";
import { cn } from "@/lib/utils";

const isDone = (t: Task) => t.status === DONE_STATUS;

function sortTasks(rows: Task[], priorities: string[]): Task[] {
  const rank = (p: string | null) => {
    const i = p ? priorities.indexOf(p) : -1;
    return i < 0 ? priorities.length : i;
  };
  return [...rows].sort(
    (a, b) =>
      Number(isDone(a)) - Number(isDone(b)) ||
      rank(a.priority) - rank(b.priority) ||
      (a.dueDate ?? "9999").localeCompare(b.dueDate ?? "9999") ||
      Number(a.id) - Number(b.id),
  );
}

export function ProjectTasks({ projectId, tasks }: { projectId: string; tasks: PagedList<Task> }) {
  const queryClient = useQueryClient();
  const confirm = useConfirm();
  const priorities = usePriorityChoices();
  const statuses = useStatusChoices();
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState<string | null>(null);
  const [due, setDue] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [statusOverride, setStatusOverride] = useState<Record<string, string>>({});
  const [editing, setEditing] = useState<Task | null>(null);

  const priorityOptions = priorities.data ?? [];
  const selectedPriority =
    priority ?? (priorityOptions.includes("Medium") ? "Medium" : (priorityOptions[0] ?? null));
  const firstStatus = statuses.data?.[0] ?? null;
  const refresh = () => queryClient.invalidateQueries({ queryKey: keys.tasks(projectId) });

  const addTask = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const text = title.trim();
    if (!text || busy) return;
    setBusy(true);
    const saved = await save(
      () =>
        TasksService.create({
          Title: text,
          ProjectId: Number(projectId),
          ...(selectedPriority ? { TaskPriority: { Value: selectedPriority } } : {}),
          ...(firstStatus ? { TaskStatus: { Value: firstStatus } } : {}),
          ...(due ? { DueOn: toSpDate(due) } : {}),
        }),
      "Couldn't add the task.",
    );
    if (saved.ok) {
      setTitle("");
      setDue(null);
      await refresh();
    }
    setBusy(false);
  };

  const setStatus = async (task: Task, status: string) => {
    if (status === task.status) return;
    setStatusOverride((o) => ({ ...o, [task.id]: status }));
    const saved = await save(
      () => TasksService.update(task.id, { TaskStatus: { Value: status } }),
      "Couldn't update the task.",
    );
    if (saved.ok) await refresh();
    setStatusOverride((o) => {
      const rest = { ...o };
      delete rest[task.id];
      return rest;
    });
  };

  const deleteTask = async (task: Task) => {
    if (!(await confirm({ title: "Delete this task?", description: task.title, confirmLabel: "Delete task", destructive: true }))) return;
    const gone = await remove(
      () => TasksService.delete(task.id),
      () => TasksService.getAll({ filter: `ID eq ${Number(task.id)}`, top: 1 }),
      "Couldn't delete the task.",
    );
    if (gone) await refresh();
  };

  const rows = sortTasks(
    tasks.rows.map((t) => (statusOverride[t.id] ? { ...t, status: statusOverride[t.id] } : t)),
    priorityOptions,
  );

  return (
    <section aria-labelledby="tasks-heading" className="rounded-xl border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b px-4 py-3">
        <h3 id="tasks-heading" className="text-sm font-semibold">
          Tasks
          {tasks.query.isSuccess && !tasks.paged && (
            <span className="ml-1.5 font-normal tabular-nums text-muted-foreground">
              {rows.filter((t) => !isDone(t)).length} open of {rows.length}
            </span>
          )}
        </h3>
      </div>

      <div className="space-y-3 p-4">
        <form
          onSubmit={(e) => void addTask(e)}
          className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_8.5rem] lg:grid-cols-[minmax(0,1fr)_8.5rem_12rem_auto]"
        >
          <Label htmlFor="new-task" className="sr-only">
            New task
          </Label>
          <Input
            id="new-task"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Add a task"
            maxLength={255}
          />
          <ChoiceSelect
            id="new-task-priority"
            label="Priority"
            choices={priorities}
            value={selectedPriority}
            onChange={setPriority}
            what="priorities"
          />
          <OptionalDateField
            id="new-task-due"
            label="Due date"
            value={due}
            onChange={setDue}
            emptyLabel="No due date"
          />
          <Button type="submit" variant="outline" disabled={busy || !title.trim()} className="justify-self-start">
            <Plus aria-hidden="true" />
            Add task
          </Button>
        </form>

        <ListStatus list={tasks} what="tasks" />
        {tasks.query.isSuccess && rows.length === 0 && !tasks.paged && (
          <EmptyState icon={ListTodo} title="No tasks yet" className="py-8" action={<Button variant="outline" onClick={() => document.getElementById("new-task")?.focus()}>Add a task</Button>} />
        )}
        {tasks.query.isSuccess && rows.length > 0 && (
          <ul className="divide-y rounded-lg border">
            {rows.map((task) => {
              const done = isDone(task);
              return (
                <li
                  key={task.id}
                  className="grid items-start gap-3 px-3 py-3 sm:grid-cols-[8.5rem_minmax(0,1fr)_auto]"
                >
                  <ChoiceSelect
                    id={`task-status-${task.id}`}
                    label={`Status: ${task.title}`}
                    choices={statuses}
                    value={task.status}
                    onChange={(value) => void setStatus(task, value)}
                    what="statuses"
                    size="sm"
                    disabled={task.id in statusOverride}
                  />
                  <div className="min-w-0">
                    <p className={cn("text-sm leading-snug break-words", done && "line-through decoration-foreground/70")}>
                      {task.title}
                    </p>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5">
                      {task.priority && <StatusBadge tone={priorityTone(task.priority)}>{task.priority} priority</StatusBadge>}
                      {task.assignedTo && <span className="text-xs">Assignee: {task.assignedTo}</span>}
                      {task.workstream && <span className="text-xs">Workstream: {task.workstream}</span>}
                      {task.milestone && <span className="text-xs">Milestone: {task.milestone}</span>}
                      <DueBadge due={task.dueDate} done={done} />
                      {task.dueDate && (
                        <span className="text-xs text-muted-foreground tabular-nums">
                          due {fmtDay(task.dueDate)}
                        </span>
                      )}
                    </div>
                    {task.blockedReason && <p className="mt-2 text-sm break-words whitespace-pre-wrap"><span className="font-medium">Blocker: </span>{task.blockedReason}</p>}
                  </div>
                  <div className="flex items-center">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon-sm"
                      aria-label={`Edit task: ${task.title}`}
                      title="Edit task"
                      onClick={() => setEditing(task)}
                    >
                      <Pencil aria-hidden="true" />
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon-sm"
                      aria-label={`Delete task: ${task.title}`}
                      title="Delete task"
                      onClick={() => void deleteTask(task)}
                    >
                      <Trash2 aria-hidden="true" />
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
        <PageControls list={tasks} what="tasks" />
      </div>

      <Dialog open={editing !== null} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent aria-describedby={undefined} className="max-h-[90dvh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Edit task</DialogTitle>
          </DialogHeader>
          {editing && (
            <TaskEditForm
              key={editing.id}
              task={editing}
              onDone={async (changed) => {
                if (changed) await refresh();
                setEditing(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

function TaskEditForm({ task, onDone }: { task: Task; onDone: (changed: boolean) => Promise<void> }) {
  const priorities = usePriorityChoices();
  const [title, setTitle] = useState(task.title);
  const [priority, setPriority] = useState<string | null>(task.priority);
  const [due, setDue] = useState<string | null>(task.dueDate);
  const workstreams = useTaskChoices("Workstream");
  const milestones = useTaskChoices("Milestone");
  const [assignedTo, setAssignedTo] = useState(task.assignedTo);
  const [workstream, setWorkstream] = useState(task.workstream);
  const [milestone, setMilestone] = useState(task.milestone);
  const [blocker, setBlocker] = useState(task.blockedReason);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const text = title.trim();
    if (!text || busy) return;
    const changes = {
      ...(text !== task.title ? { Title: text } : {}),
      ...(priority && priority !== task.priority ? { TaskPriority: { Value: priority } } : {}),
      ...(due !== task.dueDate ? (due ? { DueOn: toSpDate(due) } : clearDate("DueOn")) : {}),
      ...(assignedTo.trim() !== task.assignedTo ? { AssignedTo: assignedTo.trim() } : {}),
      ...(workstream && workstream !== task.workstream ? { Workstream: { Value: workstream } } : {}),
      ...(milestone && milestone !== task.milestone ? { Milestone: { Value: milestone } } : {}),
      ...(blocker.trim() !== task.blockedReason ? { BlockedReason: blocker.trim() } : {}),
    };
    if (Object.keys(changes).length === 0) {
      await onDone(false);
      return;
    }
    setBusy(true);
    const saved = await save(() => TasksService.update(task.id, changes), "Couldn't save the task.");
    setBusy(false);
    if (saved.ok) await onDone(true);
  };

  return (
    <form onSubmit={(e) => void submit(e)} className="grid gap-4">
      <Field id="edit-task-title" label="Task">
        <Input id="edit-task-title" value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={255} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="edit-task-priority" label="Priority">
          <ChoiceSelect
            id="edit-task-priority"
            choices={priorities}
            value={priority}
            onChange={setPriority}
            what="priorities"
          />
        </Field>
        <Field id="edit-task-due" label="Due date">
          <OptionalDateField id="edit-task-due" label="Due date" value={due} onChange={setDue} emptyLabel="No due date" />
        </Field>
      </div>
      <Field id="edit-task-assignee" label="Assignee"><Input id="edit-task-assignee" value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)} maxLength={255} /></Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="edit-task-workstream" label="Workstream"><ChoiceSelect id="edit-task-workstream" choices={workstreams} value={workstream} onChange={setWorkstream} what="workstreams" /></Field>
        <Field id="edit-task-milestone" label="Milestone"><ChoiceSelect id="edit-task-milestone" choices={milestones} value={milestone} onChange={setMilestone} what="milestones" /></Field>
      </div>
      <Field id="edit-task-blocker" label="Blocked reason"><Textarea id="edit-task-blocker" value={blocker} onChange={(e) => setBlocker(e.target.value)} rows={2} maxLength={255} /></Field>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={() => void onDone(false)}>
          Cancel
        </Button>
        <Button type="submit" disabled={busy || !title.trim()}>
          {busy ? "Saving…" : "Save task"}
        </Button>
      </DialogFooter>
    </form>
  );
}
