import { useRef, useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DialogFooter } from "@/components/ui/dialog";
import { ConnectorErrorState } from "@/components/states";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChoiceSelect, Field, ListStatus, PageControls, RetryButton } from "@/components/tracker-ui";
import { fetchProjects, fetchRounds, keys, TimeService, useTimeChoices } from "@/data/api";
import { PAGE_SIZE, toSpDate, type TimeEntry } from "@/data/tracker";
import type { Time_log_9426df72Write } from "../../generated/models/Time_log_9426df72Model";
import { todayIso } from "@/lib/format";
import { save, usePaged } from "@/lib/sp";
import { configuredChoice, validDay } from "@/lib/time-math";
import { newManualSubmission, type ManualSubmission } from "@/lib/manual-submission";
import { submitManualTime, type ManualTimePayload } from "@/data/time-api";

export function TimeEntryForm({ entry, onDone }: { entry?: TimeEntry; onDone: () => void }) {
  const client = useQueryClient();
  const projects = usePaged(keys.projects(PAGE_SIZE), (token) => fetchProjects(PAGE_SIZE, token));
  const categories = useTimeChoices("WorkCategory");
  const states = useTimeChoices("EntryState");
  const [projectId, setProjectId] = useState(entry?.projectId ?? "");
  const [roundId, setRoundId] = useState<string | null>(entry?.roundId ?? null);
  const [category, setCategory] = useState(entry?.category ?? null);
  const [date, setDate] = useState(entry?.date ?? todayIso());
  const [hours, setHours] = useState(entry?.hours?.toString() ?? "");
  const [note, setNote] = useState(entry?.note ?? "");
  const [busy, setBusy] = useState(false);
  const submission = useRef<ManualSubmission<ManualTimePayload> | null>(null);
  const [pendingSave, setPendingSave] = useState(false);
  const timed = !!entry?.startedOn;
  const loggedState = configuredChoice(states.data, ["Logged", "Stopped", "Completed"]);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const numericHours = Number(hours);
    if (busy || !note.trim() || (!entry && (!projectId || !category))) return;
    if (!timed && (!validDay(date) || !Number.isFinite(numericHours) || numericHours <= 0 || numericHours > 24)) { toast.error("Enter a valid work date and more than 0, up to 24 hours."); return; }
    setBusy(true);
    const logged = loggedState;
    if (!entry && !submission.current?.attempted && !logged) {
      setBusy(false); toast.error("The logged-time state is not available. Reload the options before saving."); return;
    }
    let saved;
    if (entry) {
      const patch: Partial<Time_log_9426df72Write> = {};
      if (note.trim() !== entry.note) patch.Title = note.trim();
      if (category && category !== entry.category) patch.WorkCategory = { Value: category };
      if (!timed && date !== entry.date) patch.WorkDate = toSpDate(date);
      if (!timed && numericHours !== entry.hours) patch.Hours = numericHours;
      if (!Object.keys(patch).length) { setBusy(false); onDone(); return; }
      saved = await save(() => TimeService.update(entry.id, patch), "Couldn't update the time entry.");
    } else {
      if (!submission.current?.attempted) submission.current = newManualSubmission({
        Title: note.trim(), ProjectId: Number(projectId), ...(roundId ? { RoundId: Number(roundId) } : {}),
        WorkDate: toSpDate(date), Hours: numericHours, WorkCategory: { Value: category ?? "" },
        ...(logged ? { EntryState: { Value: logged } } : {}),
      });
      saved = { ok: await submitManualTime(submission.current) };
      setPendingSave(!saved.ok && submission.current.attempted);
    }
    if (saved.ok) { await client.invalidateQueries({ queryKey: ["time"] }); await client.invalidateQueries({ queryKey: ["time-report"] }); toast.success("Time entry saved"); onDone(); }
    setBusy(false);
  };
  return <form onSubmit={(e) => void submit(e)} className="space-y-4">
    <fieldset disabled={busy || pendingSave} className="space-y-4 border-0 p-0">
    {!entry && <>
      <Field id="time-project" label="Project"><Select value={projectId} onValueChange={(id) => { setProjectId(id); setRoundId(null); }}><SelectTrigger id="time-project" className="h-auto w-full whitespace-normal"><SelectValue placeholder="Choose project" /></SelectTrigger><SelectContent>{projects.rows.map((project) => <SelectItem key={project.id} value={project.id}>{project.title}</SelectItem>)}</SelectContent></Select></Field>
      <ListStatus list={projects} what="projects" /><PageControls list={projects} what="projects" />
      {projectId && <RoundPicker key={projectId} projectId={projectId} value={roundId} onChange={setRoundId} />}
    </>}
    <Field id="time-note" label="Work done"><Input id="time-note" value={note} onChange={(e) => setNote(e.target.value)} required maxLength={255} /></Field>
    <Field id="time-category" label="Work category"><ChoiceSelect id="time-category" choices={categories} value={category} onChange={setCategory} what="work categories" /></Field>
    {timed ? <p className="text-sm text-muted-foreground">Timer timestamps and duration are retained. You can edit the description and category.</p> : <div className="grid gap-4 sm:grid-cols-2"><Field id="time-date" label="Work date"><Input id="time-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} required /></Field><Field id="time-hours" label="Hours"><Input id="time-hours" type="number" inputMode="decimal" min="0.01" max="24" step="0.01" value={hours} onChange={(e) => setHours(e.target.value)} required /></Field></div>}
    </fieldset>
    {!entry && states.isError && <ConnectorErrorState error={states.error} connector="SharePoint" title="Couldn't load time states" className="py-2" action={<RetryButton onRetry={() => void states.refetch()} />} />}
    {!entry && states.isPending && <p role="status" className="text-sm">Loading time states…</p>}
    {!entry && states.isSuccess && !loggedState && <p role="alert" className="text-sm">A logged-time state must be configured before saving manual hours.</p>}
    {pendingSave && <p role="alert" className="text-sm">This submission is awaiting confirmation. Its original values and reference are retained here. Check the saved entry before closing this form or logging the same hours again.</p>}
    <DialogFooter><Button type="submit" disabled={busy || !note.trim() || (!entry && (!projectId || !category || (!pendingSave && !loggedState)))}>{busy ? "Checking…" : entry ? "Save entry" : pendingSave ? "Check saved entry" : "Log time"}</Button></DialogFooter>
  </form>;
}

function RoundPicker({ projectId, value, onChange }: { projectId: string; value: string | null; onChange: (id: string | null) => void }) {
  const rounds = usePaged(keys.rounds(projectId), (token) => fetchRounds(projectId, token));
  return <div className="space-y-2"><Field id="time-round" label="Revision round (optional)"><Select value={value ?? "none"} onValueChange={(id) => onChange(id === "none" ? null : id)}><SelectTrigger id="time-round" className="h-auto w-full whitespace-normal"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">Project work, no round</SelectItem>{rounds.rows.map((round) => <SelectItem key={round.id} value={round.id}>{round.label} · {round.emailSubject}</SelectItem>)}</SelectContent></Select></Field><ListStatus list={rounds} what="revision rounds" /><PageControls list={rounds} what="rounds" /></div>;
}
