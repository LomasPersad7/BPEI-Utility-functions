import { useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Database, Gavel, NotebookPen, Plus, StickyNote, Trash2, Users, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/states";
import { ChoiceSelect, DateField, ListStatus, PageControls } from "@/components/tracker-ui";
import { NotesService, keys, useNoteTypeChoices } from "@/data/api";
import { shortTitle, toSpDate, type Note } from "@/data/tracker";
import { fmtFull, todayIso } from "@/lib/format";
import { remove, save, type PagedList } from "@/lib/sp";

const TYPE_ICON: Record<string, LucideIcon> = {
  Decision: Gavel,
  "Data issue": Database,
  Meeting: Users,
};

export function ProjectNotes({ projectId, notes }: { projectId: string; notes: PagedList<Note> }) {
  const queryClient = useQueryClient();
  const types = useNoteTypeChoices();
  const [type, setType] = useState<string | null>(null);
  const [date, setDate] = useState(todayIso);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const refresh = () => queryClient.invalidateQueries({ queryKey: keys.notes(projectId) });

  const addNote = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const body = text.trim();
    if (!body || busy) return;
    setBusy(true);
    const saved = await save(
      () =>
        NotesService.create({
          Title: shortTitle(body),
          ProjectId: Number(projectId),
          NoteText: body,
          NoteDate: toSpDate(date),
          ...(type ? { NoteType: { Value: type } } : {}),
        }),
      "Couldn't save the note.",
    );
    if (saved.ok) {
      setText("");
      await refresh();
    }
    setBusy(false);
  };

  const deleteNote = async (note: Note) => {
    const gone = await remove(
      () => NotesService.delete(note.id),
      () => NotesService.getAll({ filter: `ID eq ${Number(note.id)}`, top: 1 }),
      "Couldn't delete the note.",
    );
    if (gone) await refresh();
  };

  return (
    <section aria-labelledby="notes-heading" className="rounded-xl border bg-card">
      <div className="border-b px-4 py-3">
        <h3 id="notes-heading" className="text-sm font-semibold">
          Notes
          {notes.query.isSuccess && !notes.paged && (
            <span className="ml-1.5 font-normal tabular-nums text-muted-foreground">{notes.rows.length}</span>
          )}
        </h3>
      </div>

      <div className="grid gap-6 p-4 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)]">
        <form onSubmit={(e) => void addNote(e)} className="grid content-start gap-2">
          <div className="grid grid-cols-2 gap-2">
            <ChoiceSelect
              id="note-type"
              label="Note type"
              choices={types}
              value={type}
              onChange={setType}
              what="note types"
            />
            <DateField id="note-date" label="Note date" value={date} onChange={setDate} />
          </div>
          <Label htmlFor="note-text" className="sr-only">
            Note
          </Label>
          <Textarea
            id="note-text"
            rows={5}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Decision, data issue or meeting outcome"
          />
          <Button type="submit" variant="outline" disabled={busy || !text.trim()} className="justify-self-start">
            <Plus aria-hidden="true" />
            Add note
          </Button>
        </form>

        <div className="min-w-0 space-y-2">
          <ListStatus list={notes} what="notes" />
          {notes.query.isSuccess && notes.rows.length === 0 && !notes.paged && (
            <EmptyState icon={NotebookPen} title="No notes yet" className="py-8" action={<Button variant="outline" onClick={() => document.getElementById("note-text")?.focus()}>Add a note</Button>} />
          )}
          {notes.query.isSuccess && notes.rows.length > 0 && (
            <ol className="space-y-0 border-l pl-4">
              {notes.rows.map((note) => {
                const Icon = (note.type && TYPE_ICON[note.type]) || StickyNote;
                return (
                  <li key={note.id} className="relative pb-4 last:pb-0">
                    <span
                      aria-hidden="true"
                      className="note-dot absolute top-1.5 -left-[1.3rem] size-2.5 rounded-full border-2 border-primary bg-card"
                    />
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="flex flex-wrap items-center gap-2 text-xs">
                          <span className="font-medium tabular-nums">{note.date ? fmtFull(note.date) : "No date"}</span>
                          {note.type && (
                            <span className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-medium">
                              <Icon aria-hidden="true" className="size-3" />
                              {note.type}
                            </span>
                          )}
                        </p>
                        <p className="mt-1 text-sm leading-relaxed break-words whitespace-pre-line">{note.text}</p>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        aria-label={`Delete note from ${note.date ? fmtFull(note.date) : "no date"}`}
                        title="Delete note"
                        onClick={() => void deleteNote(note)}
                      >
                        <Trash2 aria-hidden="true" />
                      </Button>
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
          <PageControls list={notes} what="notes" />
        </div>
      </div>
    </section>
  );
}
