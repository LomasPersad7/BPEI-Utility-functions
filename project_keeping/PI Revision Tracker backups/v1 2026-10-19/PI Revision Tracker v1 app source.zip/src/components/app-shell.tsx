import type { MouseEvent } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { FileClock } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { ActiveWorkTimer } from "@/components/work-timer";
import { routes } from "@/routes";
import { cn } from "@/lib/utils";

// App frame: skip link, persistent identity bar, the single <main>, toasts.
export function AppShell() {
  const { pathname } = useLocation();
  const skipToWorkspace = (event: MouseEvent<HTMLAnchorElement>) => {
    const target = document.getElementById("main-content");
    if (!target) return;
    event.preventDefault();
    target.focus();
    target.scrollIntoView({ block: "start" });
  };
  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main-content"
        onClick={skipToWorkspace}
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-md focus:bg-background focus:px-3 focus:py-2 focus:text-sm focus:font-medium focus:shadow-md focus:outline-2 focus:outline-ring"
      >
        Skip to main content
      </a>
      <header className="border-b bg-card">
        <div className="mx-auto flex min-h-14 w-full max-w-[1440px] flex-wrap items-center gap-3 px-4 py-3 md:px-6">
          <span
            aria-hidden="true"
            className="grid size-8 place-items-center rounded-md bg-primary text-primary-foreground"
          >
            <FileClock className="size-4" />
          </span>
          <span className="text-sm font-semibold tracking-tight">PI Revision Tracker</span>
          <nav aria-label="Main" className="flex flex-wrap items-center gap-1 sm:ml-4">
            {routes
              .filter((route) => route.label)
              .map((route) => {
                const Icon = route.icon;
                return (
                  <NavLink
                    key={route.path}
                    to={route.path}
                    end={route.path === "/"}
                    className={({ isActive }) =>
                      cn(
                        "inline-flex min-h-9 items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
                        isActive ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted/60 hover:text-foreground",
                      )
                    }
                  >
                    {Icon && <Icon aria-hidden="true" className="size-4" />}
                    {route.label}
                  </NavLink>
                );
              })}
          </nav>
        </div>
      </header>
      <main id="main-content" tabIndex={-1} className="flex flex-1 flex-col outline-none focus-visible:outline-2 focus-visible:outline-ring">
        <ActiveWorkTimer />
        {/* key on pathname → each route re-mounts and replays the entrance.
            Entrance-only (no AnimatePresence/exit): an exit animation around
            <Outlet/> would animate the NEXT route's content, not the leaving one. */}
        <motion.div
          key={pathname}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.15, ease: "easeOut" }}
          className="flex-1"
        >
          <Outlet />
        </motion.div>
      </main>
      <Toaster />
    </div>
  );
}

export default AppShell;
