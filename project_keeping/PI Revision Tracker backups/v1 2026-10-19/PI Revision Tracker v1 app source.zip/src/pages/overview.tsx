import { useQueries, type UseQueryResult } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { FolderPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ConnectorErrorState, EmptyState, LoadingState } from "@/components/states";
import { DueBadge, PageControls, RetryButton, StageBars, StatusBadge } from "@/components/tracker-ui";
import { fetchProjects, fetchRounds, fetchTasks, firstPage, keys, useStageChoices } from "@/data/api";
import { DONE_STATUS, isProjectFinished, type Project, type Round, type Task } from "@/data/tracker";
import { daysBetween, fmtFull, isOverdue, plural, projectStatusTone, todayIso } from "@/lib/format";
import { CONNECTOR, usePaged, type Page } from "@/lib/sp";

/** Projects per overview page; each row reads its own rounds and tasks. */
const OVERVIEW_PAGE = 20;

interface Deadline {
  date: string;
  label: string;
}

interface Summary {
  project: Project;
  rounds: UseQueryResult<Page<Round>, Error>;
  tasks: UseQueryResult<Page<Task>, Error>;
  openRound: Round | null;
  openRounds: number;
  overdueRounds: number;
  next: Deadline | null;
  turnaround: { avg: number; count: number } | null;
  openTasks: number;
  overdueTasks: number;
  overdueTarget: boolean;
}

function summarize(
  project: Project,
  rounds: UseQueryResult<Page<Round>, Error>,
  tasks: UseQueryResult<Page<Task>, Error>,
  today: string,
): Summary {
  const roundRows = rounds.data?.rows ?? [];
  const taskRows = tasks.data?.rows ?? [];
  const open = roundRows.filter((r) => !r.deliveredDate);
  const finished = isProjectFinished(project);

  const candidates: Deadline[] = [];
  for (const r of open) if (r.dueDate) candidates.push({ date: r.dueDate, label: `${r.label || "Round"} due back` });
  if (project.targetDate && !finished) candidates.push({ date: project.targetDate, label: "Submission target" });
  candidates.sort((a, b) => a.date.localeCompare(b.date));

  const turnarounds = roundRows
    .filter((r) => r.requestDate && r.deliveredDate)
    .map((r) => daysBetween(r.requestDate as string, r.deliveredDate as string));
  const openTaskRows = taskRows.filter((t) => t.status !== DONE_STATUS);

  return {
    project,
    rounds,
    tasks,
    openRound:
      [...open].sort((a, b) => (a.requestDate ?? "").localeCompare(b.requestDate ?? "")).at(-1) ?? null,
    openRounds: open.length,
    overdueRounds: open.filter((r) => isOverdue(r.dueDate, false, today)).length,
    next: candidates[0] ?? null,
    turnaround: turnarounds.length
      ? { avg: turnarounds.reduce((a, b) => a + b, 0) / turnarounds.length, count: turnarounds.length }
      : null,
    openTasks: openTaskRows.length,
    overdueTasks: openTaskRows.filter((t) => isOverdue(t.dueDate, false, today)).length,
    overdueTarget: !finished && isOverdue(project.targetDate, false, today),
  };
}

/** Finished projects last; otherwise by next deadline (overdue first), then title. */
function compareSummaries(a: Summary, b: Summary): number {
  const doneA = isProjectFinished(a.project);
  const doneB = isProjectFinished(b.project);
  if (doneA !== doneB) return doneA ? 1 : -1;
  const nextA = a.next?.date ?? "9999-12-31";
  const nextB = b.next?.date ?? "9999-12-31";
  return nextA.localeCompare(nextB) || a.project.title.localeCompare(b.project.title);
}

function CellStatus({ query, what }: { query: UseQueryResult<unknown, Error>; what: string }) {
  if (query.isPending) return <Skeleton className="h-4 w-20" />;
  return (
    <span className="flex flex-wrap items-center gap-2 text-xs">
      Couldn&apos;t load {what}.
      <Button type="button" variant="link" size="xs" className="h-auto px-0" onClick={() => void query.refetch()}>
        Retry<span className="sr-only"> loading {what}</span>
      </Button>
    </span>
  );
}

export function OverviewPage() {
  const stages = useStageChoices();
  const projects = usePaged(keys.projects(OVERVIEW_PAGE), (skipToken) => fetchProjects(OVERVIEW_PAGE, skipToken));
  const roundQueries = useQueries({
    queries: projects.rows.map((p) => ({
      queryKey: firstPage(keys.rounds(p.id)),
      queryFn: () => fetchRounds(p.id),
    })),
  });
  const taskQueries = useQueries({
    queries: projects.rows.map((p) => ({
      queryKey: firstPage(keys.tasks(p.id)),
      queryFn: () => fetchTasks(p.id),
    })),
  });

  const today = todayIso();
  const order = stages.data ?? [];
  const summaries = projects.rows
    .map((p, i) => summarize(p, roundQueries[i], taskQueries[i], today))
    .sort(compareSummaries);
  const allLoaded = summaries.every((s) => s.rounds.isSuccess && s.tasks.isSuccess);
  const totals = {
    openRounds: summaries.reduce((n, s) => n + s.openRounds, 0),
    overdue: summaries.reduce((n, s) => n + s.overdueRounds + s.overdueTasks + (s.overdueTarget ? 1 : 0), 0),
    openTasks: summaries.reduce((n, s) => n + s.openTasks, 0),
  };

  return (
    <section
      id="workspace"
      tabIndex={-1}
      aria-labelledby="overview-title"
      className="mx-auto w-full max-w-[1440px] space-y-5 px-4 py-5 outline-none md:px-6"
    >
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 id="overview-title" className="text-xl font-semibold tracking-tight">
          Overview
        </h1>
        {projects.query.isSuccess && summaries.length > 0 && (
          <dl className="flex flex-wrap gap-x-6 gap-y-1 text-sm" aria-busy={!allLoaded || undefined}>
            {[
              { label: "Open rounds", value: totals.openRounds },
              { label: "Overdue items", value: totals.overdue, danger: totals.overdue > 0 },
              { label: "Open tasks", value: totals.openTasks },
            ].map((stat) => (
              <div key={stat.label} className="flex items-baseline gap-2">
                <dt className="text-muted-foreground">{stat.label}</dt>
                <dd className="text-base font-semibold tabular-nums">
                  {allLoaded ? (
                    stat.danger ? (
                      <StatusBadge tone="danger">{stat.value}</StatusBadge>
                    ) : (
                      stat.value
                    )
                  ) : (
                    "…"
                  )}
                </dd>
              </div>
            ))}
            {projects.paged && <div className="text-xs text-muted-foreground self-center">On this page</div>}
          </dl>
        )}
      </div>

      {projects.query.isPending ? (
        <LoadingState rows={5} />
      ) : projects.query.isError ? (
        <ConnectorErrorState
          error={projects.query.error}
          connector={CONNECTOR}
          title="Couldn't load projects"
          action={<RetryButton onRetry={() => void projects.query.refetch()} />}
        />
      ) : summaries.length === 0 ? (
        <EmptyState
          icon={FolderPlus}
          title={projects.hasPrev ? "No projects on this page" : "No projects yet"}
          action={
            <Button asChild>
              <Link to="/">Go to Projects</Link>
            </Button>
          }
        />
      ) : (
        <div className="rounded-xl border bg-card">
          <Table>
            <TableCaption className="sr-only">
              Every project with its status, stage, open round, next deadline, turnaround and open tasks, sorted by next
              deadline.
            </TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead scope="col" className="min-w-[16rem] pl-4">
                  Project
                </TableHead>
                <TableHead scope="col">Status and stage</TableHead>
                <TableHead scope="col">Open round</TableHead>
                <TableHead scope="col" aria-sort="ascending">
                  Next deadline
                </TableHead>
                <TableHead scope="col">Turnaround</TableHead>
                <TableHead scope="col" className="pr-4">
                  Open tasks
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {summaries.map((s) => {
                const p = s.project;
                const idx = p.stage ? order.indexOf(p.stage) : -1;
                return (
                  <TableRow key={p.id}>
                    <TableCell className="py-3 pl-4 align-top whitespace-normal">
                      <Link
                        to={{ pathname: "/", search: `?project=${encodeURIComponent(p.id)}` }}
                        className="font-medium underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                      >
                        {p.title}
                      </Link>
                      <span className="mt-0.5 block text-xs text-muted-foreground">
                        {p.piName}
                        {p.database && ` · ${p.database}`}
                        {p.target && ` · ${p.target}`}
                      </span>
                    </TableCell>
                    <TableCell className="py-3 align-top">
                      <span className="flex flex-col items-start gap-1.5 text-xs">
                        {p.status && <StatusBadge tone={projectStatusTone(p.status)}><span className="sr-only">Status: </span>{p.status}</StatusBadge>}
                        <StageBars stage={p.stage} order={order} />
                        <span className="font-medium">{p.stage ?? "No stage"}</span>
                        {idx >= 0 && (
                          <span className="sr-only">
                            (stage {idx + 1} of {order.length})
                          </span>
                        )}
                      </span>
                    </TableCell>
                    <TableCell className="py-3 align-top text-sm">
                      {!s.rounds.isSuccess ? (
                        <CellStatus query={s.rounds} what="rounds" />
                      ) : s.openRound ? (
                        <span className="flex flex-col gap-0.5">
                          <span className="font-medium">
                            {s.openRound.label || "Round"}
                            {s.openRound.kind && <span className="font-normal"> · {s.openRound.kind}</span>}
                          </span>
                          {s.openRound.requestDate && (
                            <span className="text-xs text-muted-foreground tabular-nums">
                              open {plural(Math.max(0, daysBetween(s.openRound.requestDate, today)), "day")}
                            </span>
                          )}
                          {s.openRounds > 1 && (
                            <span className="text-xs text-muted-foreground">{s.openRounds} rounds open</span>
                          )}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">None open</span>
                      )}
                      {s.rounds.data?.next && (
                        <span className="mt-1 block text-xs text-muted-foreground">First 100 rounds only</span>
                      )}
                    </TableCell>
                    <TableCell className="py-3 align-top text-sm">
                      {!s.rounds.isSuccess ? (
                        <CellStatus query={s.rounds} what="deadlines" />
                      ) : s.next ? (
                        <span className="flex flex-col items-start gap-1">
                          <span className="font-medium tabular-nums">{fmtFull(s.next.date)}</span>
                          <span className="text-xs text-muted-foreground">{s.next.label}</span>
                          <DueBadge due={s.next.date} />
                        </span>
                      ) : (
                        <span className="text-muted-foreground">None set</span>
                      )}
                    </TableCell>
                    <TableCell className="py-3 align-top text-sm tabular-nums">
                      {!s.rounds.isSuccess ? (
                        <CellStatus query={s.rounds} what="turnaround" />
                      ) : s.turnaround ? (
                        <span className="flex flex-col">
                          <span className="font-medium">
                            avg {plural(Number(s.turnaround.avg.toFixed(1)), "day")}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {plural(s.turnaround.count, "delivered round")}
                          </span>
                        </span>
                      ) : (
                        <span className="text-muted-foreground">No deliveries</span>
                      )}
                    </TableCell>
                    <TableCell className="py-3 pr-4 align-top text-sm">
                      {!s.tasks.isSuccess ? (
                        <CellStatus query={s.tasks} what="tasks" />
                      ) : (
                        <span className="flex flex-col items-start gap-1">
                          <span className="font-medium tabular-nums">
                            {s.openTasks}
                            {s.tasks.data?.next && "+"}
                          </span>
                          {s.overdueTasks > 0 && <StatusBadge tone="danger">{s.overdueTasks} overdue</StatusBadge>}
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <div className="px-4 pb-3">
            <PageControls list={projects} what="projects" />
          </div>
        </div>
      )}
    </section>
  );
}
