import type { IOperationResult } from "@microsoft/managed-apps/data";
import type { Agent_requests_9426df72Read } from "../../generated/models/Agent_requests_9426df72Model";
import type { Activity_log_9426df72Read } from "../../generated/models/Activity_log_9426df72Model";
import { Agent_requests_9426df72Service as RequestsService, Activity_log_9426df72Service as ActivityService } from "../../generated";
import { ProjectsService, TasksService } from "@/data/api";
import { toSpDate } from "@/data/tracker";
import { connectorFailure, fetchPage, useChoices } from "@/lib/sp";
import { allowedAction, currentValue, isTaskAction, sameProposal, validateProposal } from "@/lib/agent-rules";
import { configuredChoice } from "@/lib/time-math";

export { RequestsService, ActivityService };
export type AgentRequest = Agent_requests_9426df72Read;
export type Activity = Activity_log_9426df72Read;
export const fetchRequests = (projectId: string, skipToken?: string) => fetchPage(RequestsService.getAll({ filter: `ProjectId eq ${Number(projectId)}`, top: 50, orderBy: ["ID desc"], skipToken }), (row) => typeof row.ID === "number" ? row : null);
export const fetchActivity = (projectId: string, skipToken?: string) => fetchPage(ActivityService.getAll({ filter: `ProjectId eq ${Number(projectId)}`, top: 50, orderBy: ["ID desc"], skipToken }), (row) => typeof row.ID === "number" ? row : null);
export const useRequestChoices = (field: "ActionName" | "RequestMode" | "RequestState") => useChoices(["choices", "requests", field], () => RequestsService.getReferencedEntity("", field));
export const useActivityChoices = (field: "Origin" | "Outcome") => useChoices(["choices", "activity", field], () => ActivityService.getReferencedEntity("", field));

export async function required<T>(request: Promise<IOperationResult<T>>): Promise<T> {
  const result = await request;
  if (!result.success) connectorFailure(result.error);
  return result.data;
}
class ReviewBlocked extends Error {}
const reviewing = new Set<number>();

export async function proposalBaseline(projectId: string, actionName: string, targetId: string) {
  const action = allowedAction(actionName);
  if (!action) throw new ReviewBlocked("Choose an allowed action.");
  const project = await required(ProjectsService.get(projectId));
  const task = isTaskAction(action) ? await required(TasksService.get(targetId)) : undefined;
  if (project.ID !== Number(projectId) || (isTaskAction(action) ? task?.ProjectId !== project.ID : Number(targetId) !== project.ID)) throw new ReviewBlocked("The target does not belong to this project.");
  return currentValue(action, project, task);
}

/** Human-triggered, allowlisted, fail-closed review. No automatic executor exists. */
export async function reviewRequest(input: {
  visible: AgentRequest; projectId: string; reject: boolean; reviewNote: string;
  states: string[]; statuses: string[]; stages: string[]; outcomes: string[]; origins: string[];
}): Promise<{ ok: boolean; message: string }> {
  const id = input.visible.ID;
  if (typeof id !== "number" || reviewing.has(id)) return { ok: false, message: "This request is already being reviewed." };
  const pending = configuredChoice(input.states, ["Pending", "Proposed", "Pending approval", "Awaiting approval", "Submitted"]);
  const applied = configuredChoice(input.states, ["Applied", "Completed"]);
  const rejected = configuredChoice(input.states, ["Rejected", "Declined"]);
  if (!pending || !applied || !rejected) return { ok: false, message: "Pending, applied and rejected request states must be configured." };
  reviewing.add(id);
  let changed = false;
  try {
    const request = await required(RequestsService.get(String(id)));
    if (!sameProposal(input.visible, request)) throw new ReviewBlocked("The request changed. Refresh and review it again.");
    if (request.ProjectId !== Number(input.projectId) || request.AppliedAt || request.RequestState?.Value !== pending || !request.RequestKey) throw new ReviewBlocked("This request is not eligible for review.");
    const duplicates = await RequestsService.getAll({ filter: `RequestKey eq '${request.RequestKey.replaceAll("'", "''")}'`, top: 2 });
    if (!duplicates.success) connectorFailure(duplicates.error);
    if (duplicates.skipToken || duplicates.data.length !== 1 || duplicates.data[0].ID !== id) throw new ReviewBlocked("The request key is not unique. Resolve duplicate requests first.");
    const prior = await ActivityService.getAll({ filter: `RequestId eq ${id}`, top: 1 });
    if (!prior.success) connectorFailure(prior.error);
    if (prior.data.length || prior.skipToken) throw new ReviewBlocked("This request has a previous review attempt. Check its activity and target before any further change.");
    const project = await required(ProjectsService.get(input.projectId));
    const action = allowedAction(request.ActionName?.Value);
    const task = action && isTaskAction(action) && request.TargetId ? await required(TasksService.get(String(request.TargetId))) : undefined;
    let values: ReturnType<typeof validateProposal> | null = null;
    if (!input.reject) {
      try { values = validateProposal(request, project, task, { pending, statuses: input.statuses, stages: input.stages, projectId: input.projectId }); }
      catch { throw new ReviewBlocked("The action, target or expected value is invalid or stale. Refresh and create a new proposal."); }
    }
    const origin = configuredChoice(input.origins, ["Human review", "User", "Manual", "App", "Agent review", "User approved"]);
    const pendingOutcome = configuredChoice(input.outcomes, ["Pending", "Started", "Applying", "In progress"]);
    // Write an audit reservation BEFORE the target. A partial attempt cannot be silently replayed.
    const audit = await required(ActivityService.create({
      Title: input.reject ? "Request rejection started" : "Request application started", ProjectId: Number(input.projectId),
      EntityType: action && isTaskAction(action) ? "Task" : "Project", EntityId: request.TargetId, ActionName: request.ActionName?.Value,
      BeforeValue: request.ExpectedValue ?? "", AfterValue: request.ProposedValue ?? "", RequestId: id, OccurredAt: new Date().toISOString(),
      ...(origin ? { Origin: { Value: origin } } : {}), ...(pendingOutcome ? { Outcome: { Value: pendingOutcome } } : {}),
    }));
    if (typeof audit.ID !== "number") throw new ReviewBlocked("The review audit could not be confirmed. No target change was made.");
    if (values) {
      // Recheck after recording the reservation to narrow the non-transactional write window.
      const latestProject = await required(ProjectsService.get(input.projectId));
      const latestTask = isTaskAction(values.action) ? await required(TasksService.get(String(request.TargetId))) : undefined;
      if (currentValue(values.action, latestProject, latestTask) !== values.before || (latestTask && latestTask.ProjectId !== request.ProjectId)) throw new ReviewBlocked("The target changed during review. The attempt is recorded; no update was applied.");
      switch (values.action) {
        case "task-status": await required(TasksService.update(String(request.TargetId), { TaskStatus: { Value: values.after } })); break;
        case "task-due": await required(TasksService.update(String(request.TargetId), { DueOn: toSpDate(values.after) })); break;
        case "task-owner": await required(TasksService.update(String(request.TargetId), { AssignedTo: values.after })); break;
        case "project-stage": await required(ProjectsService.update(input.projectId, { Stage: { Value: values.after } })); break;
        case "project-next": await required(ProjectsService.update(input.projectId, { NextAction: values.after })); break;
      }
      changed = true;
    }
    await required(RequestsService.update(String(id), {
      RequestState: { Value: input.reject ? rejected : applied }, ReviewNote: input.reviewNote.trim(),
      ...(!input.reject ? { AppliedAt: new Date().toISOString() } : {}),
    }));
    const outcome = configuredChoice(input.outcomes, input.reject ? ["Rejected", "Declined"] : ["Applied", "Succeeded", "Success", "Completed"]);
    await required(ActivityService.update(String(audit.ID), {
      Title: input.reject ? "Request rejected" : "Request applied", OccurredAt: new Date().toISOString(),
      ...(outcome ? { Outcome: { Value: outcome } } : {}),
    }));
    return { ok: true, message: input.reject ? "Request rejected" : "Request applied and recorded" };
  } catch (error) {
    console.error("Request review failed", error);
    return { ok: false, message: changed ? "The target was updated, but final review or audit confirmation failed. Inspect the target and activity; do not reapply this request." : error instanceof ReviewBlocked ? error.message : "Review could not be completed. Inspect the activity and target before retrying." };
  } finally { reviewing.delete(id); }
}
