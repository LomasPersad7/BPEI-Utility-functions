import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { TimeService } from "@/data/api";
import { PAGE_SIZE, dateOnly, toSpDate, toTimeEntry, type TimeEntry } from "@/data/tracker";
import { connectorFailure, fetchPage, save, type Page } from "@/lib/sp";
import { readTimerPointer, useAppStore, type TimerPointer } from "@/lib/store";
import { completePages, configuredChoice, dayKey, periodFilter, planStop, type Period } from "@/lib/time-math";
import { reconcileManualSubmission, type ManualSubmission } from "@/lib/manual-submission";
import type { Time_log_9426df72Read, Time_log_9426df72Write } from "../../generated/models/Time_log_9426df72Model";

export async function readTimer(pointer: TimerPointer): Promise<TimeEntry | null> {
  const result = await TimeService.getAll({ filter: `EntryKey eq '${pointer.key.replaceAll("'", "''")}'`, top: 2 });
  if (!result.success) connectorFailure(result.error);
  if (result.skipToken || result.data.length > 1) throw new Error("Timer reference is not unique");
  return result.data[0] ? toTimeEntry(result.data[0]) : null;
}

export function useTimerRecord() {
  const pointer = useAppStore((s) => s.timer);
  return useQuery({ queryKey: ["active-timer", pointer?.key], queryFn: () => pointer ? readTimer(pointer) : null, enabled: !!pointer, retry: false });
}

export async function startTimer(input: { projectId: string; roundId?: string; note: string; category: string; states: string[] }): Promise<boolean> {
  const store = useAppStore.getState();
  if (store.timerBusy || store.timer || readTimerPointer()) {
    toast.error("Finish the current timer before starting another.");
    return false;
  }
  const running = configuredChoice(input.states, ["Running", "Active"]);
  const logged = configuredChoice(input.states, ["Logged", "Stopped", "Completed"]);
  if (!running || !logged) { toast.error("The timer needs configured running and logged states."); return false; }
  store.setTimerBusy(true);
  try {
    const pointer = { key: crypto.randomUUID() };
    store.setTimer(pointer); // Refuse to start if the reload-safe metadata cannot be saved.
    const now = new Date();
    const result = await save(() => TimeService.create({
      Title: input.note.trim() || "Project work", ProjectId: Number(input.projectId),
      ...(input.roundId ? { RoundId: Number(input.roundId) } : {}),
      WorkDate: toSpDate(dayKey(now)), Hours: 0, WorkCategory: { Value: input.category },
      StartedOn: now.toISOString(), EntryState: { Value: running }, EntryKey: pointer.key,
    }), "Couldn't confirm that the timer started. Check the saved timer before trying again.");
    return result.ok;
  } catch { toast.error("The timer reference could not be saved. Check browser storage access."); return false; }
  finally { store.setTimerBusy(false); }
}

export async function stopTimer(pointer: TimerPointer, states: string[]): Promise<boolean> {
  const store = useAppStore.getState();
  if (store.timerBusy) return false;
  const currentPointer = readTimerPointer();
  if (currentPointer && currentPointer.key !== pointer.key) {
    toast.error("The active timer changed in another window. Refresh before stopping it.");
    return false;
  }
  const logged = configuredChoice(states, ["Logged", "Stopped", "Completed"]);
  if (!logged) { toast.error("A logged timer state must be configured."); return false; }
  store.setTimerBusy(true);
  try {
    // A failed/repeated stop uses the same timestamp and row, including after reload.
    const stopped = { ...pointer, stopAt: pointer.stopAt ?? currentPointer?.stopAt ?? new Date().toISOString() };
    store.setTimer(stopped);
    const entry = await readTimer(stopped);
    if (!entry) { toast.error("The saved timer was not found. Refresh before trying again."); return false; }
    const plan = planStop(entry, stopped.stopAt);
    if (!plan.alreadyStopped) {
      const result = await save(() => TimeService.update(entry.id, {
        StoppedOn: plan.stoppedOn, Hours: plan.hours, EntryState: { Value: logged },
      }), "Couldn't save the stopped timer. Your stop time is retained for retry.");
      if (!result.ok) return false;
    }
    if (readTimerPointer()?.key === pointer.key) store.setTimer(null);
    toast.success(plan.alreadyStopped ? "This timer was already logged." : "Time logged");
    return true;
  } catch (error) {
    console.error("Timer stop failed", error);
    toast.error("Couldn't finish the timer. Refresh and retry; no extra time entry is created.");
    return false;
  } finally { store.setTimerBusy(false); }
}

/** Explicit page-token navigation. Accumulated report data remains in the query cache. */
export function usePeriodEntries(period: Period, revision: number) {
  const client = useQueryClient();
  const [tokens, setTokens] = useState<(string | undefined)[]>([undefined]);
  const [index, setIndex] = useState(0);
  const token = tokens[index];
  const key = (skipToken?: string) => ["time-report", period.start, period.end, revision, { skipToken }];
  const query = useQuery({
    queryKey: key(token),
    queryFn: () => fetchPage(TimeService.getAll({ filter: periodFilter(period), orderBy: ["ID asc"], top: PAGE_SIZE, skipToken: token }), toTimeEntry),
    staleTime: Number.POSITIVE_INFINITY,
    gcTime: 30 * 60 * 1000,
  });
  const pages = tokens.map((value, i) => i === index ? query.data : client.getQueryData<Page<TimeEntry>>(key(value)));
  const rows = [...new Map(pages.flatMap((page) => page?.rows ?? []).map((row) => [row.id, row])).values()];
  const fresh = tokens.every((value) => {
    const state = client.getQueryState(key(value));
    return state?.status === "success" && !state.isInvalidated && state.fetchStatus === "idle";
  });
  const next = query.data?.next;
  return {
    query, rows, pageRows: query.data?.rows ?? [], index, complete: query.isSuccess && fresh && completePages(pages),
    hasPrev: index > 0, hasNext: Boolean(next),
    previous: () => { if (index > 0 && !query.isFetching) setIndex(index - 1); },
    next: () => {
      if (!next || query.isFetching) return;
      if (index === tokens.length - 1) setTokens([...tokens, next]);
      setIndex(index + 1);
    },
  };
}

export type ManualTimePayload = Omit<Time_log_9426df72Write, "ID" | "EntryKey">;

export async function submitManualTime(submission: ManualSubmission<ManualTimePayload>): Promise<boolean> {
  try {
    const result = await reconcileManualSubmission(submission, {
      find: async (key) => {
        const result = await TimeService.getAll({ filter: `EntryKey eq '${key.replaceAll("'", "''")}'`, top: 2 });
        if (!result.success) connectorFailure(result.error);
        if (result.skipToken) throw new Error("Submission key is not unique");
        return result.data;
      },
      create: async (payload, key) => {
        const result = await TimeService.create({ ...payload, EntryKey: key });
        if (!result.success) connectorFailure(result.error);
        return result.data;
      },
      matches: (row: Time_log_9426df72Read, payload, key) =>
        typeof row.ID === "number" && row.ID > 0 && row.EntryKey === key &&
        row.Title === payload.Title && (row.ProjectId ?? null) === (payload.ProjectId ?? null) &&
        (row.RoundId ?? null) === (payload.RoundId ?? null) && dateOnly(row.WorkDate) === dateOnly(payload.WorkDate) &&
        typeof row.Hours === "number" && typeof payload.Hours === "number" && Math.abs(row.Hours - payload.Hours) < 1e-9 &&
        row.WorkCategory?.Value === payload.WorkCategory?.Value &&
        (!payload.EntryState || row.EntryState?.Value === payload.EntryState.Value),
    });
    if (result.status === "saved") return true;
    if (result.status === "busy") return false;
  } catch (error) { console.error("Manual time confirmation failed", error); }
  toast.error(submission.attempted
    ? "The original time entry is not confirmed. Use Check saved entry to look for it; do not submit the same hours as a new entry."
    : "Couldn't check for an existing time entry. No create was attempted; retry when the connection is available.");
  return false;
}
