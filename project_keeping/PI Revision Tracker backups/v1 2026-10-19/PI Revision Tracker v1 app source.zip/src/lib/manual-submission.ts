// One logical manual submission may issue at most one create request. A retry
// reconciles by its stable key rather than assuming a missing acknowledgement
// means the write did not happen. Payloads remain in session memory only.
export interface ManualSubmission<T> {
  key: string;
  payload: T;
  attempted: boolean;
  busy: boolean;
}

export function newManualSubmission<T>(payload: T, key = crypto.randomUUID()): ManualSubmission<T> {
  return { key, payload, attempted: false, busy: false };
}

export async function reconcileManualSubmission<T, R>(
  submission: ManualSubmission<T>,
  operations: {
    find: (key: string) => Promise<R[]>;
    create: (payload: T, key: string) => Promise<R>;
    matches: (row: R, payload: T, key: string) => boolean;
  },
): Promise<{ status: "saved"; row: R } | { status: "pending" | "busy" }> {
  if (submission.busy) return { status: "busy" };
  submission.busy = true;
  try {
    const findExisting = async () => {
      const rows = await operations.find(submission.key);
      if (rows.length > 1) throw new Error("Submission key is not unique");
      if (!rows.length) return null;
      if (!operations.matches(rows[0], submission.payload, submission.key)) {
        throw new Error("Saved entry differs from the submitted entry");
      }
      return rows[0];
    };
    const existing = await findExisting();
    if (existing) return { status: "saved", row: existing };
    if (submission.attempted) return { status: "pending" };
    submission.attempted = true;
    try {
      const created = await operations.create(submission.payload, submission.key);
      if (operations.matches(created, submission.payload, submission.key)) return { status: "saved", row: created };
    } catch {
      // A create can commit even when its acknowledgement is lost. Reconcile
      // once now; later button presses may only reconcile, never create again.
    }
    const confirmed = await findExisting();
    return confirmed ? { status: "saved", row: confirmed } : { status: "pending" };
  } finally {
    submission.busy = false;
  }
}
