// SharePoint plumbing shared by every page: page-at-a-time list reads keyed by
// the connector's skip token, configured Choice values, and write helpers.
import { useState } from "react";
import { useQuery, type QueryKey, type UseQueryResult } from "@tanstack/react-query";
import type { IOperationResult } from "@microsoft/managed-apps/data";
import { toast } from "sonner";
import { parseChoices } from "@/data/tracker";
import { connectorErrorMessage, isConnectorPolicyBlock } from "@/lib/connector-error";

export const CONNECTOR = "SharePoint";

export interface Page<T> {
  rows: T[];
  next?: string;
}

/** Rethrows a failed generated call's own error so a policy block stays recognizable. */
export function connectorFailure(error: unknown): never {
  console.error("connector error", error);
  if (error) throw error;
  throw new Error("Connector request failed");
}

export async function fetchPage<R, T>(
  request: Promise<IOperationResult<R[]>>,
  map: (row: R) => T | null,
): Promise<Page<T>> {
  const result = await request;
  if (!result.success) connectorFailure(result.error);
  const rows: T[] = [];
  for (const row of result.data ?? []) {
    const mapped = map(row);
    if (mapped) rows.push(mapped);
  }
  return { rows, next: result.skipToken?.trim() || undefined };
}

export interface PagedList<T> {
  query: UseQueryResult<Page<T>, Error>;
  rows: T[];
  hasPrev: boolean;
  hasNext: boolean;
  /** More than one page exists, so counts and totals cover the visible page only. */
  paged: boolean;
  showPrev: () => void;
  showNext: () => void;
}

/** One page at a time, keyed by its skip token; Previous/Next follow the connector's continuation. */
export function usePaged<T>(key: QueryKey, load: (skipToken?: string) => Promise<Page<T>>): PagedList<T> {
  const serializedKey = JSON.stringify(key);
  const [savedKey, setSavedKey] = useState(serializedKey);
  const [skipToken, setSkipToken] = useState<string | undefined>();
  const [previous, setPrevious] = useState<(string | undefined)[]>([]);
  if (savedKey !== serializedKey) {
    setSavedKey(serializedKey);
    setSkipToken(undefined);
    setPrevious([]);
  }
  const currentToken = savedKey === serializedKey ? skipToken : undefined;
  const query = useQuery({ queryKey: [...key, { skipToken: currentToken }], queryFn: () => load(currentToken) });
  const next = query.data?.next;
  return {
    query,
    rows: query.data?.rows ?? [],
    hasPrev: previous.length > 0,
    hasNext: Boolean(next),
    paged: previous.length > 0 || Boolean(next),
    showPrev() {
      if (previous.length === 0 || query.isFetching) return;
      setSkipToken(previous[previous.length - 1]);
      setPrevious((tokens) => tokens.slice(0, -1));
    },
    showNext() {
      if (!next || query.isFetching) return;
      setPrevious((tokens) => [...tokens, skipToken]);
      setSkipToken(next);
    },
  };
}

export type Choices = UseQueryResult<string[], Error>;

/** Configured Choice values, read through the generated referenced-entity operation. */
export function useChoices(key: QueryKey, request: () => Promise<IOperationResult<unknown>>): Choices {
  return useQuery({
    queryKey: key,
    queryFn: async () => {
      const result = await request();
      if (!result.success) connectorFailure(result.error);
      return parseChoices(result.data);
    },
    staleTime: Number.POSITIVE_INFINITY,
  });
}

function failureToast(error: unknown, failure: string) {
  toast.error(isConnectorPolicyBlock(error) ? connectorErrorMessage(error, CONNECTOR) : failure);
}

export type Saved<T> = { ok: true; data: T } | { ok: false };

export async function save<T>(request: () => Promise<IOperationResult<T>>, failure: string): Promise<Saved<T>> {
  let error: unknown;
  try {
    const result = await request();
    if (result.success) return { ok: true, data: result.data };
    error = result.error;
  } catch (caught) {
    error = caught;
  }
  console.error("connector error", error);
  failureToast(error, failure);
  return { ok: false };
}

/** A successful, ID-filtered list read must prove absence; failures never mean deleted. */
export function deletionConfirmed(check: { success: boolean; data: unknown }): boolean {
  return check.success && Array.isArray(check.data) && check.data.length === 0;
}

export async function remove(
  del: () => Promise<void>,
  read: () => Promise<IOperationResult<unknown>>,
  failure: string,
): Promise<boolean> {
  let error: unknown;
  try {
    await del();
    const check = await read();
    if (deletionConfirmed(check)) return true;
    error = check.error;
  } catch (caught) {
    error = caught;
  }
  console.error("Deletion could not be verified", error);
  failureToast(error, `${failure} Refresh the list before retrying; deletion could not be verified.`);
  return false;
}

/** Sends null to clear a SharePoint date column (the generated write model types dates as strings). */
export function clearDate<K extends string>(key: K): Partial<Record<K, string>> {
  return { [key]: null } as unknown as Partial<Record<K, string>>;
}
