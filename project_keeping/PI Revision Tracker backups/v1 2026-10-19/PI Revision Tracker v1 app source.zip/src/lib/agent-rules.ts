import type { Agent_requests_9426df72Read } from "../../generated/models/Agent_requests_9426df72Model";
import type { Projects_9426df72Read } from "../../generated/models/Projects_9426df72Model";
import type { Tasks_9426df72Read } from "../../generated/models/Tasks_9426df72Model";
import { dateOnly } from "@/data/tracker";
import { normalized, validDay } from "@/lib/time-math";

export type AllowedAction = "task-status" | "task-due" | "task-owner" | "project-stage" | "project-next";
const ALLOWED: Record<AllowedAction, string[]> = {
  "task-status": ["Update task status", "Set task status", "Task status", "UpdateTaskStatus"],
  "task-due": ["Update task due date", "Set task due date", "Task due date", "UpdateTaskDueDate", "UpdateTaskDeadline"],
  "task-owner": ["Update task assignee", "Set task assignee", "Task assignee", "UpdateTaskAssignee", "UpdateTaskOwner"],
  "project-stage": ["Update project stage", "Set project stage", "Project stage", "UpdateProjectStage", "UpdateProjectStatus"],
  "project-next": ["Update next action", "Set next action", "Project next action", "UpdateNextAction", "UpdateProjectNextAction", "SetProjectNextAction"],
};
export function allowedAction(value: string | null | undefined): AllowedAction | null {
  for (const [key, labels] of Object.entries(ALLOWED)) {
    if (labels.some((label) => normalized(label) === normalized(value))) return key as AllowedAction;
  }
  return null;
}
export const isTaskAction = (action: AllowedAction) => action.startsWith("task-");
export const defaultAgentMode = (choices: string[] | undefined) =>
  choices?.find((choice) => /approval|propos/i.test(choice)) ?? null;

export function currentValue(action: AllowedAction, project: Projects_9426df72Read, task?: Tasks_9426df72Read): string {
  switch (action) {
    case "task-status": return task?.TaskStatus?.Value ?? "";
    case "task-due": return dateOnly(task?.DueOn) ?? "";
    case "task-owner": return task?.AssignedTo ?? "";
    case "project-stage": return project.Stage?.Value ?? "";
    case "project-next": return project.NextAction ?? "";
  }
}

/** No executable payloads, deletes, time writes, emails, approvals, or publishing. */
export function validateProposal(
  request: Agent_requests_9426df72Read,
  project: Projects_9426df72Read,
  task: Tasks_9426df72Read | undefined,
  options: { statuses: string[]; stages: string[]; pending: string; projectId: string },
): { action: AllowedAction; before: string; after: string } {
  const action = allowedAction(request.ActionName?.Value);
  if (!action) throw new Error("This action is not allowed.");
  if (request.AppliedAt || request.RequestState?.Value !== options.pending) throw new Error("This request is no longer pending.");
  if (request.ID === undefined || !request.RequestKey?.trim()) throw new Error("The request needs a stable request key.");
  if (request.ProjectId !== Number(options.projectId) || project.ID !== request.ProjectId) throw new Error("The project does not match this request.");
  if (isTaskAction(action)) {
    if (!task || task.ID !== request.TargetId || task.ProjectId !== request.ProjectId) throw new Error("The task does not belong to this project.");
  } else if (request.TargetId !== request.ProjectId) {
    throw new Error("The target project does not match this request.");
  }
  const before = currentValue(action, project, task);
  if (before !== (request.ExpectedValue ?? "")) throw new Error("The record changed after this proposal. Create a new request.");
  const after = request.ProposedValue ?? "";
  if (after === before) throw new Error("The requested value is already present; nothing was applied.");
  if (action === "task-status" && !options.statuses.includes(after)) throw new Error("The proposed task status is not configured.");
  if (action === "project-stage" && !options.stages.includes(after)) throw new Error("The proposed stage is not configured.");
  if (action === "task-due" && !validDay(after)) throw new Error("Use a valid deadline in YYYY-MM-DD format.");
  if ((action === "task-owner" || action === "project-next") && (!after.trim() || after.length > 255)) throw new Error("Use between 1 and 255 characters.");
  return { action, before, after };
}

/** A refreshed request must still be exactly the one the reviewer saw. */
export function sameProposal(a: Agent_requests_9426df72Read, b: Agent_requests_9426df72Read): boolean {
  return a.ID === b.ID && a.ProjectId === b.ProjectId && a.TargetId === b.TargetId &&
    a.RequestKey === b.RequestKey && a.ActionName?.Value === b.ActionName?.Value &&
    a.ExpectedValue === b.ExpectedValue && a.ProposedValue === b.ProposedValue &&
    a.RequestMode?.Value === b.RequestMode?.Value && a.RequestState?.Value === b.RequestState?.Value &&
    a.Reason === b.Reason && a.Modified === b.Modified && a.AppliedAt === b.AppliedAt;
}
