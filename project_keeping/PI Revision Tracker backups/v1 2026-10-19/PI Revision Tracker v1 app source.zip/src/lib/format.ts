import { differenceInCalendarDays, format, parseISO } from "date-fns";
import { FINAL_STAGE } from "@/data/tracker";

export type Tone = "success" | "pending" | "active" | "inactive" | "danger";

// One state-tone map for every status mark: badges, dots and stage bars.
// green done/on time · amber pending/today · blue active/upcoming · gray inactive · red overdue/high.
export const TONE_DOT: Record<Tone, string> = {
  success: "bg-emerald-600 dark:bg-emerald-400",
  pending: "bg-amber-600 dark:bg-amber-400",
  active: "bg-sky-600 dark:bg-sky-400",
  inactive: "bg-zinc-500 dark:bg-zinc-400",
  danger: "bg-red-600 dark:bg-red-400",
};

export const TONE_BADGE: Record<Tone, string> = {
  success:
    "border-emerald-300 bg-emerald-50 text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950 dark:text-emerald-100",
  pending:
    "border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-100",
  active: "border-sky-300 bg-sky-50 text-sky-900 dark:border-sky-800 dark:bg-sky-950 dark:text-sky-100",
  inactive: "border-border bg-muted text-foreground",
  danger: "border-red-300 bg-red-50 text-red-900 dark:border-red-800 dark:bg-red-950 dark:text-red-100",
};

export const todayIso = () => format(new Date(), "yyyy-MM-dd");
export const fmtDay = (iso: string) => format(parseISO(iso), "MMM d");
export const fmtFull = (iso: string) => format(parseISO(iso), "MMM d, yyyy");
export const fmtHours = (h: number) => `${Number(h.toFixed(2))} h`;
export const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? "" : "s"}`;

/** Calendar days from `fromIso` to `toIso` (negative when `toIso` is earlier). */
export const daysBetween = (fromIso: string, toIso: string) =>
  differenceInCalendarDays(parseISO(toIso), parseISO(fromIso));

/**
 * Factual deadline state. Open items report against today (overdue / due today /
 * due in N days); completed items report against their completion date.
 */
export function dueState(
  due: string | null,
  completedOn: string | null = null,
  done = false,
  today = todayIso(),
): { tone: Tone; label: string } | null {
  if (!due) return null;
  if (completedOn) {
    const late = daysBetween(due, completedOn);
    return late <= 0 ? { tone: "success", label: "On time" } : { tone: "pending", label: `${plural(late, "day")} late` };
  }
  if (done) return null;
  const left = daysBetween(today, due);
  if (left < 0) return { tone: "danger", label: `Overdue by ${plural(-left, "day")}` };
  if (left === 0) return { tone: "pending", label: "Due today" };
  return { tone: "active", label: `Due in ${plural(left, "day")}` };
}

/** True when an open item's due date has passed. */
export const isOverdue = (due: string | null, done: boolean, today = todayIso()) =>
  Boolean(due) && !done && daysBetween(today, due as string) < 0;

const PRIORITY_TONE: Record<string, Tone> = { High: "danger", Medium: "pending", Low: "inactive" };
const STATUS_TONE: Record<string, Tone> = { Done: "success", "In progress": "active", "To do": "inactive" };

export const priorityTone = (priority: string | null): Tone => (priority && PRIORITY_TONE[priority]) || "inactive";
export const statusTone = (status: string | null): Tone => (status && STATUS_TONE[status]) || "inactive";

export const stageTone = (stage: string | null): Tone => (stage === FINAL_STAGE ? "success" : "active");

const PROJECT_STATUS_TONE: Record<string, Tone> = { Completed: "success", Ongoing: "active", Pending: "pending", "On hold": "inactive" };

export const projectStatusTone = (status: string | null): Tone => (status && PROJECT_STATUS_TONE[status]) || "inactive";
