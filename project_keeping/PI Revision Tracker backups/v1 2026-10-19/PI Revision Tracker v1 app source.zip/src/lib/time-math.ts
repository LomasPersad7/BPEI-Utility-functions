import { addDays, addMonths, format, isValid, parseISO, startOfMonth, startOfWeek } from "date-fns";
import type { TimeEntry } from "@/data/tracker";

export type ReportMode = "week" | "month" | "period";
export interface Period { start: string; end: string }
export const dayKey = (date: Date) => format(date, "yyyy-MM-dd");
export const normalized = (value: string | null | undefined) => (value ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
export const configuredChoice = (choices: string[] | undefined, names: string[]) =>
  choices?.find((choice) => names.some((name) => normalized(choice) === normalized(name))) ?? null;

export function validDay(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && isValid(parseISO(value)) && dayKey(parseISO(value)) === value;
}

/** End is exclusive. Weeks are Monday–Sunday, in the browser's time zone. */
export function periodFor(mode: "week" | "month", anchor: string): Period {
  const date = parseISO(anchor);
  const start = mode === "week" ? startOfWeek(date, { weekStartsOn: 1 }) : startOfMonth(date);
  return { start: dayKey(start), end: dayKey(mode === "week" ? addDays(start, 7) : addMonths(start, 1)) };
}

export function isRunning(entry: Pick<TimeEntry, "startedOn" | "stoppedOn" | "state">): boolean {
  return Boolean(entry.startedOn && !entry.stoppedOn) || ["running", "active"].includes(normalized(entry.state));
}

/** A stop overwrites the existing row, never appends another time entry. */
export function planStop(entry: Pick<TimeEntry, "startedOn" | "stoppedOn" | "hours">, requestedStop: string) {
  if (entry.stoppedOn) return { alreadyStopped: true as const, stoppedOn: entry.stoppedOn, hours: entry.hours };
  const start = Date.parse(entry.startedOn ?? "");
  const stop = Date.parse(requestedStop);
  if (!Number.isFinite(start) || !Number.isFinite(stop) || stop < start) throw new Error("Invalid timer interval");
  return { alreadyStopped: false as const, stoppedOn: requestedStop, hours: (stop - start) / 3_600_000 };
}

export interface DailySlice { date: string; hours: number }

/** Split actual elapsed time at local midnights, including DST and month boundaries. */
export function allocateTime(entry: TimeEntry, period: Period): DailySlice[] {
  if (isRunning(entry)) return [];
  if (entry.hours === null || entry.hours < 0) throw new Error("Hours are missing or invalid");
  if (!entry.startedOn && !entry.stoppedOn) {
    if (!entry.date || !validDay(entry.date)) throw new Error("Work date is missing or invalid");
    return entry.date >= period.start && entry.date < period.end ? [{ date: entry.date, hours: entry.hours }] : [];
  }
  const start = Date.parse(entry.startedOn ?? "");
  const end = Date.parse(entry.stoppedOn ?? "");
  if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) throw new Error("Invalid timer interval");
  if (start === end) return [];
  let cursor = Math.max(start, parseISO(period.start).getTime());
  const limit = Math.min(end, parseISO(period.end).getTime());
  const slices: DailySlice[] = [];
  while (cursor < limit) {
    const day = new Date(cursor);
    const next = new Date(day.getFullYear(), day.getMonth(), day.getDate() + 1).getTime();
    const boundary = Math.min(next, limit);
    slices.push({ date: dayKey(day), hours: entry.hours * (boundary - cursor) / (end - start) });
    cursor = boundary;
  }
  return slices;
}

export function periodFilter(period: Period): string {
  const start = parseISO(period.start).toISOString();
  const end = parseISO(period.end).toISOString();
  return `(WorkDate ge '${period.start}T00:00:00Z' and WorkDate lt '${period.end}T00:00:00Z') or (StartedOn lt '${end}' and (StoppedOn gt '${start}' or StoppedOn eq null))`;
}

/** Never treat a loaded page as a full report. */
export function completePages<T>(pages: ({ rows: T[]; next?: string } | undefined)[]): boolean {
  return pages.length > 0 && pages.every((page) => page !== undefined) && !pages.at(-1)?.next;
}
