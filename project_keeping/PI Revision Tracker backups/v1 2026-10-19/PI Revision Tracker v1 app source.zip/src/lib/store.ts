import { create } from "zustand";

// Global client state shared across components/routes. ONE module-scoped store,
// no Provider needed — import `useAppStore` anywhere. Use `useState` for
// component-local state; let TanStack Query own server/connector data (don't
// mirror it here). NEVER use raw React Context for mutable shared state.
//
// Rules:
//   • Put actions INSIDE the store (set-based, immutable updates); components call them.
//   • Read with a NARROW selector — `useAppStore((s) => s.items)`, never
//     `useAppStore()` with no selector. Don't return a fresh object/array from a
//     selector (it re-renders on every change); group with `useShallow`:
//     `import { useShallow } from "zustand/react/shallow"`
//     `const { a, b } = useAppStore(useShallow((s) => ({ a: s.a, b: s.b })));`
//
// Example (replace `AppState` with the app's real state + actions):
//   interface AppState {
//     items: Item[];
//     addItem: (text: string) => void;
//     toggleItem: (id: string) => void;
//   }
//   export const useAppStore = create<AppState>((set) => ({
//     items: [],
//     addItem: (text) =>
//       set((s) => ({ items: [...s.items, { id: crypto.randomUUID(), text, done: false }] })),
//     toggleItem: (id) =>
//       set((s) => ({ items: s.items.map((i) => (i.id === id ? { ...i, done: !i.done } : i)) })),
//   }));
//
// In components:
//   const items = useAppStore((s) => s.items);      // read (targeted re-render)
//   const addItem = useAppStore((s) => s.addItem);  // action (stable reference)

export interface TimerPointer { key: string; stopAt?: string }
const TIMER_KEY = "pi-revision-tracker:timer-reference";

export function readTimerPointer(): TimerPointer | null {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(TIMER_KEY) ?? "null");
    if (typeof value !== "object" || value === null || !("key" in value) || typeof value.key !== "string" || !/^[a-f0-9-]{36}$/i.test(value.key)) return null;
    if ("stopAt" in value && (typeof value.stopAt !== "string" || !Number.isFinite(Date.parse(value.stopAt)))) return null;
    return { key: value.key, ...("stopAt" in value && typeof value.stopAt === "string" ? { stopAt: value.stopAt } : {}) };
  } catch { return null; }
}

interface AppState {
  timer: TimerPointer | null;
  timerBusy: boolean;
  setTimer: (timer: TimerPointer | null) => void;
  setTimerBusy: (timerBusy: boolean) => void;
}

// Only the random timer key and a stop timestamp are persisted, never record content.
export const useAppStore = create<AppState>((set) => ({
  timer: readTimerPointer(),
  timerBusy: false,
  setTimer: (timer) => {
    if (timer) localStorage.setItem(TIMER_KEY, JSON.stringify(timer));
    else localStorage.removeItem(TIMER_KEY);
    set({ timer });
  },
  setTimerBusy: (timerBusy) => set({ timerBusy }),
}));
