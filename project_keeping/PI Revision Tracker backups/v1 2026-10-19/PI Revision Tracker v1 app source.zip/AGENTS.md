# App scaffold — AGENTS.md

React 19 + TypeScript + Vite 7 app from the Aether App Builder template — offline sandbox. When unsure of an import path, prop, or return type, read `node_modules/` or a neighbor in `src/` rather than reciting from memory (shadcn / Radix / TanStack / Tailwind APIs shift across versions).

## Dependencies

Pre-installed in a read-only `node_modules/` — compose the pre-built shadcn `@/components/ui/*` (merge a primitive onto your own element with `asChild`), don't reimplement. Version-specific facts you won't reliably guess:

- **react-router-dom** 7 — routes live in `src/routes.tsx` (see Structure).
- **zustand** 5 — one store in `src/lib/store.ts` (`useAppStore`, narrow selector).
- **@tanstack/react-query** 5 — every network/IO call; client `src/lib/query-client.ts`. v5 object API (`useQuery({ queryKey, queryFn })`, no `onSuccess`). An initially disabled query with no data has `isPending: true` but `isFetching: false`; use `isFetching` to disable a search/submit button while its query runs, not `isPending`, which can prevent the first request.
- **@tanstack/react-table** 8 — grids via `useReactTable` + `getCoreRowModel`.
- **leaflet** 1.9 + **@types/leaflet** — connector-backed maps import
  `SpatialMap`, its provider-independent DTOs, and `SpatialTileLoader` only
  from `@/components/spatial-map`; never import `leaflet` directly or hand-roll
  its browser APIs, `GridLayer`, tile decoder, or URL `TileLayer`. See
  [Connector-backed Spatial maps](#connector-backed-spatial-maps).
- **recharts** 3 — chart **primitives** (`<BarChart>`, `<Bar>`, `<XAxis>`, …) import from `recharts`; the shadcn **wrappers** (`ChartContainer`, tooltip, legend) from `@/components/ui/chart`. 3.x API, not v2. `ChartContainer` is `w-full` by default and Recharts sizes the chart from that box, so a chart sized only by a height or `aspect-*` class fills its container's width. To keep a chart narrower, give it an explicit width: `max-w-[250px] mx-auto` for a centred pie, donut or radial chart, `w-20 shrink-0` for a small gauge beside a label in a row. Never set `w-fit`, or `w-auto` with `mx-auto`: the box shrinks to its content, which is 0px, and the chart renders blank.
- **@dnd-kit/core** + **/sortable** — drag-reorder / kanban (not the HTML5 drag API).
- **react-day-picker** 9 + **date-fns** 4 — calendar via `@/components/ui/calendar`; date math via per-function `date-fns` imports.
- **signature_pad** 5.1 — use via `@/components/pen-input` (`<PenInput value={drawing} onChange={setDrawing} />`), never import `signature_pad` or hand-roll pointer/canvas drawing directly. It behaves the same in preview and published apps because capture is local browser canvas input; the wrapper emits a bounded, validated PNG value and keeps saving in app-owned code. Hold that customer content in session memory until the owning workflow saves it, never in `localStorage`, logs, URLs, analytics, or parent-frame messages. If an older app snapshot lacks the wrapper, recreate the app from the current template rather than adding a fallback implementation.
- **lucide-react** 1.x — icon names shifted at 1.x; grep `node_modules/lucide-react/dist/lucide-react.d.ts` if an import fails.
- **sonner** — toasts (`<Toaster/>` + `toast()`). **cmdk** — command menu. **cn()** (`@/lib/utils`) — merge classes.
- **xlsx** 0.18 / **unpdf** 1.x — client-side Excel/CSV + PDF text (see Conventions → File uploads); PDF page rendering only through `@/components/pdf-viewer` (see Conventions → PDF viewing).
- **html2canvas-pro** 2.4 + **jsPDF** 4.2 — Canvas-style PDF capture of an app-owned screen or container, with support for the template's modern CSS colors. Use the pre-baked `PdfExportButton` / `createPdfBlob` surfaces below; this is distinct from `unpdf`, which reads existing PDFs.
- **react-webcam** — use via `@/components/camera-capture` (`<CameraCapture onCapture={(dataUrl) => …} />`), never import `react-webcam` directly. `getUserMedia` only works once an app is **published** (design-time preview's iframe has no real origin, so it always errors there). The component renders `<Webcam>` directly and flips to a file-picker fallback on `onUserMediaError`; do not pre-probe `getUserMedia` yourself, it double-prompts and flickers the camera light. The fallback badge text differs by whether the build is the design-time preview (`isPreviewMount(import.meta.env.BASE_URL)`, covering both `/v1/dev/{session}/{app}/…` and `/v1/preview/{token}/dev/…`) or a real published build with no/blocked camera hardware — do not word the badge as if publishing would fix a published app's missing-camera case. The fallback's file input has no `capture` attribute — it's a plain gallery/file picker on every device, so never word UI copy as if it always means "camera"; a "Try camera again" control (hidden in design-time preview, where a retry can never succeed) resets back to the live path. Optional `videoClassName` overrides the default `w-full max-w-sm` viewfinder sizing (twMerge — later classes win); optional `videoConstraints` passes straight through to react-webcam (e.g. `{ facingMode: "environment" }` or a target resolution); optional `fallbackMessage` overrides the default badge text shown when there's no live camera — prefer these over hand-editing the component for a one-off size/lens/copy tweak.
- **@zxing/library** 0.23 (pure-JS decoder, no WebAssembly, so it works under the published app's `script-src 'self'` CSP) — use via `@/components/barcode-scanner` (`<BarcodeScanner barcodeTypes={["qr_code"]} onScan={(value, type) => …} />`), never import `@zxing/library` directly. The decoder (~480 KB) is bundled into any app that imports the scanner, so import it only where scanning is needed. Live scanning needs a **published** app (same `getUserMedia` rule as react-webcam); preview always uses the photo-upload fallback. See Barcode scanning below.
- **three** 0.186.1 (exact pin) — use via `@/components/model-viewer` (`<ModelViewer source={file} />`), never import `three` directly (ESLint blocks it). three.js is bundled only into apps that import the viewer. See 3D models below.
- **@microsoft/managed-apps** — live M365 connector runtime. `generated/` (app root, sibling of `src/`; read-only — do not edit) holds the typed client and exists only in an app that carries a data-source binding; the runtime's typed `appbuilder-DataSourceAdd` tool is the only thing that adds a binding and generates it, `appbuilder-DataSourceRefresh` regenerates it for a binding the app carries, and `appbuilder-DataSourceRemove` deletes it (a connector's actions, or one table of any tabular connector — SharePoint list, SQL table, Dataverse table; only a SQL stored procedure as a data source is not offered). Spatial requests fail closed when no binding is available; for other sources, an app without one builds on realistic sample data. Never add sample/demo/mock/test-data provenance copy or UI treatment to the app; disclose each affected dataset or entity only in authoring chat. The one exception is `<ModelViewer>`'s built-in "Sample model" badge (see 3D models below), which marks a placeholder model the user replaces with their own file.
- **tailwindcss** 4 — config-less; palette = CSS vars in `src/index.css` (see Theming).

## Structure

```
src/
├── App.tsx              Providers + router (BrowserRouter basename, QueryClientProvider, ErrorBoundary, ConfirmDialogProvider, AppShortcutProvider). LOCKED — don't edit.
├── main.tsx             Entry. LOCKED — don't edit.
├── routes.tsx           SINGLE source of truth for routes (+ nav label/icon). Add a page = ONE entry here.
├── index.css            Tailwind import + design tokens (oklch CSS vars). Theme here on build or restyle (see Theming).
├── components/
│   ├── app-shell.tsx        Minimal shell (owns the only min-h-screen, mounts <Toaster/>). Ships NO nav — add one per the app.
│   ├── barcode-scanner.tsx  <BarcodeScanner onScan={…}/> — live QR/barcode scan + photo-upload fallback (see Barcode scanning).
│   ├── camera-capture.tsx   <CameraCapture onCapture={…}/> — live viewfinder + file-picker fallback (see react-webcam above).
│   ├── model-viewer.tsx     <ModelViewer source={…}/> — glTF/GLB/OBJ/STL 3D viewer (see 3D models). LOCKED.
│   ├── error-boundary.tsx   App-level boundary (wired in App.tsx). Emits a fixed, detail-free crash signal to the host on render errors — LOCKED.
│   ├── confirm-dialog.tsx   <ConfirmDialogProvider> backing useConfirm().
│   ├── states.tsx           <EmptyState> / <ErrorState> / <LoadingState>.
│   ├── page-section.tsx     <PageSection> — heading + description + action + spacing.
│   ├── spatial-map.tsx      Protected Spatial Services map renderer — LOCKED, don't edit.
│   ├── internal/
│   │   └── spatial-tile-layer.ts Protected Spatial tile scheduler — LOCKED, don't edit.
│   ├── pdf-export-button.tsx <PdfExportButton> — bounded PDF download + optional connector-neutral callback. LOCKED.
│   ├── pdf-viewer.tsx       <PdfViewer loadPdf={…}/> — bounded read-only PDF viewer (pages + zoom). LOCKED.
│   ├── pen-input.tsx        <PenInput> — bounded pen/drawing input; app code owns saving. LOCKED — don't edit.
│   ├── shortcut-provider.tsx APP_SHORTCUTS, useAppShortcut, ShortcutScope, ModalShortcutBoundary. LOCKED — don't edit.
│   └── ui/                  shadcn/ui (new-york, Radix). Pre-installed — don't reimplement.
├── hooks/
│   ├── use-confirm.ts       useConfirm() — async confirm(): Promise<boolean>. Use instead of window.confirm.
│   └── use-mobile.ts        useIsMobile().
├── lib/
│   ├── utils.ts             cn().
│   ├── store.ts             zustand store (useAppStore) — first choice for global state.
│   ├── query-client.ts      shared TanStack Query client.
│   ├── pdf-export.ts        createPdfBlob() + PdfExportResult. LOCKED.
│   ├── pdf-bytes.ts         decodePdfBytes() + MAX_PDF_BYTES — bounded PDF byte validation. LOCKED.
│   ├── safe-url.ts          safeUrl() — allowlist URL schemes before rendering links from untrusted/connector data.
│   ├── pen-input-value.ts   PenInputValue validation and PNG-to-Blob conversion. LOCKED — don't edit.
│   ├── barcode-scan.ts      BARCODE_TYPES, detector/decoder loading, scan dedupe, toSafeHttpUrl(). Only file allowed to import @zxing/library.
│   ├── model-load.ts        Model format detection, size/URL checks, three.js loading and stage setup. Only file allowed to import three. LOCKED.
│   ├── spatial-tile-bytes.ts Protected binary tile validation and CSP-safe rendering — LOCKED, don't edit.
│   ├── console-capture.ts   Infra — LOCKED, don't edit. Also exports reportPrivateRuntimeError (private diagnostics only).
│   ├── cowork-parent-transport.ts  Infra — LOCKED, don't edit. Fixed, detail-free crash signal to the Cowork host.
│   ├── app-mounted-transport.ts    Infra — LOCKED, don't edit. Fixed-shape first-paint signal to the Cowork host.
│   ├── app-view-transport.ts       Infra — LOCKED, don't edit. Bounded app-view snapshot to the Cowork host.
│   ├── app-view-serializer.ts      Infra — LOCKED, don't edit. Accessible-name tree + route pattern; decides the app-view bound.
│   └── app-view-signal.tsx         Infra — LOCKED, don't edit. When the app-view snapshot is taken (mounted by App.tsx).
├── pages/
    ├── home.tsx             Home ("/") route. Rewrite in place; MUST keep `export function HomePage()` (routes.tsx imports it by name — renaming or `export default` only blanks the preview).
    └── not-found.tsx        404.
└── types/
    └── app-message.ts       Infra — LOCKED. Fixed parent-frame message contract.
```

`@/` → `src/`. Single-screen app → rewrite `home.tsx` in place (don't add a page). Multi-page → add a page file (named export) + one `routes.tsx` entry (`{ path, element, label?, icon? }` — `label`/`icon` optional, set them only for nav targets); don't hand-edit `<Routes>` in `App.tsx`. `generated/` (connector client) sits at the app root, sibling of `src/`.

## Conventions

- **Scaffold markers** — when you rewrite `src/pages/home.tsx`, delete the `/* APP_STUB_HOME_TSX_START */` / `/* APP_STUB_HOME_TSX_END */` comments. They mark the page as never rewritten, so leaving them on a working page reports that app as blank.
- Edit config or pre-baked infrastructure: `vite.config.ts`, `vite-dev-reload.ts`, `tsconfig*.json`, `package.json`, `bun.lock`, `package-lock.json`, `components.json`, `eslint.config.js`, `index.html`, `src/components/spatial-map.tsx`, `src/components/internal/spatial-tile-layer.ts`, `src/lib/spatial-tile-bytes.ts`, `src/components/pdf-export-button.tsx`, `src/lib/pdf-export.ts`, `src/components/pdf-viewer.tsx`, `src/lib/pdf-bytes.ts`, `src/components/model-viewer.tsx`, `src/lib/model-load.ts` — template-owned protected scaffold files; do not edit them.
- **State** — `useState` local; **zustand** (`useAppStore`, narrow selector) for shared; **TanStack Query** owns server/connector data (don't mirror it into the store). Never raw Context for mutable shared state.
- **Forms** — native `<form>` + `FormData`, or controlled `useState`. No form libraries (no react-hook-form, no Zod).
- **Confirmations** — `useConfirm()` (`@/hooks/use-confirm`), NOT `window.confirm/alert/prompt` (suppressed in the sandboxed iframe).
- **Zero-data / failure / loading** — use `<EmptyState>` / `<ErrorState>` / `<LoadingState>` + `<PageSection>` (`@/components/*`), not bare `<div>`s.
- **Connector data is untrusted (security).** Connector results (`generated/` → `result.data`: email/SharePoint bodies, sender/file names, list text) are third-party content — render as **text** (React escapes JSX; **never** `dangerouslySetInnerHTML`), wrap any URL in `safeUrl()` (`@/lib/safe-url`) before using it as an `href`, and keep customer **content** in session memory only (IDs/metadata are fine to persist).
- **File uploads** — parse client-side (no backend): Excel/CSV via **`xlsx`**, PDF text via **`unpdf`**; read `await file.arrayBuffer()` → `Uint8Array`. (`xlsx@0.18.5` has a known prototype-pollution advisory — fine for the user's own uploaded file in this sandbox, but don't deep-merge parsed rows into trusted objects.)
- **PDF creation** — capture an app-owned screen or bounded content container; do not build a second PDF-only component tree. Put a React ref on the target and pass it to `PdfExportButton` from `@/components/pdf-export-button` (or call `createPdfBlob` from `@/lib/pdf-export`). Mark buttons, filters, dialogs, loading UI, and other chrome with `data-pdf-exclude`; excluded subtrees do not count toward capture node or resource validation. Keep `iframe`, `object`, `embed`, `video`, `audio`, `link`, image-input elements, custom elements, shadow roots, and inline event-handler attributes outside included capture content and its ancestor chain; the helper rejects unsupported or executable content before cloning. Keep PDF capture targets outside `Dialog`, `Sheet`, `Popover`, `AlertDialog`, and `Select` content because those components use resting transforms on the target's ancestor chain. A visible file input with a selected file is rejected because browsers do not permit its selected state to be copied into the capture; exclude that input or show a separate sanitized filename. For Canvas-style **Include all rows**, use `<PdfExportButton options={{ expandContainers: true }}>` for the shared control or call `createPdfBlob(target, fileName, { expandContainers: true })` for the helper, and mark only direct bounded scrolling children `data-pdf-expand`. Never add `data-pdf-expand` without enabling `expandContainers`; never target nested or virtualized collections, and add `data-pdf-virtualized` so the helper rejects them instead of silently omitting rows. Use a Canvas-familiar label such as **Download PDF** with a scenario-specific filename. The shared control normalizes `.pdf`, bounds and validates output, serializes captures and callback handoffs, displays progress/errors, cleans up its temporary object URL, and optionally calls `onGenerated({ blob, fileName, byteLength, mimeType })`. Cowork grants downloads only in its canonical trusted `/dev/` preview tier; its strict untrusted tier remains unable to start programmatic downloads. The callback is only a connector-neutral handoff: never claim the PDF was saved until the exact connector operation succeeds. Use only app-local, data, blob, or same-origin image and font resources; remote cross-origin resources are rejected even when they advertise CORS. Require the user to narrow large date/data ranges and fail visibly rather than truncating. A standalone PDF deliverable belongs to the PDF artifact workflow, not App Builder.
- **PDF viewing** — show an existing PDF only through `<PdfViewer loadPdf={…} title="…" />` from `@/components/pdf-viewer`. `loadPdf` returns `{ success: true, data }` (or `{ success: false, data: null }` when the read fails) where `data` is the generated client's file-content `result.data` passed through unchanged (the viewer accepts raw bytes, base64, an ASCII-only binary string or a `{ $content }` envelope) or the user's own `await file.arrayBuffer()` as a `Uint8Array`; the viewer validates the `%PDF-` signature, bounds the size at `MAX_PDF_BYTES` (25 MB), renders one page at a time with Previous/Next and zoom, and shows its own loading and retry states. Fetch connector PDFs through the generated client's file-content operation on the user's connection. Load the PDF as bytes, never by URL: never put a connector file URL, sharing link or `blob:` URL in an `iframe`, `object`, `embed`, `<a href>` or `window.open`, and never import `unpdf` or `pdfjs-dist` to render pages yourself. Keep PDF bytes in session memory only, and never log raw connector errors or bytes. Use `onUnavailable` to show a scenario-specific `<ErrorState>` or a file picker when the document cannot be shown.
- **Keyboard shortcuts** — register every shortcut with `useAppShortcut(binding, handler, options)` from `@/components/shortcut-provider`, reusing the names in `APP_SHORTCUTS` (`mod+k` command palette, `/` search, `mod+/` help, `j`/`k`/`enter` list navigation, `n` new, `mod+enter` save and close). A global binding needs `mod`, `ctrl`, `meta` or `alt`, or an F-key (`shift` alone does not count); plain keys such as `j` or `n` must pass `scope` from `useShortcutScope(name)` and spread `{...scope.bindings}` on the region, so they fire only while focus or the last click is inside it; an unscoped plain key with literal options fails ESLint, and any unscoped plain key throws in dev and is dropped in a published app. Modified or scoped bindings call `preventDefault` unless `preventDefault: false` is passed; unmodified global bindings do not (custom overlays: `<ModalShortcutBoundary active name>` plus `useModalShortcutScope()`). Modal scopes beat local scopes, which beat global ones; an open DOM dialog (`aria-modal="true"` or `role="dialog"` with `data-state="open"`) silences globals and scopes outside it, and a Radix popover or popper-positioned select (`position="popper"`) opened inside that dialog counts as the dialog. Shortcuts skip inputs, textareas and selects unless `enableOnFormTags` is set, and contentEditable unless `enableOnContentEditable` is set; for form commands prefer `mod+enter` or an F-key. `shift+<digit>` without `alt` is invalid (it types a symbol); bind the symbol, add `alt`, or use a different key. `shift+<symbol>` (e.g. `shift+/`) is also invalid; bind the character it produces (`?`). Never bind combos the browser or OS keeps for itself (find, save, print, new tab/window, reload, zoom, history, devtools, address bar): `mod+f`, `mod+s`, `mod+p`, `mod+n`, `mod+t`, `mod+w`, `mod+r`, `mod+d`, `mod+l`, `mod+shift+i`/`j`/`c`, `mod+1`…`mod+9`, `alt+f4`, `f5`, `f11`, `f12` and the rest of `RESERVED_BROWSER_SHORTCUTS` in `shortcut-provider.tsx`. `useAppShortcut` enforces that list: a reserved combo throws in dev and is dropped in a published app, scoped or not. Pick a scoped plain key instead (`n` for new, `/` for search); never use `mod+alt+<key>`, which macOS browsers keep for devtools, the side panel and bookmarks. Clipboard and undo (`mod+a`/`c`/`v`/`x`/`z`) are allowed but only inside a scope that owns them. Never add `keydown`/`keyup` listeners or `onkeydown` assignments on `document`/`window`, JSX `onKeyDown`, or `react-hotkeys-hook` — ESLint rejects them. Show each shortcut in its button's tooltip or label so it is discoverable.

```tsx
const list = useShortcutScope("task-list");
useAppShortcut(APP_SHORTCUTS.nextItem, selectNext, { scope: list });
useAppShortcut(APP_SHORTCUTS.commandPalette, openPalette);
return <ul tabIndex={0} {...list.bindings}>{/* items */}</ul>;
```

- **Layout** — `min-h-screen` on the root only (`min-h-[100dvh]` for a full-height hero, not `h-screen`).
- **A11y** — `focus-visible:` ring, `aria-label` on icon-only buttons, real `<label>`s; `min-w-0` on flex children with truncatable text.
- **Sample data** — no round-number stats, no "John Doe", no emojis in headings/body; no copyright footers or fake login/profile buttons unless asked.

## Pen input

For pen drawing, including a drawn signature, approval mark, or field sign-off,
import
`PenInput` from `@/components/pen-input` and `PenInputValue`
or `penInputValueToBlob` from `@/lib/pen-input-value`. Never import
`signature_pad` directly or implement pointer/canvas drawing in the
generated page.

Generated app code belongs under `src/`; never create or place app code under
`.aether-container-tests`. Raw stroke capture is forbidden. A legitimate
non-drawing canvas must use JSX or a recognized React `createElement` call with
the literal `data-aether-canvas-purpose="non-drawing"` marker. The marker does
not permit pointer, mouse, or touch stroke-capture handlers. Global pointer, mouse, and touch listener registration is forbidden.
Imperative or dynamically constructed canvas forms are unsupported. A marked
non-drawing canvas may be accessed through a React ref or from another module
for non-interactive rendering, but pointer, mouse, or touch handlers must not
call stroke-path or canvas-export APIs. `bun run check` enforces this contract.

Hold `PenInputValue | null` in app state and pass it through `value` /
`onChange`. Track `onValidityChange` when a form owns hydrated values; require
both a non-null value and `isValid === true` before enabling submission. Treat
the value as customer content: keep it in session memory,
never put it in `localStorage`, logs, URLs, analytics, or parent-frame messages.
The shared control emits a bounded PNG data URL with dimensions and decoded
byte length; controlled images are limited to 8,192 pixels per edge and
16,777,216 total pixels before browser decode, and their inflated PNG
scanlines are limited to 4 MiB without inflating them on the interaction path.
The wrapper reduces effective device-pixel-ratio
resolution when needed so its own exported RGBA scanlines fit those same limits
while retaining the highest supported fidelity. `Clear drawing` emits `null`.
Synchronous validation verifies the PNG envelope, chunk CRCs, dimensions,
decoded-work bound, and exact end-of-file. The browser image decoder remains
the final authority for compressed image data and displaying the pixels. A
controlled validation or decode failure is surfaced locally without mutating
the caller's authoritative value.
The `required` prop marks the control visually but does not provide native form
constraint validation; when drawing is required, block submission in the owning
form unless its `PenInputValue` state is non-null and
`onValidityChange` reports true. Validate again at the app-owned save
boundary so a malformed hydrated value cannot be persisted.

Use the wrapper's explicit presentation props when the workflow needs a
different drawing surface: `width` (default `100%`) and `height` (default
`14rem`) set CSS dimensions; `penColor` (default black), `backgroundColor`
(default white for stable light/dark-theme contrast), `minStrokeWidth` (default `0.5`), and `maxStrokeWidth`
(default `2.5`) tune the drawing; `borderRadius`, `canvasClassName`, and
`canvasStyle` tune the canvas.
`maxBytes` defaults to `DEFAULT_PEN_INPUT_MAX_BYTES` (512 KiB) and may set a
lower connector-specific ceiling; values above that hard cap are rejected.
Color changes apply to subsequent strokes or a cleared surface; an existing
`PenInputValue` is an opaque PNG and is never recolored in place.
Keep sufficient pen/background contrast, positive stroke widths with
`minStrokeWidth <= maxStrokeWidth`, and a usable touch target. `canvasProps`
is for remaining safe canvas attributes; raw bitmap `width`/`height` stay
wrapper-owned so responsive device-pixel-ratio scaling remains correct.

The control does not save or verify identity. For a local prototype, a Save
action may copy the value into in-memory app state and must describe that
honestly. For a bound app, inspect the exact method under app-root `generated/`
before adapting the output: use `penInputValueToBlob()` only for a declared
binary/file input, and pass `dataUrl` only when the generated scalar type
explicitly accepts it. Check `IOperationResult<T>` and report failures; never
invent a binding, silently fall back to sample persistence, or claim that a
drawing was saved remotely without a successful operation.

### Connector-backed Spatial maps

Geographic map, address-search, location-finder, geocoded-marker, and geographic
pan/zoom requests use the pre-built `SpatialMap` from `@/components/spatial-map`
with a usable Spatial Services binding. Non-geographic charts, diagrams, image
pan/zoom, and timeline markers do not imply Spatial Services.
App code supplies a `SpatialTileLoader` that maps
`{ zoom, x, y }` to the exact local generated-service signature for
`GetMapTile` or `GetMapTileV2` and returns that operation result directly; never
guess parameter order, cast an unknown response, decode bytes, or call
`GetOrganizationSettings`.
The generated `subscription-key` parameter must always remain `undefined` for
every Spatial operation. Never supply an app-owned Azure Maps key, including
when troubleshooting failures; authentication belongs to the bound connection.

- **Markers and selection:** app code owns search text, the accessible result
  list, and selection. Import `SpatialMapMarker` and pass
  at most 500 `markers`, each with a stable, trimmed, case-sensitive string
  `id` of 1–128 Unicode code points, a nonblank label of at most 200 Unicode code points, and valid
  finite latitude/longitude values. Use `selectedId` plus `onLocationSelect`
  for app-owned selection and synchronize it with the accessible result list.
  Omitted or empty `markers` are valid, including loading/empty results;
  absent or stale selection ids simply highlight no marker. A single result
  uses the same collection API. Never derive identity from array position or
  coordinates.
- **Camera and events:** `bounds` takes precedence over `center`/`zoom`.
  Changing camera values moves the map without animation; unrelated rerenders
  and selection changes do not reset user panning. Selection never implicitly
  recenters the map. `onViewportChange` reports `{ center, zoom, bounds }`
  after map movement. `onInputRejected` returns a closed reason; invalid
  configuration disposes the map and shows an unavailable explanation until
  corrected.
- **Callback boundary:** selection and viewport callbacks contain copied plain
  DTOs only. Do not log, persist, analyze, parent-message, or augment them with
  Leaflet objects, DOM nodes, events, URLs, tile bytes, addresses, or
  coordinates. Markers already provide pointer, Enter, and Space selection with
  bounded text-only accessible names; do not replace that behavior.
- **Preview and published play:** both require a usable Spatial Services binding;
  a published user may still need per-user consent, so preview success does not
  prove that another user can load the published map. For an existing app, read
  `src/components/spatial-map.tsx` directly before use; if an older snapshot
  lacks it, stop and report that the protected control is unavailable rather
  than importing `leaflet` or recreating the wrapper.
- **Fallbacks:** a failed connection, search, tile request, validation, or render
  must show an unavailable/error state and stop further connector calls. The
  sole exception is scheduler overflow beyond 8 active plus 64 queued requests,
  shared across all map instances in the app page (including remounts):
  `capacity_exceeded` rejects only that tile and retains no deferred request
  queue. Once the shared queue is empty and an active slot is free, the layer
  removes capacity-rejected tiles from Leaflet's registry and requests the
  still-visible missing tiles.
  Visible overflow waiters fail visibly if shared capacity stalls.
  Never substitute sample coordinates, a public tile provider, raw HTTP, or a
  connector-returned URL.
  A tile request's 30-second deadline shows the unavailable state but does not
  cancel its loader. Timed-out calls still count toward the eight active calls
  until they settle; **Try again** waits for that capacity and keeps the
  unavailable explanation until a new tile is accepted. Queued retries share
  a 30-second stall deadline, reset on SDK settlement rather than enqueue.
  Healthy backlogs may wait longer; retry fails visibly if capacity stays
  occupied and cannot guarantee recovery of an uncancellable transport.
  After bytes arrive, image loading/decoding has its own 30-second deadline;
  a stalled image fails visibly without changing physical SDK-call permits.
  Removing a map detaches its pending rendering and callbacks, not the
  underlying calls or their permits.
- **Privacy and persistence:** `SpatialMap` persists nothing. Keep
  connector-derived addresses, coordinates, and tile bytes in session memory
  only; never put them in `localStorage`, analytics, logs, URLs, or parent-frame
  messages. Do not call `console.*` in Spatial search or tile error paths; show
  a fixed, user-safe error message in the app instead. Never persist tile bytes,
  create Blob URLs, or bypass the protected image validation.

## Barcode scanning

Use `<BarcodeScanner>` from `@/components/barcode-scanner` for any QR code or
barcode feature; never import `@zxing/library`, and never
hand-roll a `getUserMedia` + canvas decode loop (ESLint blocks the imports).

Pick `barcodeTypes` from what the user is scanning, not "everything" — fewer
formats scan faster and misread less:

- QR codes, links, tickets, badges → `["qr_code"]`
- Retail products / grocery → `["ean_13", "ean_8", "upc_a", "upc_e"]`
- Shipping labels, asset tags, warehouse bins → `["code_128"]` (add `"code_39"` for older labels)
- Boarding passes / IDs → `["pdf417", "aztec"]`; small parts → `["data_matrix"]`
- Omit `barcodeTypes` only when the user genuinely doesn't know; it then scans all
  `BARCODE_TYPES` from `@/lib/barcode-scan`.

`onScan(value, type)` fires once per distinct code (repeat reads of the same code
in view are deduped). It is not awaited: scanning continues immediately, and it may
return a promise. An `onScan` that throws or rejects logs a warning and, unless the
scanner has since unmounted or changed mode (e.g. "Try camera again"), shows one "Couldn't process that scan." toast. A synchronous throw is not
announced; an async `onScan` is announced when it returns its promise, and a later
rejection still shows the toast. A live scan whose `onScan` failed is not redelivered while the code stays in view (move it away for ~2 s and back to retry), so `onScan` should be idempotent or handle its own retry. Results from a superseded session (after "Try camera again") are dropped. `scanRate` (frames/sec, default 20, clamped) trades battery
for speed. Optional `preferFrontCamera`, `flashlightEnabled`, `className`,
`videoClassName` and `fallbackMessage` cover lens, torch, sizing and copy.

Live scanning works only in a **published** app. In design-time preview, or when
the camera is denied or missing, the component shows a photo-upload fallback
(image files up to 10 MB) that decodes the same formats; if the camera opens
but the live decoder keeps failing, it falls back with "Live scanning unavailable". Word UI copy
accordingly and never promise that preview scans live. While the camera
permission prompt is pending, the scanner offers "Scan from a photo instead";
unlike `CameraCapture` there is no auto-fallback timer.

Scanned values are untrusted text. Render them as text, validate them before
using them as lookup keys, and pass any URL through `toSafeHttpUrl()` before
rendering a link or navigating; never auto-open a scanned URL.

## 3D models

Use `<ModelViewer source={…} />` from `@/components/model-viewer` to show a 3D
model. It loads glTF (`.gltf`), GLB, OBJ and STL. `source` is a `File` or `Blob`
(for example from an `<input type="file">`), an `ArrayBuffer`/`Uint8Array`, or
an `https:` URL; pass `format` when the source has no file name or extension.
`format` forces that loader for every source and skips detection, so do not
pass it alongside a file the user picked (`format={file ? undefined : "glb"}`).
The viewer frames the model automatically and the user can orbit and zoom.

Never commit a user-attached model file into app source or `src/assets/`: a
product, part, CAD export or scan may be confidential, and published bundles are
visible to everyone the app is shared with. Keep uploaded/attached model bytes in
browser state (a `File`, `Blob` or `ArrayBuffer`) and pass them directly to
`<ModelViewer>`, or show the built-in sample until the user picks a file.
Only use `src/assets/` for a model that is intentionally part of the app itself
(for example a safe demo asset the app author owns): import it plainly
(`import shoeUrl from "@/assets/shoe.glb"`; model extensions are registered as
assets, so the import is a URL that already carries the app's base path). Then
`fetch(shoeUrl)` and pass the response bytes and `format`
(`source={bytes} format="glb"`). Do not add a `?url` suffix: the preview proxy
serves it as `?url=`, which Vite does not recognise, and the import fails. Never
fetch a root-absolute path such as `"/shoe.glb"`: the app is served under a base
path, so it 404s. A file in `public/` is fetched as
`` `${import.meta.env.BASE_URL}shoe.glb` ``.

A model in a connected file store (OneDrive, SharePoint, a Dataverse file
column) comes from the bound connector's file-content operation. Pass
`result.data` unchanged, with the file's name, to `decodeModelBytes` from
`@/lib/model-load`. It accepts bytes, base64, a `data:` URL, a `{ $content }`
or `{ contentBytes }` envelope or OBJ/STL/glTF text, and returns `{ ok, bytes, format }` or
`{ ok: false, reason }`. Render `<ModelViewer source={bytes} format={format} />`,
and show a loading state rather than the sample while it loads. Never write your
own base64 decoder, and never use a URL or sharing-link token as a file id.

Limits, all enforced by the component:

- Models over 10 MiB are rejected, and a download that has not finished within
  60 seconds fails.
- Draco, meshopt and KTX2-compressed glTF are rejected; ask for an
  uncompressed export.
- A `.gltf` must embed its buffers and textures (data URIs); prefer `.glb`.
- OBJ `.mtl` material files are not loaded. OBJ and STL models carry no
  materials, so they render in a plain blue; pass `color` (hex, `rgb()`, `hsl()` or a CSS color name, e.g.
  `color="#c0392b"`; `oklch()` and `var(--token)` are not parsed) to tint them. An OBJ or STL that carries vertex colors
  keeps them and ignores `color`.
  glTF/GLB keep their own materials and textures and ignore `color`, so prefer
  `.glb` when the model's look matters.

When the user asks to see a 3D object and supplies no model:

- The app MUST open with a colored model already showing. Never ship an empty
  or upload-only first screen; a file picker may only replace the sample.
- `<ModelViewer source={null} />` already shows a colored sample model (a toy
  car) with a "Sample model" badge; mount it and swap `source` when the user
  picks a file. Never build a three.js scene or geometry by hand.
- Never point the viewer at a third-party sample URL (GitHub raw content, a
  model gallery): the published app's CSP may block it, and the upstream file
    can change or disappear. Use the built-in sample or a file the user supplies.
- Do not hand-write OBJ, STL or three.js geometry for the model, and give the
  viewer a model file (the built-in sample or the user's), never a gray one.
- The built-in badge already labels the sample; keep the upload control next
  to it so the user can replace it with their own file.
- Each viewer holds a WebGL context and browsers allow only about 16 per page:
  mount a `<ModelViewer>` only while a model is shown, never one per list row.

Load failures never throw: the viewer shows an error state and a toast, and
calls `onError(error)` (`error.code` is one of `unsupported-format`,
`too-large`, `compressed`, `external-resources`, `unsafe-url`, `fetch-failed`,
`read-failed`, `parse-failed`, `webgl-unavailable`, `viewer-load-failed`).
`external-resources` means a `.gltf` points at separate `.bin` or texture
files: re-export it as a self-contained `.glb` or a `.gltf` with embedded data
URIs. `onLoad(stats)` fires after a successful load with
`{ meshes, triangles, size: { x, y, z } }` (size in model units).
Set `wireframe` to draw edges only and `autoRotate` to spin the model until
the user interacts with the viewer controls (any press, drag or scroll on the viewer); both default
to `false` and can change without reloading the model. To restart auto-rotate
after user interaction, render once with `autoRotate={false}`, then render a
later state with `autoRotate={true}`.
Size the viewer with `className` (the canvas fills it). A resize re-frames the
model until the user drags, pinches, scrolls or presses a key on it (a plain
click to focus does not count), then keeps their view. The canvas is
focusable: arrow keys rotate and `+`/`-` zoom while it has focus (the viewer's
own keys, not app shortcuts; do not bind them elsewhere). `source` is compared
by bounded content, not identity, for byte sources: a new `Uint8Array` or
`ArrayBuffer` with the same accepted-size bytes as the shown model does not
reload (the viewer keeps its own copy, so rewriting a buffer you passed in
does not hide a change). A different
`File` or `Blob` object always reloads, even if its metadata matches. It behaves the same in
design-time preview and in a published app.

## Theming

Grayscale by default — **every build adds color.** Single theme unless the user asks for dark mode. Turn-1 builds select one validated hue preset directly from the stable app UUID from `/opt/appbuilder/templates/v1/THEMING.md`. Paste the hue into all three `index.css` token blocks (surfaces stay neutral), set `--radius` to suit the app, then accent inline with Tailwind utilities. **Turn-1 builds AND restyle / recolor iterates → prefer the current paste-able presets in `/opt/appbuilder/templates/v1/THEMING.md`; use the app-local `THEMING.md` only as a legacy fallback because template snapshots are not refreshed after creation** (retheme the `src/index.css` token blocks; don't derive OKLCH by hand).

**Tailwind v4 (config-less).** No `tailwind.config.js` — everything is in `src/index.css` (`@import "tailwindcss";`, tokens in `:root`/`.dark`, `@theme inline { --color-*: var(--*) }` maps vars → utilities). **Adding a token needs BOTH the `:root`/`.dark` var AND its `@theme` `--color-*` mapping** (a var with no mapping renders nothing). v3 habits that silently break: `bg-opacity-50`→`bg-black/50`, `shadow`→`shadow-sm`, `outline-none`→`outline-hidden`.


## Parent-frame message contract (LOCKED)

The preview runs inside an embedding **Cowork host** iframe. Hand-written template source has four parent-frame channels, all owned by infra files you must not edit:

- **Console forwarding** (`console-capture.ts`, unchanged legacy behavior): mirrors `console.log/warn/error` to the host preview panel. This is the existing, general channel. It resolves its target origin at runtime (env override → `ancestorOrigins` → same-origin fallback) — that resolution is grandfathered legacy behavior and must not be copied into new channels.
- **Runtime-error signal** (`cowork-parent-transport.ts`): a **fixed, detail-free** crash signal, sent by the ErrorBoundary for caught render crashes or by React's root `onUncaughtError` hook for uncaught root crashes.
- **App-mounted signal** (`app-mounted-transport.ts`): a **fixed-shape, detail-free** first-paint signal (`{ type: "app-mounted", timestamp }`), sent once from `main.tsx` after the first `requestAnimationFrame` following the initial render commit, so the host can measure real load latency instead of inferring it from the iframe's `load` event.
- **App-view snapshot** (`app-view-transport.ts`, fed by `app-view-serializer.ts` and scheduled by `app-view-signal.tsx`): a **bounded** report of what the user can see (`{ type: "app-view", v: 1, timestamp, route, tree, truncated }`), so the agent can ground on the screen the user is asking about. This is the ONE channel that carries app content by design. Its bound is the serialiser: `route` is the matched route PATTERN from `routes.tsx` (never the pathname, never params); `tree` is an accessible-name tree — roles, accessible names and visible text, one node per line, two spaces of indent per depth, `role: name` for elements and `"text"` (quoted) for text leaves so a parser can tell the two apart — with no attributes, no form-control values (a value-bearing control — `input`, `textarea`, `select`, `option`, `output`, `progress`, `meter` — never contributes to a computed name, so a wrapping `<label>` names it without its value, and a `contenteditable` region is a `textbox` control whose body never crosses), no link targets, no image sources, no ids/classes/`data-*`, no hidden subtrees (a hidden `<label>` or `aria-labelledby` target names nothing; CSS `display:none`/`visibility:hidden` count as hidden), cut at whole lines to 24,000 characters and capped in depth (transparent containers count toward the depth bound too) and node count. The serialiser reads DOM properties through exactly two casts (`.checked`, `.labels`), pinned by the guard; every other read is an allow-listed attribute. Emitted on the preview mount only (the orchestrator-baked `/v1/…` base; a deployed app never observes or posts), after a route change or a settled DOM mutation anywhere in `document.body` (so an open dialog, sheet or menu is in the tree), rate-floored, never on a timer alone; the host keeps only the latest and forwards it under the user's consent. Never emitted top-level.

**The runtime-error signal is immutable.** Both emitters call `postAppRuntimeErrorToCoworkParent()` with **no arguments**, and the template emits exactly:

    { type: "preview-error", code: "APP_RUNTIME_ERROR" }

Cowork receiver support for `APP_RUNTIME_ERROR` lands separately; until then,
the host safely ignores this code and its generic crash UI remains inactive.

**The app-mounted signal carries exactly one dynamic field.** `postAppMountedToCoworkParent()` takes **no arguments** and emits exactly:

    { type: "app-mounted", timestamp: <Date.now() at call time> }

`timestamp` is a clock reading, never customer content, route, URL, token, or `appId`.

Cowork's host-side listener for `{ type: "app-mounted" }` merged in `bic/cowork` PR #8401 (app-studio#2979 client-preview telemetry).

Hard rules (a security review depends on these; the Aether repo enforces them with `aether_runtime/tests/unit/app_builder/test_template_runtime_error_security.py`):

- **No dynamic data crosses to the parent** from the runtime-error or app-mounted paths beyond the single `timestamp` field above — no error `name`/`message`/`stack`, no React component stack, no route, URL, token, `appId`, or customer content. The app-view path is the only exception, and only within the serialiser's allow-list: a route PATTERN and the accessible-name tree. Nothing else — never `location.href`, never a form value, never an `appId`, never a token — may be added to that envelope; widening it is a security review, not an edit. `reportPrivateRuntimeError` writes to the pre-capture console implementation and makes a best-effort POST to `./__dev/console`; the runtime preview proxy forwards that POST to the dev server (#24067), but the channel stays best-effort — the log is absent until the first report lands and a restarting dev server drops reports — so repair logic must not assume `.browser-errors.log` exists.
- **No wildcard target origin.** `cowork-parent-transport.ts`, `app-mounted-transport.ts` and `app-view-transport.ts` post their messages to the SAME **explicit allow-list** of Cowork host origins (`COWORK_PARENT_ORIGINS`, exported from `cowork-parent-transport.ts`) and rely on Cowork pinning `event.source` to this iframe. Adding a supported host requires updating both that list and `EXPECTED_PARENT_ORIGINS` in the security guard — never add `"*"`, a suffix match, or a runtime-derived origin (`ancestorOrigins`, `document.referrer`, `location.origin`).
- **Top-level is a no-op.** When not embedded (`window.parent === window`), each sender does nothing.
- **Do not add another hand-written post-to-parent path.** In `src/`, `window.parent` / `window.top` / `postMessage` may appear only in the four transport infra files (`console-capture.ts`, `cowork-parent-transport.ts`, `app-mounted-transport.ts`, `app-view-transport.ts`). `app-view-serializer.ts` and `app-view-signal.tsx` never touch the parent; they only prepare and schedule the snapshot. New app code must never message the parent, and must never read the DOM to build a payload for the host — the serialiser is the one reader.
- **Bundled dependencies are outside this source contract.** In particular, `@microsoft/managed-apps` may transfer its connector `MessagePort` to the embedding host with a wildcard target origin on the no-bridge authoring path. The Aether source guard does not inspect dependency bundles and must not be treated as proving that only these four channels exist in the complete runtime.
- The in-frame fallback UI may still show the real local error message — that stays inside the iframe and never crosses to the host.
